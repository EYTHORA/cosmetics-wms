// assets/js/main.js
$(document).ready(function() {
    // Sidebar Toggle
    $('.sidebar-toggle').click(function() {
        $('.sidebar').toggleClass('collapsed');
        $('.main').toggleClass('expanded');
    });
    
    // Submenu Toggle
    $('.has-submenu > a').click(function(e) {
        e.preventDefault();
        $(this).parent().toggleClass('active');
    });
    
    // Tooltip
    $('[data-bs-toggle="tooltip"]').tooltip();
    
    // Auto-hide alerts
    setTimeout(function() {
        $('.alert').fadeOut('slow');
    }, 5000);
    
    // Batch Table Row Click
    $('.batch-row').click(function() {
        window.location = $(this).data('href');
    });
    
    // Expiry Date Calculator
    $('input[name="manufacturing_date"]').change(function() {
        var manufactureDate = new Date($(this).val());
        if (manufactureDate) {
            // Default expiry 24 months for cosmetics
            var expiryDate = new Date(manufactureDate);
            expiryDate.setMonth(expiryDate.getMonth() + 24);
            
            var formatted = expiryDate.toISOString().split('T')[0];
            $('input[name="expiry_date"]').val(formatted);
        }
    });
    
    // Auto-generate Batch Number
    $('select[name="product_id"]').change(function() {
        if($(this).val()) {
            var sku = $(this).find(':selected').text().split(' - ')[0];
            var year = new Date().getFullYear();
            var month = ('0' + (new Date().getMonth() + 1)).slice(-2);
            
            // Generate random 3-digit number
            var random = Math.floor(Math.random() * 900) + 100;
            
            var batchNo = 'BATCH-' + sku + '-' + year + month + '-' + random;
            $('input[name="batch_number"]').val(batchNo);
        }
    });
    
    // Real-time Expiry Check
    $('input[name="expiry_date"]').change(function() {
        var expiryDate = new Date($(this).val());
        var today = new Date();
        var diffTime = expiryDate - today;
        var diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        
        var alertBox = $('#expiryAlert');
        if(diffDays < 0) {
            alertBox.html('<i class="fas fa-exclamation-triangle"></i> Expiry date sudah lewat!')
                     .removeClass('alert-warning alert-info')
                     .addClass('alert-danger')
                     .show();
        } else if(diffDays < 90) {
            alertBox.html('<i class="fas fa-clock"></i> Hanya ' + diffDays + ' hari lagi sampai expired')
                     .removeClass('alert-info alert-danger')
                     .addClass('alert-warning')
                     .show();
        } else {
            alertBox.html('<i class="fas fa-check-circle"></i> Masih ' + diffDays + ' hari sampai expired')
                     .removeClass('alert-warning alert-danger')
                     .addClass('alert-info')
                     .show();
        }
    });
});