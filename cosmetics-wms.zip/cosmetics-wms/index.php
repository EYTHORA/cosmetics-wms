<?php
// index.php - DASHBOARD
require_once 'includes/config.php';
require_once 'includes/auth.php';
checkLogin();

$active_menu = 'dashboard';
$page_title = "Dashboard";
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cosmetics WMS - Dashboard</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <style>
        body { background: #f8f9fa; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        
        /* SIDEBAR */
        .sidebar {
            background: linear-gradient(180deg, #2c3e50 0%, #1a252f 100%);
            color: white;
            min-height: 100vh;
            width: 250px;
            position: fixed;
            left: 0;
            top: 0;
            overflow-y: auto;
            z-index: 1000;
            box-shadow: 3px 0 10px rgba(0,0,0,0.1);
        }
        
        .main-content {
            margin-left: 250px;
            padding: 25px;
            min-height: 100vh;
        }
        
        /* TOP BAR */
        .top-bar {
            background: white;
            padding: 15px 25px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 25px;
        }
        
        /* STATS CARDS */
        .stat-card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.08);
            transition: transform 0.3s;
            height: 100%;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        .stat-icon {
            font-size: 2.5rem;
            opacity: 0.8;
        }
        
        /* QUICK ACTIONS */
        .quick-action-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        
        .action-btn {
            padding: 12px 20px;
            border-radius: 8px;
            font-weight: 500;
            transition: all 0.3s;
        }
        
        .action-btn:hover {
            transform: scale(1.05);
        }
        
        /* RECENT ACTIVITY */
        .activity-item {
            padding: 15px;
            border-left: 4px solid #3498db;
            margin-bottom: 10px;
            background: white;
            border-radius: 8px;
        }
        
        .activity-item.warning { border-left-color: #f39c12; }
        .activity-item.danger { border-left-color: #e74c3c; }
        .activity-item.success { border-left-color: #27ae60; }
        
        /* RESPONSIVE */
        @media (max-width: 768px) {
            .sidebar {
                width: 70px;
            }
            .sidebar .menu-text {
                display: none;
            }
            .main-content {
                margin-left: 70px;
            }
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <!-- SIDEBAR -->
        <?php include 'includes/sidebar.php'; ?>
        
        <!-- MAIN CONTENT -->
        <div class="main-content">
            <!-- TOP BAR -->
            <div class="top-bar d-flex justify-content-between align-items-center">
                <div>
                    <h3 class="mb-1">📊 Dashboard</h3>
                    <p class="text-muted mb-0">Welcome back, <?php echo $_SESSION['username']; ?>! Here's your overview.</p>
                </div>
                <div class="text-end">
                    <span class="badge bg-primary"><?php echo date('l, F j, Y'); ?></span>
                </div>
            </div>
            
            <!-- STATS ROW -->
            <div class="row mb-4">
                <div class="col-md-3 mb-3">
                    <div class="card stat-card bg-primary text-white">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="card-subtitle">Total Products</h6>
                                    <h2 class="card-title">156</h2>
                                    <small>+12% from last month</small>
                                </div>
                                <i class="fas fa-cubes stat-icon"></i>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-3 mb-3">
                    <div class="card stat-card bg-success text-white">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="card-subtitle">Active Batches</h6>
                                    <h2 class="card-title">42</h2>
                                    <small>3 expiring soon</small>
                                </div>
                                <i class="fas fa-boxes stat-icon"></i>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-3 mb-3">
                    <div class="card stat-card bg-warning text-white">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="card-subtitle">Pending Orders</h6>
                                    <h2 class="card-title">18</h2>
                                    <small>Need processing</small>
                                </div>
                                <i class="fas fa-shopping-cart stat-icon"></i>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-3 mb-3">
                    <div class="card stat-card bg-danger text-white">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="card-subtitle">Low Stock</h6>
                                    <h2 class="card-title">7</h2>
                                    <small>Need replenishment</small>
                                </div>
                                <i class="fas fa-exclamation-triangle stat-icon"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- QUICK ACTIONS & RECENT ACTIVITY -->
            <div class="row">
                <!-- QUICK ACTIONS -->
                <div class="col-md-8">
                    <div class="quick-action-card">
                        <h5 class="mb-4">🚀 Quick Actions</h5>
                        <div class="row g-3">
                            <div class="col-md-4">
                                <a href="http://localhost:8080/cosmetics-wms/modules/products/add.php" 
                                   class="btn btn-primary w-100 action-btn">
                                    <i class="fas fa-plus-circle me-2"></i> Add Product
                                </a>
                            </div>
                            <div class="col-md-4">
                                <a href="http://localhost:8080/cosmetics-wms/modules/batch/add.php" 
                                   class="btn btn-success w-100 action-btn">
                                    <i class="fas fa-box me-2"></i> Add Batch
                                </a>
                            </div>
                            <div class="col-md-4">
                                <a href="http://localhost:8080/cosmetics-wms/modules/orders/create.php" 
                                   class="btn btn-warning w-100 action-btn">
                                    <i class="fas fa-cart-plus me-2"></i> Create Order
                                </a>
                            </div>
                            <div class="col-md-4">
                                <a href="http://localhost:8080/cosmetics-wms/modules/reports/" 
                                   class="btn btn-info w-100 action-btn">
                                    <i class="fas fa-chart-bar me-2"></i> View Reports
                                </a>
                            </div>
                            <div class="col-md-4">
                                <a href="http://localhost:8080/cosmetics-wms/modules/inventory/" 
                                   class="btn btn-secondary w-100 action-btn">
                                    <i class="fas fa-warehouse me-2"></i> Check Inventory
                                </a>
                            </div>
                            <div class="col-md-4">
                                <button class="btn btn-dark w-100 action-btn" onclick="window.print()">
                                    <i class="fas fa-print me-2"></i> Print Summary
                                </button>
                            </div>
                        </div>
                    </div>
                    
                    <!-- RECENT BATCHES -->
                    <div class="quick-action-card">
                        <h5 class="mb-4">📦 Recent Batches</h5>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Batch No</th>
                                        <th>Product</th>
                                        <th>Expiry Date</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>BATCH-LIP001-2024-01</td>
                                        <td>Wardah Lip Cream Matte</td>
                                        <td>15/07/2025</td>
                                        <td><span class="badge bg-success">Good</span></td>
                                    </tr>
                                    <tr>
                                        <td>BATCH-LIP002-2023-11</td>
                                        <td>Make Over Liquid Lipstick</td>
                                        <td>10/11/2024</td>
                                        <td><span class="badge bg-warning">Warning</span></td>
                                    </tr>
                                    <tr>
                                        <td>BATCH-FND001-2023-12</td>
                                        <td>Wardah Lightening Foundation</td>
                                        <td>01/12/2024</td>
                                        <td><span class="badge bg-danger">Critical</span></td>
                                    </tr>
                                    <tr>
                                        <td>BATCH-LIP003-2023-08</td>
                                        <td>ESOA Moisturizing Lipstick</td>
                                        <td>01/08/2024</td>
                                        <td><span class="badge bg-danger">Expired</span></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                
                <!-- RECENT ACTIVITY -->
                <div class="col-md-4">
                    <div class="quick-action-card">
                        <h5 class="mb-4">📝 Recent Activity</h5>
                        <div class="activity-list">
                            <div class="activity-item">
                                <small class="text-muted">10 min ago</small>
                                <p class="mb-0"><strong>New batch added:</strong> BATCH-LIP005-2024-01</p>
                            </div>
                            <div class="activity-item warning">
                                <small class="text-muted">1 hour ago</small>
                                <p class="mb-0"><strong>Low stock alert:</strong> Make Over Foundation (15 units)</p>
                            </div>
                            <div class="activity-item success">
                                <small class="text-muted">2 hours ago</small>
                                <p class="mb-0"><strong>Order completed:</strong> ORD-2024-015 (Beauty Store)</p>
                            </div>
                            <div class="activity-item">
                                <small class="text-muted">5 hours ago</small>
                                <p class="mb-0"><strong>QC Passed:</strong> BATCH-FND002-2024-01</p>
                            </div>
                            <div class="activity-item danger">
                                <small class="text-muted">Yesterday</small>
                                <p class="mb-0"><strong>Expiry alert:</strong> 3 batches expiring in 30 days</p>
                            </div>
                        </div>
                    </div>
                    
                    <!-- SYSTEM STATUS -->
                    <div class="quick-action-card">
                        <h5 class="mb-4">⚙️ System Status</h5>
                        <div class="mb-3">
                            <small class="d-block mb-1">Database Connection</small>
                            <div class="progress">
                                <div class="progress-bar bg-success" style="width: 100%"></div>
                            </div>
                            <small class="text-success">✅ Connected</small>
                        </div>
                        <div class="mb-3">
                            <small class="d-block mb-1">Storage Usage</small>
                            <div class="progress">
                                <div class="progress-bar bg-info" style="width: 65%"></div>
                            </div>
                            <small>65% used (1.3GB/2GB)</small>
                        </div>
                        <div class="mb-3">
                            <small class="d-block mb-1">Last Backup</small>
                            <small class="text-muted">2024-01-14 23:00</small>
                        </div>
                        <div>
                            <small class="d-block mb-1">Active Users</small>
                            <small class="text-muted">3 users online</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- SCRIPTS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Auto-refresh dashboard every 5 minutes
        setTimeout(function() {
            window.location.reload();
        }, 300000); // 5 minutes
        
        // Tooltip initialization
        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
        var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl)
        })
    </script>
</body>
</html>