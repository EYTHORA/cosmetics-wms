<?php
// modules/inventory/index.php - VERSI FIX (TANPA VIEW)
$root_path = dirname(dirname(dirname(__FILE__))) . '/';
require_once $root_path . 'includes/config.php';
require_once $root_path . 'includes/auth.php';
checkLogin();

$active_menu = 'inventory';
$page_title = "Inventory Management";

// PAGINATION SETUP
$limit = 10;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

// SEARCH & FILTER
$search = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : '';
$category = isset($_GET['category']) ? (int)$_GET['category'] : 0;
$stock_level = isset($_GET['stock_level']) ? $_GET['stock_level'] : '';

// BUILD WHERE CLAUSE untuk products
$where = "p.status = 'active'";
if (!empty($search)) {
    $where .= " AND (p.name LIKE '%$search%' OR p.sku LIKE '%$search%')";
}
if ($category > 0) {
    $where .= " AND p.category_id = $category";
}

// GET TOTAL COUNT
$count_sql = "SELECT COUNT(p.id) as total 
              FROM products p
              WHERE $where";
$count_result = mysqli_query($conn, $count_sql);
$total_items = mysqli_fetch_assoc($count_result)['total'];
$total_pages = ceil($total_items / $limit);

// GET INVENTORY DATA
$sql = "SELECT p.id, p.sku, p.name, p.category_id, p.min_stock, p.max_stock,
               c.name as category_name,
               b.name as brand_name,
               COALESCE((
                   SELECT SUM(pb2.current_quantity) 
                   FROM product_batches pb2 
                   WHERE pb2.product_id = p.id AND pb2.status = 'released'
               ), 0) as total_stock,
               COALESCE((
                   SELECT MAX(pb2.updated_at) 
                   FROM product_batches pb2 
                   WHERE pb2.product_id = p.id
               ), p.created_at) as last_updated
        FROM products p
        LEFT JOIN categories c ON p.category_id = c.id
        LEFT JOIN brands b ON p.brand_id = b.id
        WHERE $where
        ORDER BY p.name ASC
        LIMIT $limit OFFSET $offset";

$result = mysqli_query($conn, $sql);

// GET CATEGORIES FOR FILTER
$categories_sql = "SELECT id, name FROM categories ORDER BY name";
$categories_result = mysqli_query($conn, $categories_sql);

// ================================
// PERBAIKAN: GANTI DENGAN QUERY LANGSUNG, BUKAN VIEW
// ================================

// GET STATS - PAKAI QUERY LANGSUNG
$stats_sql = "SELECT 
    (SELECT COUNT(*) FROM products WHERE status = 'active') as total_products,
    (SELECT COUNT(*) FROM product_batches WHERE status = 'released' AND expiry_date > CURDATE()) as active_batches,
    (SELECT COUNT(*) FROM expiry_alerts WHERE is_resolved = FALSE AND alert_type = 'critical') as critical_alerts,
    (SELECT COUNT(*) FROM orders WHERE status = 'picking' OR status = 'packing') as pending_orders,
    (SELECT COALESCE(SUM(current_quantity), 0) FROM product_batches WHERE status = 'released') as total_stock_items";

$stats_result = mysqli_query($conn, $stats_sql);
if($stats_result && mysqli_num_rows($stats_result) > 0) {
    $stats = mysqli_fetch_assoc($stats_result);
} else {
    // Fallback
    $stats = [
        'total_products' => 0,
        'active_batches' => 0,
        'critical_alerts' => 0,
        'pending_orders' => 0,
        'total_stock_items' => 0
    ];
}

// GET LOW STOCK COUNT - PAKAI QUERY LANGSUNG
$low_stock_sql = "SELECT COUNT(*) as count FROM (
                    SELECT p.id, COALESCE(SUM(pb.current_quantity), 0) as current_stock, p.min_stock
                    FROM products p
                    LEFT JOIN product_batches pb ON p.id = pb.product_id AND pb.status = 'released'
                    WHERE p.status = 'active'
                    GROUP BY p.id
                    HAVING current_stock <= p.min_stock
                ) as low_stock";
$low_stock_result = mysqli_query($conn, $low_stock_sql);
$low_stock_data = mysqli_fetch_assoc($low_stock_result);
$low_stock_count = $low_stock_data['count'] ?? 0;

// GET EXPIRING SOON COUNT - PAKAI QUERY LANGSUNG
$expiring_sql = "SELECT COUNT(*) as count FROM (
                    SELECT pb.id, pb.expiry_date, DATEDIFF(pb.expiry_date, CURDATE()) as days_remaining
                    FROM product_batches pb
                    WHERE pb.status = 'released' 
                    AND pb.expiry_date > CURDATE()
                    AND DATEDIFF(pb.expiry_date, CURDATE()) BETWEEN 1 AND 30
                ) as expiring";
$expiring_result = mysqli_query($conn, $expiring_sql);
$expiring_data = mysqli_fetch_assoc($expiring_result);
$expiring_count = $expiring_data['count'] ?? 0;

// GET STOCK VALUE - UNTUK SUMMARY
$value_sql = "SELECT SUM(p.unit_price * COALESCE(pb.total_stock, 0)) as total_value 
              FROM products p
              LEFT JOIN (
                  SELECT product_id, SUM(current_quantity) as total_stock
                  FROM product_batches 
                  WHERE status = 'released'
                  GROUP BY product_id
              ) pb ON p.id = pb.product_id";
$value_result = mysqli_query($conn, $value_sql);
$total_value = mysqli_fetch_assoc($value_result)['total_value'] ?? 0;

// GET STOCK DISTRIBUTION
$good_stock_sql = "SELECT COUNT(*) as count FROM (
                    SELECT p.id, COALESCE(SUM(pb.current_quantity), 0) as current_stock, p.min_stock
                    FROM products p
                    LEFT JOIN product_batches pb ON p.id = pb.product_id AND pb.status = 'released'
                    WHERE p.status = 'active'
                    GROUP BY p.id
                    HAVING current_stock > p.min_stock
                ) as good_stock";
$good_result = mysqli_query($conn, $good_stock_sql);
$good_stock = mysqli_fetch_assoc($good_result)['count'] ?? 0;

$out_stock_sql = "SELECT COUNT(*) as count FROM (
                    SELECT p.id, COALESCE(SUM(pb.current_quantity), 0) as current_stock
                    FROM products p
                    LEFT JOIN product_batches pb ON p.id = pb.product_id AND pb.status = 'released'
                    WHERE p.status = 'active'
                    GROUP BY p.id
                    HAVING current_stock = 0
                ) as out_stock";
$out_result = mysqli_query($conn, $out_stock_sql);
$out_stock = mysqli_fetch_assoc($out_result)['count'] ?? 0;

$total_active_products = $stats['total_products'];
$good_percentage = $total_active_products > 0 ? ($good_stock / $total_active_products * 100) : 0;
$low_percentage = $total_active_products > 0 ? ($low_stock_count / $total_active_products * 100) : 0;
$out_percentage = $total_active_products > 0 ? ($out_stock / $total_active_products * 100) : 0;
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cosmetics WMS - Inventory</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <style>
        .sidebar { background: #2c3e50; color: white; width: 250px; position: fixed; height: 100vh; }
        .main-content { margin-left: 250px; padding: 25px; }
        
        .inventory-card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.08);
            transition: transform 0.3s;
            height: 100%;
        }
        
        .inventory-card:hover {
            transform: translateY(-3px);
        }
        
        .stock-indicator {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            display: inline-block;
            margin-right: 8px;
        }
        
        .stock-high { background: #27ae60; }
        .stock-medium { background: #f39c12; }
        .stock-low { background: #e74c3c; }
        .stock-out { background: #7f8c8d; }
        
        .brand-badge {
            background: #3498db;
            color: white;
            padding: 2px 8px;
            border-radius: 10px;
            font-size: 11px;
        }
    </style>
</head>
<body>
    <?php include $root_path . 'includes/sidebar.php'; ?>
    
    <div class="main-content">
        <!-- HEADER -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h3 class="mb-1">📦 Inventory Management</h3>
                <p class="text-muted mb-0">Real-time stock monitoring and management</p>
            </div>
            <div>
                <button onclick="window.location.reload()" class="btn btn-primary me-2">
                    <i class="fas fa-sync-alt"></i> Refresh
                </button>
                <a href="report.php" class="btn btn-success">
                    <i class="fas fa-file-export"></i> Export Report
                </a>
            </div>
        </div>
        
        <!-- INVENTORY STATS -->
        <div class="row mb-4">
            <div class="col-md-2 mb-3">
                <div class="card inventory-card bg-primary text-white">
                    <div class="card-body">
                        <h6 class="card-subtitle">Total Products</h6>
                        <h2 class="card-title"><?php echo $stats['total_products'] ?? 0; ?></h2>
                        <small>Active products</small>
                    </div>
                </div>
            </div>
            <div class="col-md-2 mb-3">
                <div class="card inventory-card bg-success text-white">
                    <div class="card-body">
                        <h6 class="card-subtitle">Total Stock</h6>
                        <h2 class="card-title"><?php echo number_format($stats['total_stock_items'] ?? 0); ?></h2>
                        <small>Items in stock</small>
                    </div>
                </div>
            </div>
            <div class="col-md-2 mb-3">
                <div class="card inventory-card bg-warning text-white">
                    <div class="card-body">
                        <h6 class="card-subtitle">Low Stock</h6>
                        <h2 class="card-title"><?php echo $low_stock_count; ?></h2>
                        <small>Need replenishment</small>
                    </div>
                </div>
            </div>
            <div class="col-md-2 mb-3">
                <div class="card inventory-card bg-danger text-white">
                    <div class="card-body">
                        <h6 class="card-subtitle">Critical Expiry</h6>
                        <h2 class="card-title"><?php echo $expiring_count; ?></h2>
                        <small>Expiring in 30 days</small>
                    </div>
                </div>
            </div>
            <div class="col-md-2 mb-3">
                <div class="card inventory-card bg-info text-white">
                    <div class="card-body">
                        <h6 class="card-subtitle">Active Batches</h6>
                        <h2 class="card-title"><?php echo $stats['active_batches'] ?? 0; ?></h2>
                        <small>Released batches</small>
                    </div>
                </div>
            </div>
            <div class="col-md-2 mb-3">
                <div class="card inventory-card bg-secondary text-white">
                    <div class="card-body">
                        <h6 class="card-subtitle">Pending Orders</h6>
                        <h2 class="card-title"><?php echo $stats['pending_orders'] ?? 0; ?></h2>
                        <small>To be processed</small>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- FILTERS -->
        <div class="card mb-4">
            <div class="card-body">
                <h5 class="card-title mb-3">🔍 Filter Inventory</h5>
                <form method="GET" action="">
                    <div class="row g-3">
                        <div class="col-md-3">
                            <input type="text" name="search" class="form-control" 
                                   placeholder="Search product or SKU..." 
                                   value="<?php echo htmlspecialchars($search); ?>">
                        </div>
                        <div class="col-md-2">
                            <select name="category" class="form-select">
                                <option value="">All Categories</option>
                                <?php 
                                mysqli_data_seek($categories_result, 0);
                                while($cat = mysqli_fetch_assoc($categories_result)): 
                                ?>
                                <option value="<?php echo $cat['id']; ?>" 
                                    <?php echo ($category == $cat['id']) ? 'selected' : ''; ?>>
                                    <?php echo $cat['name']; ?>
                                </option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <select name="stock_level" class="form-select">
                                <option value="">All Stock Levels</option>
                                <option value="low" <?php echo ($stock_level == 'low') ? 'selected' : ''; ?>>Low Stock</option>
                                <option value="out" <?php echo ($stock_level == 'out') ? 'selected' : ''; ?>>Out of Stock</option>
                                <option value="good" <?php echo ($stock_level == 'good') ? 'selected' : ''; ?>>Good Stock</option>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <input type="number" name="min_stock" class="form-control" 
                                   placeholder="Min stock" 
                                   value="<?php echo isset($_GET['min_stock']) ? $_GET['min_stock'] : ''; ?>">
                        </div>
                        <div class="col-md-3 d-flex">
                            <button type="submit" class="btn btn-primary me-2">
                                <i class="fas fa-search"></i> Search
                            </button>
                            <a href="index.php" class="btn btn-secondary">
                                <i class="fas fa-redo"></i> Reset
                            </a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- INVENTORY TABLE -->
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0">📋 Product Inventory</h5>
                <div>
                    <span class="badge bg-primary">Page <?php echo $page; ?> of <?php echo $total_pages; ?></span>
                    <span class="badge bg-info ms-2">Showing <?php echo ($offset + 1); ?>-<?php echo min($offset + $limit, $total_items); ?> of <?php echo $total_items; ?></span>
                </div>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Product</th>
                                <th>SKU</th>
                                <th>Category</th>
                                <th>Brand</th>
                                <th>Current Stock</th>
                                <th>Min/Max</th>
                                <th>Status</th>
                                <th>Last Updated</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(mysqli_num_rows($result) > 0): ?>
                                <?php while($row = mysqli_fetch_assoc($result)): 
                                    $stock = (int)$row['total_stock'];
                                    $min_stock = (int)$row['min_stock'];
                                    $max_stock = (int)$row['max_stock'];
                                    
                                    // Determine stock status
                                    if($stock == 0) {
                                        $status_class = 'stock-out';
                                        $status_text = 'Out of Stock';
                                        $status_color = 'text-muted';
                                        $status_badge = 'danger';
                                    } elseif($stock <= $min_stock) {
                                        $status_class = 'stock-low';
                                        $status_text = 'Low Stock';
                                        $status_color = 'text-danger';
                                        $status_badge = 'warning';
                                    } elseif($stock >= $max_stock) {
                                        $status_class = 'stock-medium';
                                        $status_text = 'Over Stock';
                                        $status_color = 'text-warning';
                                        $status_badge = 'info';
                                    } elseif($stock <= ($min_stock + 10)) {
                                        $status_class = 'stock-medium';
                                        $status_text = 'Medium';
                                        $status_color = 'text-warning';
                                        $status_badge = 'secondary';
                                    } else {
                                        $status_class = 'stock-high';
                                        $status_text = 'Good';
                                        $status_color = 'text-success';
                                        $status_badge = 'success';
                                    }
                                ?>
                                <tr>
                                    <td>
                                        <strong><?php echo htmlspecialchars($row['name']); ?></strong><br>
                                        <small class="text-muted">ID: <?php echo $row['id']; ?></small>
                                    </td>
                                    <td>
                                        <code><?php echo $row['sku']; ?></code>
                                    </td>
                                    <td><?php echo $row['category_name']; ?></td>
                                    <td>
                                        <span class="brand-badge"><?php echo $row['brand_name']; ?></span>
                                    </td>
                                    <td>
                                        <strong class="<?php echo $status_color; ?>" style="font-size: 16px;">
                                            <?php echo number_format($stock); ?>
                                        </strong>
                                    </td>
                                    <td>
                                        <small>Min: <?php echo $min_stock; ?></small><br>
                                        <small>Max: <?php echo $max_stock; ?></small>
                                    </td>
                                    <td>
                                        <span class="stock-indicator <?php echo $status_class; ?>"></span>
                                        <span class="badge bg-<?php echo $status_badge; ?>">
                                            <?php echo $status_text; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php echo date('Y-m-d', strtotime($row['last_updated'])); ?><br>
                                        <small class="text-muted"><?php echo date('H:i', strtotime($row['last_updated'])); ?></small>
                                    </td>
                                    <td>
                                        <div class="btn-group btn-group-sm">
                                            <a href="../products/view.php?id=<?php echo $row['id']; ?>" 
                                               class="btn btn-info" title="View Product">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                            <a href="adjust.php?product_id=<?php echo $row['id']; ?>" 
                                               class="btn btn-warning" title="Adjust Stock">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <a href="../orders/create.php?product_id=<?php echo $row['id']; ?>" 
                                               class="btn btn-primary" title="Create Order">
                                                <i class="fas fa-cart-plus"></i>
                                            </a>
                                            <?php if($stock <= $min_stock): ?>
                                            <a href="../purchasing/create.php?product_id=<?php echo $row['id']; ?>" 
                                               class="btn btn-danger" title="Reorder">
                                                <i class="fas fa-shopping-cart"></i>
                                            </a>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="9" class="text-center py-4">
                                        <div class="text-muted">
                                            <i class="fas fa-box-open fa-3x mb-3"></i><br>
                                            <h5>No products found</h5>
                                            <p>Try adjusting your search filters</p>
                                        </div>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                
                <!-- PAGINATION -->
                <?php if($total_pages > 1): ?>
                <nav aria-label="Page navigation">
                    <ul class="pagination justify-content-center mt-4">
                        <!-- First Page -->
                        <li class="page-item <?php echo ($page <= 1) ? 'disabled' : ''; ?>">
                            <a class="page-link" href="?page=1&search=<?php echo urlencode($search); ?>&category=<?php echo $category; ?>&stock_level=<?php echo $stock_level; ?>">
                                <i class="fas fa-angle-double-left"></i>
                            </a>
                        </li>
                        
                        <!-- Previous -->
                        <li class="page-item <?php echo ($page <= 1) ? 'disabled' : ''; ?>">
                            <a class="page-link" 
                               href="?page=<?php echo $page-1; ?>&search=<?php echo urlencode($search); ?>&category=<?php echo $category; ?>&stock_level=<?php echo $stock_level; ?>">
                                <i class="fas fa-angle-left"></i>
                            </a>
                        </li>
                        
                        <!-- Page Numbers -->
                        <?php 
                        $start_page = max(1, $page - 2);
                        $end_page = min($total_pages, $page + 2);
                        
                        if($start_page > 1) {
                            echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
                        }
                        
                        for($i = $start_page; $i <= $end_page; $i++): 
                        ?>
                            <li class="page-item <?php echo ($i == $page) ? 'active' : ''; ?>">
                                <a class="page-link" 
                                   href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>&category=<?php echo $category; ?>&stock_level=<?php echo $stock_level; ?>">
                                    <?php echo $i; ?>
                                </a>
                            </li>
                        <?php endfor; 
                        
                        if($end_page < $total_pages) {
                            echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
                        }
                        ?>
                        
                        <!-- Next -->
                        <li class="page-item <?php echo ($page >= $total_pages) ? 'disabled' : ''; ?>">
                            <a class="page-link" 
                               href="?page=<?php echo $page+1; ?>&search=<?php echo urlencode($search); ?>&category=<?php echo $category; ?>&stock_level=<?php echo $stock_level; ?>">
                                <i class="fas fa-angle-right"></i>
                            </a>
                        </li>
                        
                        <!-- Last Page -->
                        <li class="page-item <?php echo ($page >= $total_pages) ? 'disabled' : ''; ?>">
                            <a class="page-link" href="?page=<?php echo $total_pages; ?>&search=<?php echo urlencode($search); ?>&category=<?php echo $category; ?>&stock_level=<?php echo $stock_level; ?>">
                                <i class="fas fa-angle-double-right"></i>
                            </a>
                        </li>
                    </ul>
                </nav>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- QUICK ACTIONS -->
        <div class="row mt-4">
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header">
                        <h6 class="mb-0"><i class="fas fa-bolt"></i> Quick Actions</h6>
                    </div>
                    <div class="card-body">
                        <a href="report.php" class="btn btn-outline-primary w-100 mb-2">
                            <i class="fas fa-chart-bar"></i> Stock Report
                        </a>
                        <a href="expiry_report.php" class="btn btn-outline-warning w-100 mb-2">
                            <i class="fas fa-calendar-times"></i> Expiry Report
                        </a>
                        <a href="low_stock.php" class="btn btn-outline-danger w-100">
                            <i class="fas fa-exclamation-triangle"></i> Low Stock Alert
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <h6 class="mb-0"><i class="fas fa-info-circle"></i> Inventory Summary</h6>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <small class="text-muted">Total Products:</small>
                                <h5><?php echo $stats['total_products'] ?? 0; ?> products</h5>
                                
                                <small class="text-muted">Total Stock Value:</small>
                                <h5>Rp <?php echo number_format($total_value, 0, ',', '.'); ?></h5>
                            </div>
                            <div class="col-md-6">
                                <small class="text-muted">Stock Distribution:</small>
                                <div class="progress mb-1" style="height: 20px;">
                                    <div class="progress-bar bg-success" style="width: <?php echo $good_percentage; ?>%">Good Stock</div>
                                    <div class="progress-bar bg-warning" style="width: <?php echo $low_percentage; ?>%">Low Stock</div>
                                    <div class="progress-bar bg-danger" style="width: <?php echo $out_percentage; ?>%">Out of Stock</div>
                                </div>
                                <small class="text-muted">Last updated: <?php echo date('Y-m-d H:i:s'); ?></small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Auto-refresh every 5 minutes
        setTimeout(function() {
            window.location.reload();
        }, 300000);
        
        // Export confirmation
        document.querySelector('a[href="report.php"]')?.addEventListener('click', function(e) {
            if(!confirm('Generate inventory report?')) {
                e.preventDefault();
            }
        });
    </script>
</body>
</html>