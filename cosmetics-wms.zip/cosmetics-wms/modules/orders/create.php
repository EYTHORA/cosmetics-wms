<?php

$root_path = dirname(dirname(dirname(__FILE__))) . '/';
require_once $root_path . 'includes/config.php';
require_once $root_path . 'includes/auth.php';
checkLogin();

$active_menu = 'orders';
$page_title = "Create New Order";
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cosmetics WMS - Create Order</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <style>
        body { background: #f8f9fa; }
        .main-content { margin-left: 250px; padding: 25px; }
        .order-card {
            background: white;
            border-radius: 10px;
            padding: 25px;
            margin-bottom: 20px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.08);
        }
        .order-step {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: #e9ecef;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            margin-right: 10px;
        }
        .order-step.active {
            background: #3498db;
            color: white;
        }
        .order-step.completed {
            background: #27ae60;
            color: white;
        }
        .product-item {
            border: 1px solid #e9ecef;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 10px;
            transition: all 0.3s;
        }
        .product-item:hover {
            border-color: #3498db;
            background: #f8f9fa;
        }
    </style>
</head>
<body>
    <?php include $root_path . 'includes/sidebar.php'; ?>
    
    <div class="main-content">
        <!-- HEADER -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h3 class="mb-1">🛒 Create New Order</h3>
                <p class="text-muted mb-0">Process customer order</p>
            </div>
            <div>
                <a href="index.php" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Back to Orders
                </a>
            </div>
        </div>
        
        <!-- ORDER STEPS -->
        <div class="order-card mb-4">
            <div class="d-flex align-items-center mb-4">
                <div class="order-step completed">1</div>
                <div>
                    <h5 class="mb-0">Customer Details</h5>
                    <small class="text-muted">Completed</small>
                </div>
            </div>
            <div class="d-flex align-items-center mb-4">
                <div class="order-step active">2</div>
                <div>
                    <h5 class="mb-0">Order Items</h5>
                    <small class="text-muted">Add products to order</small>
                </div>
            </div>
            <div class="d-flex align-items-center">
                <div class="order-step">3</div>
                <div>
                    <h5 class="mb-0">Review & Confirm</h5>
                    <small class="text-muted">Finalize order</small>
                </div>
            </div>
        </div>
        
        <!-- ORDER FORM -->
        <div class="order-card">
            <h4 class="mb-4">Add Order Items</h4>
            
            <!-- CUSTOMER INFO -->
            <div class="row mb-4">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label class="form-label">Order Number</label>
                        <input type="text" class="form-control" value="ORD-<?php echo date('Ymd-His'); ?>" readonly>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="mb-3">
                        <label class="form-label">Order Date</label>
                        <input type="text" class="form-control" value="<?php echo date('F j, Y'); ?>" readonly>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="mb-3">
                        <label class="form-label">Customer Name</label>
                        <input type="text" class="form-control" placeholder="Enter customer name">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="mb-3">
                        <label class="form-label">Customer Phone</label>
                        <input type="text" class="form-control" placeholder="Enter phone number">
                    </div>
                </div>
                <div class="col-12">
                    <div class="mb-3">
                        <label class="form-label">Delivery Address</label>
                        <textarea class="form-control" rows="2" placeholder="Enter delivery address"></textarea>
                    </div>
                </div>
            </div>
            
            <!-- ADD PRODUCTS -->
            <h5 class="mb-3">Products</h5>
            <div class="row mb-3">
                <div class="col-md-4">
                    <select class="form-select">
                        <option>Select Product</option>
                        <option>Wardah Lip Cream Matte - LIP001</option>
                        <option>Make Over Foundation - FND001</option>
                        <option>ESOA Moisturizing Lipstick - LIP002</option>
                        <option>Wardah Lightening Foundation - FND002</option>
                    </select>
                </div>
                <div class="col-md-2">
                    <input type="number" class="form-control" placeholder="Qty" value="1" min="1">
                </div>
                <div class="col-md-4">
                    <input type="text" class="form-control" placeholder="Notes (optional)">
                </div>
                <div class="col-md-2">
                    <button class="btn btn-primary w-100">
                        <i class="fas fa-plus"></i> Add
                    </button>
                </div>
            </div>
            
            <!-- ORDER ITEMS TABLE -->
            <div class="table-responsive mb-4">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Product</th>
                            <th>SKU</th>
                            <th>Unit Price</th>
                            <th>Quantity</th>
                            <th>Subtotal</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>
                                <strong>Wardah Lip Cream Matte</strong><br>
                                <small class="text-muted">Red Velvet</small>
                            </td>
                            <td>LIP001</td>
                            <td>Rp 75,000</td>
                            <td>
                                <input type="number" class="form-control form-control-sm" value="10" style="width: 80px;">
                            </td>
                            <td><strong>Rp 750,000</strong></td>
                            <td>
                                <button class="btn btn-sm btn-danger">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <strong>Make Over Foundation</strong><br>
                                <small class="text-muted">Natural Beige</small>
                            </td>
                            <td>FND001</td>
                            <td>Rp 120,000</td>
                            <td>
                                <input type="number" class="form-control form-control-sm" value="5" style="width: 80px;">
                            </td>
                            <td><strong>Rp 600,000</strong></td>
                            <td>
                                <button class="btn btn-sm btn-danger">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            
            <!-- ORDER SUMMARY -->
            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label class="form-label">Order Notes</label>
                        <textarea class="form-control" rows="3" placeholder="Special instructions..."></textarea>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Payment Method</label>
                        <select class="form-select">
                            <option>Bank Transfer</option>
                            <option>Cash on Delivery</option>
                            <option>Credit Card</option>
                            <option>E-Wallet</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="order-summary p-3" style="background: #f8f9fa; border-radius: 8px;">
                        <h5 class="mb-3">Order Summary</h5>
                        <table class="table table-sm">
                            <tr>
                                <td>Subtotal</td>
                                <td class="text-end">Rp 1,350,000</td>
                            </tr>
                            <tr>
                                <td>Shipping</td>
                                <td class="text-end">Rp 25,000</td>
                            </tr>
                            <tr>
                                <td>Tax (10%)</td>
                                <td class="text-end">Rp 135,000</td>
                            </tr>
                            <tr class="table-active">
                                <th>Total</th>
                                <th class="text-end">Rp 1,510,000</th>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
            
            <!-- FORM ACTIONS -->
            <div class="d-flex justify-content-between mt-4">
                <button class="btn btn-secondary">
                    <i class="fas fa-save"></i> Save Draft
                </button>
                <div>
                    <a href="index.php" class="btn btn-outline-danger me-2">Cancel</a>
                    <button class="btn btn-success">
                        <i class="fas fa-check"></i> Create Order
                    </button>
                </div>
            </div>
        </div>
    </div>
    
    <!-- SCRIPTS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Calculate order total
        function calculateTotal() {
            let subtotal = 1350000; // Hardcoded for demo
            let shipping = 25000;
            let tax = subtotal * 0.1;
            let total = subtotal + shipping + tax;
            
            // Format to IDR
            document.querySelector('.order-summary tr:nth-child(1) td:last-child').textContent = 
                'Rp ' + subtotal.toLocaleString('id-ID');
            document.querySelector('.order-summary tr:nth-child(3) td:last-child').textContent = 
                'Rp ' + tax.toLocaleString('id-ID');
            document.querySelector('.order-summary tr:last-child th:last-child').textContent = 
                'Rp ' + total.toLocaleString('id-ID');
        }
        
        // Update quantity and recalculate
        document.querySelectorAll('input[type="number"]').forEach(input => {
            input.addEventListener('change', calculateTotal);
        });
        
        calculateTotal(); // Initial calculation
    </script>
</body>
</html>