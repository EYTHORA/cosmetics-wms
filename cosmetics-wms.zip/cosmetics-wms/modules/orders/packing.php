<?php
// modules/orders/packing.php
$root_path = dirname(dirname(dirname(__FILE__))) . '/';
require_once $root_path . 'includes/config.php';
require_once $root_path . 'includes/auth.php';
checkLogin();

$active_menu = 'orders';
$page_title = "Order Packing";

// Handle packing action
if(isset($_POST['pack_order'])) {
    $order_id = (int)$_POST['order_id'];
    $packed_by = $_SESSION['user_id'];
    
    // Update order status to packed
    $sql = "UPDATE orders SET status = 'packed', packed_by = $packed_by, packed_at = NOW() WHERE id = $order_id";
    mysqli_query($conn, $sql);
    
    // Log activity
    $log_sql = "INSERT INTO activity_logs (user_id, action, details) 
                VALUES ($packed_by, 'PACK_ORDER', 'Packed order #$order_id')";
    mysqli_query($conn, $log_sql);
    
    header("Location: packing.php?success=1");
    exit();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cosmetics WMS - Order Packing</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <style>
        .packing-card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.08);
            margin-bottom: 20px;
            transition: all 0.3s;
        }
        
        .packing-card:hover {
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        .status-badge {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
        }
        
        .item-checklist {
            padding: 10px;
            border: 1px solid #e9ecef;
            border-radius: 5px;
            margin-bottom: 5px;
        }
    </style>
</head>
<body>
    <?php include $root_path . 'includes/sidebar.php'; ?>
    
    <div class="main-content" style="margin-left: 250px; padding: 25px;">
        <!-- HEADER -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h3 class="mb-1">📦 Order Packing</h3>
                <p class="text-muted mb-0">Prepare orders for shipping</p>
            </div>
            <div>
                <a href="index.php" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Back to Orders
                </a>
            </div>
        </div>
        
        <?php if(isset($_GET['success'])): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <i class="fas fa-check-circle"></i> Order packed successfully!
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>
        
        <!-- PACKING TABS -->
        <ul class="nav nav-tabs mb-4" id="packingTab">
            <li class="nav-item">
                <a class="nav-link active" data-bs-toggle="tab" href="#pending">Pending Packing</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-bs-toggle="tab" href="#inprogress">In Progress</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-bs-toggle="tab" href="#completed">Completed</a>
            </li>
        </ul>
        
        <div class="tab-content">
            <!-- PENDING PACKING -->
            <div class="tab-pane fade show active" id="pending">
                <div class="row">
                    <?php
                    // Get orders ready for packing (status = 'processing')
                    $sql = "SELECT o.*, c.name as customer_name 
                            FROM orders o
                            LEFT JOIN customers c ON o.customer_id = c.id
                            WHERE o.status = 'processing'
                            ORDER BY o.order_date ASC
                            LIMIT 6";
                    $result = mysqli_query($conn, $sql);
                    
                    while($order = mysqli_fetch_assoc($result)):
                    ?>
                    <div class="col-md-6 mb-3">
                        <div class="packing-card">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-start mb-3">
                                    <div>
                                        <h5 class="card-title mb-1"><?php echo $order['order_number']; ?></h5>
                                        <p class="card-text text-muted mb-0">
                                            <i class="fas fa-user"></i> <?php echo $order['customer_name']; ?>
                                        </p>
                                    </div>
                                    <span class="status-badge bg-warning text-white">Ready to Pack</span>
                                </div>
                                
                                <div class="mb-3">
                                    <small class="text-muted">Order Date:</small>
                                    <p class="mb-1"><?php echo date('M d, Y', strtotime($order['order_date'])); ?></p>
                                    
                                    <small class="text-muted">Items:</small>
                                    <?php
                                    // Get order items
                                    $items_sql = "SELECT oi.*, p.name as product_name 
                                                 FROM order_items oi
                                                 JOIN products p ON oi.product_id = p.id
                                                 WHERE oi.order_id = " . $order['id'];
                                    $items_result = mysqli_query($conn, $items_sql);
                                    ?>
                                    <div class="mt-2">
                                        <?php while($item = mysqli_fetch_assoc($items_result)): ?>
                                        <div class="item-checklist">
                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" 
                                                       id="item_<?php echo $item['id']; ?>">
                                                <label class="form-check-label" for="item_<?php echo $item['id']; ?>">
                                                    <?php echo $item['product_name']; ?> 
                                                    <span class="badge bg-secondary">x<?php echo $item['quantity']; ?></span>
                                                </label>
                                            </div>
                                        </div>
                                        <?php endwhile; ?>
                                    </div>
                                </div>
                                
                                <form method="POST" action="">
                                    <input type="hidden" name="order_id" value="<?php echo $order['id']; ?>">
                                    <div class="d-flex justify-content-between">
                                        <a href="packing_list.php?order_id=<?php echo $order['id']; ?>" 
                                           class="btn btn-info btn-sm">
                                            <i class="fas fa-list"></i> Packing List
                                        </a>
                                        <button type="submit" name="pack_order" class="btn btn-success btn-sm">
                                            <i class="fas fa-check"></i> Mark as Packed
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <?php endwhile; ?>
                    
                    <?php if(mysqli_num_rows($result) == 0): ?>
                    <div class="col-12">
                        <div class="alert alert-info">
                            <i class="fas fa-info-circle"></i> No orders pending for packing.
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- IN PROGRESS -->
            <div class="tab-pane fade" id="inprogress">
                <div class="row">
                    <?php
                    // Get orders in packing (status = 'packing')
                    $sql = "SELECT o.*, c.name as customer_name, u.username as packed_by_name
                            FROM orders o
                            LEFT JOIN customers c ON o.customer_id = c.id
                            LEFT JOIN users u ON o.packed_by = u.id
                            WHERE o.status = 'packing'
                            ORDER BY o.updated_at DESC";
                    $result = mysqli_query($conn, $sql);
                    
                    while($order = mysqli_fetch_assoc($result)):
                    ?>
                    <div class="col-md-6 mb-3">
                        <div class="packing-card">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-start mb-3">
                                    <div>
                                        <h5 class="card-title mb-1"><?php echo $order['order_number']; ?></h5>
                                        <p class="card-text text-muted mb-0">
                                            <i class="fas fa-user"></i> <?php echo $order['customer_name']; ?>
                                        </p>
                                    </div>
                                    <span class="status-badge bg-primary text-white">Packing</span>
                                </div>
                                
                                <div class="mb-3">
                                    <small class="text-muted">Packed by:</small>
                                    <p class="mb-1"><?php echo $order['packed_by_name'] ?? 'N/A'; ?></p>
                                    
                                    <small class="text-muted">Started at:</small>
                                    <p class="mb-1"><?php echo $order['packed_at'] ? date('M d, Y H:i', strtotime($order['packed_at'])) : 'N/A'; ?></p>
                                </div>
                                
                                <div class="d-flex justify-content-between">
                                    <a href="packing_list.php?order_id=<?php echo $order['id']; ?>" 
                                       class="btn btn-info btn-sm">
                                        <i class="fas fa-list"></i> View Packing List
                                    </a>
                                    <a href="shipping.php?order_id=<?php echo $order['id']; ?>" 
                                       class="btn btn-success btn-sm">
                                        <i class="fas fa-truck"></i> Ready to Ship
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endwhile; ?>
                </div>
            </div>
            
            <!-- COMPLETED -->
            <div class="tab-pane fade" id="completed">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Recently Packed Orders</h5>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Order #</th>
                                        <th>Customer</th>
                                        <th>Packed By</th>
                                        <th>Packed Date</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $sql = "SELECT o.*, c.name as customer_name, u.username as packed_by_name
                                            FROM orders o
                                            LEFT JOIN customers c ON o.customer_id = c.id
                                            LEFT JOIN users u ON o.packed_by = u.id
                                            WHERE o.status IN ('packed', 'shipped')
                                            ORDER BY o.packed_at DESC
                                            LIMIT 10";
                                    $result = mysqli_query($conn, $sql);
                                    
                                    while($order = mysqli_fetch_assoc($result)):
                                    ?>
                                    <tr>
                                        <td><?php echo $order['order_number']; ?></td>
                                        <td><?php echo $order['customer_name']; ?></td>
                                        <td><?php echo $order['packed_by_name']; ?></td>
                                        <td><?php echo date('M d, Y', strtotime($order['packed_at'])); ?></td>
                                        <td>
                                            <?php if($order['status'] == 'packed'): ?>
                                            <span class="badge bg-success">Packed</span>
                                            <?php else: ?>
                                            <span class="badge bg-info">Shipped</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <a href="packing_list.php?order_id=<?php echo $order['id']; ?>" 
                                               class="btn btn-sm btn-info">
                                                <i class="fas fa-eye"></i> View
                                            </a>
                                        </td>
                                    </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- SCRIPTS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Initialize tabs
        var tabEls = document.querySelectorAll('#packingTab a')
        tabEls.forEach(function(tabEl) {
            tabEl.addEventListener('click', function (e) {
                e.preventDefault()
                var tab = new bootstrap.Tab(this)
                tab.show()
            })
        })
        
        // Check all items
        function checkAllItems(orderId) {
            const checkboxes = document.querySelectorAll('#order-' + orderId + ' input[type="checkbox"]');
            checkboxes.forEach(checkbox => {
                checkbox.checked = true;
            });
        }
    </script>
</body>
</html>