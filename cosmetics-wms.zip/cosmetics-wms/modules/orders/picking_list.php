<?php
// modules/orders/picking_list.php
$root_path = dirname(dirname(dirname(__FILE__))) . '/';
require_once $root_path . 'includes/config.php';
require_once $root_path . 'includes/auth.php';
checkLogin();

$active_menu = 'orders';

// Get order ID
$order_id = isset($_GET['order_id']) ? (int)$_GET['order_id'] : 0;
if(!$order_id) {
    header("Location: index.php");
    exit();
}

// Get order details
$sql = "SELECT o.*, c.name as customer_name
        FROM orders o
        LEFT JOIN customers c ON o.customer_id = c.id
        WHERE o.id = $order_id";
$result = mysqli_query($conn, $sql);
$order = mysqli_fetch_assoc($result);

if(!$order) {
    echo "Order not found!";
    exit();
}

// Get order items with location info
$items_sql = "SELECT oi.*, p.name as product_name, p.sku, 
                     pb.batch_number, pb.location_id, wl.name as location_name,
                     pb.current_quantity as available_stock
              FROM order_items oi
              JOIN products p ON oi.product_id = p.id
              LEFT JOIN product_batches pb ON p.id = pb.product_id AND pb.status = 'released'
              LEFT JOIN warehouse_locations wl ON pb.location_id = wl.id
              WHERE oi.order_id = $order_id
              GROUP BY oi.id, pb.id";
$items_result = mysqli_query($conn, $items_sql);

// Update order status to processing
if($order['status'] == 'pending') {
    $update_sql = "UPDATE orders SET status = 'processing' WHERE id = $order_id";
    mysqli_query($conn, $update_sql);
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Picking List - <?php echo $order['order_number']; ?></title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <style>
        @media print {
            .no-print { display: none !important; }
            body { font-size: 12px; }
            .container { width: 100% !important; }
        }
        
        .picking-header {
            border-bottom: 3px solid #333;
            padding-bottom: 20px;
            margin-bottom: 20px;
        }
        
        .location-badge {
            background: #e9ecef;
            color: #495057;
            padding: 3px 8px;
            border-radius: 4px;
            font-size: 11px;
        }
        
        .picking-item {
            border: 1px solid #dee2e6;
            border-radius: 5px;
            padding: 10px;
            margin-bottom: 10px;
        }
        
        .barcode {
            font-family: monospace;
            font-size: 16px;
            letter-spacing: 2px;
            background: #f8f9fa;
            padding: 5px 10px;
            border-radius: 4px;
        }
    </style>
</head>
<body>
    <div class="container mt-4 mb-5">
        <!-- PRINT BUTTON -->
        <div class="no-print mb-4">
            <button onclick="window.print()" class="btn btn-primary">
                <i class="fas fa-print"></i> Print Picking List
            </button>
            <a href="packing.php?order_id=<?php echo $order_id; ?>" class="btn btn-success">
                <i class="fas fa-box"></i> Proceed to Packing
            </a>
            <a href="index.php" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i> Back to Orders
            </a>
        </div>
        
        <!-- PICKING LIST HEADER -->
        <div class="picking-header">
            <div class="row">
                <div class="col-7">
                    <h1 class="mb-2">PICKING LIST</h1>
                    <p class="mb-1"><strong>Order #:</strong> <?php echo $order['order_number']; ?></p>
                    <p class="mb-1"><strong>Customer:</strong> <?php echo $order['customer_name']; ?></p>
                    <p class="mb-0"><strong>Date:</strong> <?php echo date('F j, Y'); ?></p>
                </div>
                <div class="col-5 text-end">
                    <div class="barcode mb-2"><?php echo 'PICK-' . str_pad($order_id, 6, '0', STR_PAD_LEFT); ?></div>
                    <div class="alert alert-info p-2">
                        <i class="fas fa-info-circle"></i> 
                        <strong>Priority:</strong> <?php echo ($order['total_amount'] > 5000000) ? 'HIGH' : 'STANDARD'; ?>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- PICKING INSTRUCTIONS -->
        <div class="alert alert-warning mb-4">
            <h5 class="alert-heading"><i class="fas fa-clipboard-check"></i> Picking Instructions</h5>
            <ol class="mb-0">
                <li>Pick items in the order listed below</li>
                <li>Check expiry dates before picking</li>
                <li>Use FIFO (First In, First Out) method</li>
                <li>Verify SKU and quantity match</li>
                <li>Mark as picked when complete</li>
            </ol>
        </div>
        
        <!-- ITEMS TO PICK -->
        <h4 class="mb-3">Items to Pick</h4>
        <?php 
        $item_counter = 1;
        while($item = mysqli_fetch_assoc($items_result)): 
        ?>
        <div class="picking-item">
            <div class="row align-items-center">
                <div class="col-1 text-center">
                    <h3 class="mb-0 text-muted"><?php echo $item_counter++; ?></h3>
                </div>
                <div class="col-5">
                    <h5 class="mb-1"><?php echo $item['product_name']; ?></h5>
                    <p class="mb-1"><strong>SKU:</strong> <?php echo $item['sku']; ?></p>
                    <p class="mb-0"><strong>Batch:</strong> <?php echo $item['batch_number'] ?? 'N/A'; ?></p>
                </div>
                <div class="col-3">
                    <p class="mb-1"><strong>Location:</strong></p>
                    <span class="location-badge">
                        <i class="fas fa-map-marker-alt"></i> <?php echo $item['location_name'] ?? 'Not Assigned'; ?>
                    </span>
                    <?php if($item['available_stock']): ?>
                    <p class="mb-0 mt-1"><small>Available: <?php echo $item['available_stock']; ?> pcs</small></p>
                    <?php endif; ?>
                </div>
                <div class="col-3">
                    <div class="input-group">
                        <span class="input-group-text">Qty:</span>
                        <input type="number" class="form-control" value="<?php echo $item['quantity']; ?>" readonly>
                        <button class="btn btn-outline-success" type="button" onclick="markPicked(this)">
                            <i class="fas fa-check"></i>
                        </button>
                    </div>
                </div>
            </div>
            
            <!-- SUB ITEMS (BATCHES) -->
            <?php
            // Get available batches for this product
            $batches_sql = "SELECT pb.batch_number, pb.expiry_date, pb.current_quantity, wl.name as location_name
                           FROM product_batches pb
                           LEFT JOIN warehouse_locations wl ON pb.location_id = wl.id
                           WHERE pb.product_id = {$item['product_id']} 
                           AND pb.status = 'released'
                           AND pb.current_quantity > 0
                           ORDER BY pb.expiry_date ASC";
            $batches_result = mysqli_query($conn, $batches_sql);
            
            if(mysqli_num_rows($batches_result) > 0):
            ?>
            <div class="mt-2">
                <small class="text-muted">Available Batches:</small>
                <div class="row mt-1">
                    <?php while($batch = mysqli_fetch_assoc($batches_result)): ?>
                    <div class="col-md-4">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" 
                                   id="batch_<?php echo $batch['batch_number']; ?>">
                            <label class="form-check-label" for="batch_<?php echo $batch['batch_number']; ?>">
                                <?php echo $batch['batch_number']; ?> 
                                (Exp: <?php echo date('M Y', strtotime($batch['expiry_date'])); ?>)
                                - <?php echo $batch['current_quantity']; ?> pcs
                            </label>
                        </div>
                    </div>
                    <?php endwhile; ?>
                </div>
            </div>
            <?php endif; ?>
        </div>
        <?php endwhile; ?>
        
        <!-- PICKER INFO -->
        <div class="row mt-4">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0"><i class="fas fa-user"></i> Picker Information</h5>
                    </div>
                    <div class="card-body">
                        <div class="mb-3">
                            <label class="form-label">Picker Name</label>
                            <input type="text" class="form-control" placeholder="Enter picker name">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Start Time</label>
                            <input type="time" class="form-control" value="<?php echo date('H:i'); ?>">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Notes</label>
                            <textarea class="form-control" rows="2" placeholder="Any notes..."></textarea>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0"><i class="fas fa-clipboard-list"></i> Picking Summary</h5>
                    </div>
                    <div class="card-body">
                        <table class="table table-sm">
                            <tr>
                                <td>Total Items:</td>
                                <td class="text-end"><strong><?php echo $item_counter - 1; ?></strong></td>
                            </tr>
                            <tr>
                                <td>Order Value:</td>
                                <td class="text-end">Rp <?php echo number_format($order['total_amount'], 0, ',', '.'); ?></td>
                            </tr>
                            <tr>
                                <td>Picking Zone:</td>
                                <td class="text-end">Cosmetics Section</td>
                            </tr>
                            <tr>
                                <td>Estimated Time:</td>
                                <td class="text-end">15-20 minutes</td>
                            </tr>
                        </table>
                        
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" id="qualityCheck">
                            <label class="form-check-label" for="qualityCheck">
                                All items checked for quality
                            </label>
                        </div>
                        
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" id="expiryCheck">
                            <label class="form-check-label" for="expiryCheck">
                                Expiry dates verified
                            </label>
                        </div>
                        
                        <button class="btn btn-success w-100" onclick="completePicking()">
                            <i class="fas fa-check-double"></i> Complete Picking
                        </button>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- SIGNATURES -->
        <div class="row mt-5">
            <div class="col-md-4">
                <div class="border p-3 text-center">
                    <p class="mb-2"><strong>Picked By</strong></p>
                    <div style="height: 60px; border-bottom: 1px solid #333;"></div>
                    <p class="mt-2 mb-0">Name & Signature</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="border p-3 text-center">
                    <p class="mb-2"><strong>Checked By</strong></p>
                    <div style="height: 60px; border-bottom: 1px solid #333;"></div>
                    <p class="mt-2 mb-0">Supervisor</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="border p-3 text-center">
                    <p class="mb-2"><strong>Date & Time</strong></p>
                    <div style="height: 60px; border-bottom: 1px solid #333;"></div>
                    <p class="mt-2 mb-0"><?php echo date('Y-m-d H:i'); ?></p>
                </div>
            </div>
        </div>
    </div>
    
    <!-- SCRIPTS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function markPicked(button) {
            const row = button.closest('.picking-item');
            row.style.backgroundColor = '#d4edda';
            button.innerHTML = '<i class="fas fa-check-double"></i>';
            button.classList.remove('btn-outline-success');
            button.classList.add('btn-success');
            button.disabled = true;
        }
        
        function completePicking() {
            if(confirm('Mark picking as complete?')) {
                // Update order status to packed
                fetch('update_status.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        order_id: <?php echo $order_id; ?>,
                        status: 'packed'
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if(data.success) {
                        alert('Picking completed! Redirecting to packing...');
                        window.location.href = 'packing.php?order_id=<?php echo $order_id; ?>';
                    }
                });
            }
        }
        
        // Auto-print if parameter exists
        if(window.location.search.includes('print=true')) {
            window.print();
        }
    </script>
</body>
</html>