<?php
// modules/orders/shipping.php
$root_path = dirname(dirname(dirname(__FILE__))) . '/';
require_once $root_path . 'includes/config.php';
require_once $root_path . 'includes/auth.php';
checkLogin();

$active_menu = 'orders';
$page_title = "Order Shipping";

// Handle shipping action
if(isset($_POST['ship_order'])) {
    $order_id = (int)$_POST['order_id'];
    $tracking_number = mysqli_real_escape_string($conn, $_POST['tracking_number']);
    $shipping_courier = mysqli_real_escape_string($conn, $_POST['shipping_courier']);
    $estimated_delivery = mysqli_real_escape_string($conn, $_POST['estimated_delivery']);
    $shipped_by = $_SESSION['user_id'];
    
    // Update order status to shipped
    $sql = "UPDATE orders SET 
            status = 'shipped',
            tracking_number = '$tracking_number',
            shipping_courier = '$shipping_courier',
            estimated_delivery = '$estimated_delivery',
            shipped_by = $shipped_by,
            shipped_at = NOW()
            WHERE id = $order_id";
    
    if(mysqli_query($conn, $sql)) {
        // Log activity
        $log_sql = "INSERT INTO activity_logs (user_id, action, details) 
                    VALUES ($shipped_by, 'SHIP_ORDER', 'Shipped order #$order_id with tracking: $tracking_number')";
        mysqli_query($conn, $log_sql);
        
        header("Location: shipping.php?success=1");
        exit();
    }
}

// Get orders ready for shipping (status = 'packed')
$sql = "SELECT o.*, c.name as customer_name, c.address, c.phone, u.username as packed_by_name
        FROM orders o
        LEFT JOIN customers c ON o.customer_id = c.id
        LEFT JOIN users u ON o.packed_by = u.id
        WHERE o.status = 'packed'
        ORDER BY o.packed_at ASC";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cosmetics WMS - Order Shipping</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <style>
        .shipping-card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.08);
            margin-bottom: 20px;
        }
        
        .tracking-input {
            font-family: monospace;
            font-size: 16px;
            letter-spacing: 1px;
        }
    </style>
</head>
<body>
    <?php include $root_path . 'includes/sidebar.php'; ?>
    
    <div class="main-content" style="margin-left: 250px; padding: 25px;">
        <!-- HEADER -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h3 class="mb-1">🚚 Order Shipping</h3>
                <p class="text-muted mb-0">Process order shipments</p>
            </div>
            <div>
                <a href="packing.php" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Back to Packing
                </a>
            </div>
        </div>
        
        <?php if(isset($_GET['success'])): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <i class="fas fa-check-circle"></i> Order shipped successfully!
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>
        
        <!-- ORDERS READY FOR SHIPPING -->
        <div class="row">
            <?php if(mysqli_num_rows($result) > 0): ?>
                <?php while($order = mysqli_fetch_assoc($result)): ?>
                <div class="col-md-6 mb-3">
                    <div class="shipping-card">
                        <div class="card-body">
                            <!-- ORDER HEADER -->
                            <div class="d-flex justify-content-between align-items-start mb-3">
                                <div>
                                    <h5 class="card-title mb-1"><?php echo $order['order_number']; ?></h5>
                                    <p class="card-text text-muted mb-0">
                                        <i class="fas fa-user"></i> <?php echo $order['customer_name']; ?>
                                    </p>
                                </div>
                                <span class="badge bg-success">Ready to Ship</span>
                            </div>
                            
                            <!-- CUSTOMER INFO -->
                            <div class="mb-3">
                                <small class="text-muted">Delivery Address:</small>
                                <p class="mb-1"><?php echo $order['address']; ?></p>
                                
                                <small class="text-muted">Contact:</small>
                                <p class="mb-1"><?php echo $order['phone']; ?></p>
                                
                                <small class="text-muted">Packed by:</small>
                                <p class="mb-3"><?php echo $order['packed_by_name']; ?> on <?php echo date('M d, Y', strtotime($order['packed_at'])); ?></p>
                            </div>
                            
                            <!-- SHIPPING FORM -->
                            <form method="POST" action="">
                                <input type="hidden" name="order_id" value="<?php echo $order['id']; ?>">
                                
                                <div class="row g-2 mb-3">
                                    <div class="col-md-6">
                                        <label class="form-label">Shipping Courier</label>
                                        <select name="shipping_courier" class="form-select" required>
                                            <option value="">Select Courier</option>
                                            <option value="JNE">JNE</option>
                                            <option value="TIKI">TIKI</option>
                                            <option value="POS Indonesia">POS Indonesia</option>
                                            <option value="J&T Express">J&T Express</option>
                                            <option value="Sicepat">Sicepat</option>
                                            <option value="Ninja Express">Ninja Express</option>
                                            <option value="GrabExpress">GrabExpress</option>
                                            <option value="GoSend">GoSend</option>
                                            <option value="Lion Parcel">Lion Parcel</option>
                                        </select>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Service Type</label>
                                        <select class="form-select">
                                            <option>REG - Regular</option>
                                            <option>ECO - Economy</option>
                                            <option>YES - Yakin Esok Sampai</option>
                                            <option>ONS - Overnight Service</option>
                                            <option>SDS - Same Day Service</option>
                                        </select>
                                    </div>
                                </div>
                                
                                <div class="row g-2 mb-3">
                                    <div class="col-md-8">
                                        <label class="form-label">Tracking Number</label>
                                        <input type="text" name="tracking_number" class="form-control tracking-input" 
                                               placeholder="Enter tracking number" required>
                                    </div>
                                    <div class="col-md-4">
                                        <label class="form-label">Estimated Delivery</label>
                                        <input type="date" name="estimated_delivery" class="form-control" 
                                               value="<?php echo date('Y-m-d', strtotime('+3 days')); ?>" required>
                                    </div>
                                </div>
                                
                                <div class="mb-3">
                                    <label class="form-label">Shipping Notes</label>
                                    <textarea class="form-control" rows="2" placeholder="Special instructions for delivery..."></textarea>
                                </div>
                                
                                <!-- SHIPPING ITEMS -->
                                <div class="mb-3">
                                    <small class="text-muted">Items to Ship:</small>
                                    <?php
                                    $items_sql = "SELECT oi.quantity, p.name, p.sku
                                                 FROM order_items oi
                                                 JOIN products p ON oi.product_id = p.id
                                                 WHERE oi.order_id = " . $order['id'];
                                    $items_result = mysqli_query($conn, $items_sql);
                                    ?>
                                    <div class="mt-2">
                                        <?php while($item = mysqli_fetch_assoc($items_result)): ?>
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" checked>
                                            <label class="form-check-label">
                                                <?php echo $item['name']; ?> (SKU: <?php echo $item['sku']; ?>)
                                                <span class="badge bg-secondary">x<?php echo $item['quantity']; ?></span>
                                            </label>
                                        </div>
                                        <?php endwhile; ?>
                                    </div>
                                </div>
                                
                                <!-- ACTION BUTTONS -->
                                <div class="d-flex justify-content-between">
                                    <a href="packing_list.php?order_id=<?php echo $order['id']; ?>&print=true" 
                                       class="btn btn-info btn-sm" target="_blank">
                                        <i class="fas fa-print"></i> Print Label
                                    </a>
                                    <button type="submit" name="ship_order" class="btn btn-success">
                                        <i class="fas fa-paper-plane"></i> Confirm Shipment
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div class="col-12">
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle"></i> No orders ready for shipping.
                    </div>
                </div>
            <?php endif; ?>
        </div>
        
        <!-- RECENT SHIPMENTS -->
        <div class="card mt-4">
            <div class="card-header">
                <h5 class="mb-0"><i class="fas fa-history"></i> Recent Shipments</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Order #</th>
                                <th>Customer</th>
                                <th>Courier</th>
                                <th>Tracking #</th>
                                <th>Shipped Date</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $recent_sql = "SELECT o.*, c.name as customer_name, u.username as shipped_by_name
                                           FROM orders o
                                           LEFT JOIN customers c ON o.customer_id = c.id
                                           LEFT JOIN users u ON o.shipped_by = u.id
                                           WHERE o.status = 'shipped'
                                           ORDER BY o.shipped_at DESC
                                           LIMIT 5";
                            $recent_result = mysqli_query($conn, $recent_sql);
                            
                            while($shipment = mysqli_fetch_assoc($recent_result)):
                            ?>
                            <tr>
                                <td><?php echo $shipment['order_number']; ?></td>
                                <td><?php echo $shipment['customer_name']; ?></td>
                                <td><?php echo $shipment['shipping_courier']; ?></td>
                                <td>
                                    <code><?php echo $shipment['tracking_number']; ?></code>
                                    <?php if($shipment['tracking_number']): ?>
                                    <a href="https://tracking.jne.co.id/" target="_blank" class="btn btn-xs btn-link">
                                        <i class="fas fa-external-link-alt"></i>
                                    </a>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo date('M d, Y', strtotime($shipment['shipped_at'])); ?></td>
                                <td>
                                    <span class="badge bg-info">Shipped</span>
                                </td>
                                <td>
                                    <a href="tracking.php?order_id=<?php echo $shipment['id']; ?>" 
                                       class="btn btn-sm btn-info">
                                        <i class="fas fa-search"></i> Track
                                    </a>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <!-- SCRIPTS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Generate random tracking number
        function generateTracking() {
            const prefix = 'JNE';
            const random = Math.floor(Math.random() * 1000000000).toString().padStart(9, '0');
            const tracking = prefix + random + 'ID';
            document.querySelector('input[name="tracking_number"]').value = tracking;
        }
        
        // Auto-fill estimated delivery based on courier
        document.querySelector('select[name="shipping_courier"]').addEventListener('change', function() {
            const courier = this.value;
            let daysToAdd = 3;
            
            if(courier === 'JNE YES') daysToAdd = 1;
            if(courier === 'TIKI ONS') daysToAdd = 1;
            if(courier === 'Sicepat') daysToAdd = 2;
            
            const today = new Date();
            today.setDate(today.getDate() + daysToAdd);
            const formattedDate = today.toISOString().split('T')[0];
            document.querySelector('input[name="estimated_delivery"]').value = formattedDate;
        });
    </script>
</body>
</html>