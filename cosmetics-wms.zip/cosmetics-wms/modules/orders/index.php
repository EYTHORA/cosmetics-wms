<?php
// modules/orders/index.php
$root_path = dirname(dirname(dirname(__FILE__))) . '/';
require_once $root_path . 'includes/config.php';
require_once $root_path . 'includes/auth.php';
checkLogin();

$active_menu = 'orders';
$page_title = "Order Management";

// PAGINATION
$limit = 10;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

// FILTERS
$status = isset($_GET['status']) ? $_GET['status'] : '';
$search = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : '';

// BUILD WHERE CLAUSE
$where = "1=1";
if (!empty($status)) {
    $where .= " AND o.status = '$status'";
}
if (!empty($search)) {
    $where .= " AND (o.order_number LIKE '%$search%' OR c.name LIKE '%$search%')";
}

// GET TOTAL COUNT
$count_sql = "SELECT COUNT(o.id) as total 
              FROM orders o
              LEFT JOIN customers c ON o.customer_id = c.id
              WHERE $where";
$count_result = mysqli_query($conn, $count_sql);
$total_items = mysqli_fetch_assoc($count_result)['total'];
$total_pages = ceil($total_items / $limit);

// GET ORDERS (QUERY YANG BENAR)
$sql = "SELECT o.*, c.name as customer_name, c.phone, 
               COUNT(oi.id) as item_count,
               SUM(oi.quantity * oi.unit_price) as total_amount
        FROM orders o
        LEFT JOIN customers c ON o.customer_id = c.id
        LEFT JOIN order_items oi ON o.id = oi.order_id
        WHERE $where
        GROUP BY o.id
        ORDER BY o.order_date DESC
        LIMIT $limit OFFSET $offset";

$result = mysqli_query($conn, $sql);

// GET STATUS COUNTS
$status_sql = "SELECT 
                COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending,
                COUNT(CASE WHEN status = 'processing' THEN 1 END) as processing,
                COUNT(CASE WHEN status = 'packed' THEN 1 END) as packed,
                COUNT(CASE WHEN status = 'shipped' THEN 1 END) as shipped,
                COUNT(CASE WHEN status = 'delivered' THEN 1 END) as delivered,
                COUNT(CASE WHEN status = 'cancelled' THEN 1 END) as cancelled
               FROM orders";
$status_result = mysqli_query($conn, $status_sql);
$status_counts = mysqli_fetch_assoc($status_result);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cosmetics WMS - Orders</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <style>
        .order-card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.08);
            margin-bottom: 15px;
            transition: all 0.3s;
        }
        
        .order-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        .status-badge {
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
        }
        
        .action-buttons .btn {
            margin: 2px;
        }
    </style>
</head>
<body>
    <?php include $root_path . 'includes/sidebar.php'; ?>
    
    <div class="main-content" style="margin-left: 250px; padding: 25px;">
        <!-- HEADER -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h3 class="mb-1">🛒 Order Management</h3>
                <p class="text-muted mb-0">Manage customer orders</p>
            </div>
            <div>
                <a href="create.php" class="btn btn-primary">
                    <i class="fas fa-plus-circle"></i> New Order
                </a>
            </div>
        </div>
        
        <!-- STATUS CARDS -->
        <div class="row mb-4">
            <div class="col-md-2 mb-2">
                <div class="card bg-primary text-white">
                    <div class="card-body text-center p-3">
                        <h6 class="mb-1">Pending</h6>
                        <h4 class="mb-0"><?php echo $status_counts['pending'] ?? 0; ?></h4>
                    </div>
                </div>
            </div>
            <div class="col-md-2 mb-2">
                <div class="card bg-warning text-white">
                    <div class="card-body text-center p-3">
                        <h6 class="mb-1">Processing</h6>
                        <h4 class="mb-0"><?php echo $status_counts['processing'] ?? 0; ?></h4>
                    </div>
                </div>
            </div>
            <div class="col-md-2 mb-2">
                <div class="card bg-info text-white">
                    <div class="card-body text-center p-3">
                        <h6 class="mb-1">Packed</h6>
                        <h4 class="mb-0"><?php echo $status_counts['packed'] ?? 0; ?></h4>
                    </div>
                </div>
            </div>
            <div class="col-md-2 mb-2">
                <div class="card bg-success text-white">
                    <div class="card-body text-center p-3">
                        <h6 class="mb-1">Shipped</h6>
                        <h4 class="mb-0"><?php echo $status_counts['shipped'] ?? 0; ?></h4>
                    </div>
                </div>
            </div>
            <div class="col-md-2 mb-2">
                <div class="card bg-secondary text-white">
                    <div class="card-body text-center p-3">
                        <h6 class="mb-1">Delivered</h6>
                        <h4 class="mb-0"><?php echo $status_counts['delivered'] ?? 0; ?></h4>
                    </div>
                </div>
            </div>
            <div class="col-md-2 mb-2">
                <div class="card bg-danger text-white">
                    <div class="card-body text-center p-3">
                        <h6 class="mb-1">Cancelled</h6>
                        <h4 class="mb-0"><?php echo $status_counts['cancelled'] ?? 0; ?></h4>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- FILTERS -->
        <div class="card mb-4">
            <div class="card-body">
                <form method="GET" action="">
                    <div class="row g-3">
                        <div class="col-md-4">
                            <input type="text" name="search" class="form-control" 
                                   placeholder="Search order number or customer..." 
                                   value="<?php echo htmlspecialchars($search); ?>">
                        </div>
                        <div class="col-md-3">
                            <select name="status" class="form-select">
                                <option value="">All Status</option>
                                <option value="pending" <?php echo ($status == 'pending') ? 'selected' : ''; ?>>Pending</option>
                                <option value="processing" <?php echo ($status == 'processing') ? 'selected' : ''; ?>>Processing</option>
                                <option value="packed" <?php echo ($status == 'packed') ? 'selected' : ''; ?>>Packed</option>
                                <option value="shipped" <?php echo ($status == 'shipped') ? 'selected' : ''; ?>>Shipped</option>
                                <option value="delivered" <?php echo ($status == 'delivered') ? 'selected' : ''; ?>>Delivered</option>
                                <option value="cancelled" <?php echo ($status == 'cancelled') ? 'selected' : ''; ?>>Cancelled</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <input type="date" name="date" class="form-control" placeholder="From date">
                        </div>
                        <div class="col-md-2">
                            <button type="submit" class="btn btn-primary w-100">
                                <i class="fas fa-search"></i> Filter
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- ORDERS TABLE -->
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0">📋 Recent Orders</h5>
                <div>
                    Showing <?php echo ($offset + 1); ?> - 
                    <?php echo min($offset + $limit, $total_items); ?> of <?php echo $total_items; ?> orders
                </div>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Order #</th>
                                <th>Customer</th>
                                <th>Date</th>
                                <th>Items</th>
                                <th>Amount</th>
                                <th>Status</th>
                                <th>Next Action</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(mysqli_num_rows($result) > 0): ?>
                                <?php while($order = mysqli_fetch_assoc($result)): 
                                    // STATUS MAPPING YANG BENAR
                                    $status_class = '';
                                    $next_action = '';
                                    $next_url = '#';
                                    
                                   // Di dalam while loop, GANTI switch statement menjadi:

switch($order['status']) {
    case 'draft':
        $status_class = 'bg-light text-dark border';
        $next_action = 'Confirm Order';
        $next_url = 'confirm.php?id=' . $order['id'];
        break;
    case 'confirmed':
        $status_class = 'bg-primary';
        $next_action = 'Create Picking';
        $next_url = 'picking.php?id=' . $order['id'];
        break;
    case 'picking':
        $status_class = 'bg-warning text-dark';
        $next_action = 'Process Picking';
        $next_url = 'picking_process.php?id=' . $order['id'];
        break;
    case 'packing':
        $status_class = 'bg-info';
        $next_action = 'Pack Order';
        $next_url = 'packing.php?id=' . $order['id'];
        break;
    case 'shipped':
        $status_class = 'bg-success';
        $next_action = 'Mark Delivered';
        $next_url = 'deliver.php?id=' . $order['id'];
        break;
    case 'delivered':
        $status_class = 'bg-secondary';
        $next_action = 'Complete';
        $next_url = '#';
        break;
    case 'cancelled':
        $status_class = 'bg-danger';
        $next_action = 'View Details';
        $next_url = '#';
        break;
    default:
        $status_class = 'bg-light text-dark border';
        break;
}
                                ?>
                                <tr>
                                    <td><strong><?php echo $order['order_number']; ?></strong></td>
                                    <td>
                                        <?php echo $order['customer_name']; ?><br>
                                        <small class="text-muted"><?php echo $order['phone'] ?? 'N/A'; ?></small>
                                    </td>
                                    <td><?php echo date('M d, Y', strtotime($order['order_date'])); ?></td>
                                    <td><?php echo $order['item_count']; ?> items</td>
                                    <td>Rp <?php echo number_format($order['total_amount'] ?? 0, 0, ',', '.'); ?></td>
                                    <td>
                                        <span class="badge <?php echo $status_class; ?> status-badge">
                                            <?php echo ucfirst($order['status']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php if($next_action && $order['status'] != 'delivered' && $order['status'] != 'cancelled'): ?>
                                        <a href="<?php echo $next_url; ?>" class="btn btn-sm btn-outline-primary">
                                            <?php echo $next_action; ?>
                                        </a>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="action-buttons">
                                            <a href="view.php?id=<?php echo $order['id']; ?>" 
                                               class="btn btn-sm btn-info" title="View">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                            <a href="edit.php?id=<?php echo $order['id']; ?>" 
                                               class="btn btn-sm btn-warning" title="Edit">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <a href="print.php?id=<?php echo $order['id']; ?>" 
                                               class="btn btn-sm btn-secondary" title="Print" target="_blank">
                                                <i class="fas fa-print"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="8" class="text-center py-4">
                                        <div class="text-muted">
                                            <i class="fas fa-shopping-cart fa-2x mb-3"></i><br>
                                            No orders found.
                                        </div>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                
                <!-- PAGINATION -->
                <?php if($total_pages > 1): ?>
                <nav aria-label="Page navigation">
                    <ul class="pagination justify-content-center mt-4">
                        <li class="page-item <?php echo ($page <= 1) ? 'disabled' : ''; ?>">
                            <a class="page-link" 
                               href="?page=<?php echo $page-1; ?>&status=<?php echo $status; ?>&search=<?php echo urlencode($search); ?>">
                                Previous
                            </a>
                        </li>
                        
                        <?php 
                        $start_page = max(1, $page - 2);
                        $end_page = min($total_pages, $page + 2);
                        
                        for($i = $start_page; $i <= $end_page; $i++): 
                        ?>
                            <li class="page-item <?php echo ($i == $page) ? 'active' : ''; ?>">
                                <a class="page-link" 
                                   href="?page=<?php echo $i; ?>&status=<?php echo $status; ?>&search=<?php echo urlencode($search); ?>">
                                    <?php echo $i; ?>
                                </a>
                            </li>
                        <?php endfor; ?>
                        
                        <li class="page-item <?php echo ($page >= $total_pages) ? 'disabled' : ''; ?>">
                            <a class="page-link" 
                               href="?page=<?php echo $page+1; ?>&status=<?php echo $status; ?>&search=<?php echo urlencode($search); ?>">
                                Next
                            </a>
                        </li>
                    </ul>
                </nav>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>