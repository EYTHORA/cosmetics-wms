<?php
// modules/reports/customer_report.php
$root_path = dirname(dirname(dirname(__FILE__))) . '/';
require_once $root_path . 'includes/config.php';
require_once $root_path . 'includes/auth.php';
checkLogin();

$active_menu = 'reports';
$page_title = "Customer Analysis Report";

// SET DEFAULT DATE RANGE (Last 90 days)
$start_date = isset($_GET['start_date']) ? $_GET['start_date'] : date('Y-m-d', strtotime('-90 days'));
$end_date = isset($_GET['end_date']) ? $_GET['end_date'] : date('Y-m-d');
$customer_type = isset($_GET['customer_type']) ? $_GET['customer_type'] : 'all';
$sort_by = isset($_GET['sort_by']) ? $_GET['sort_by'] : 'total_spent';

// VALIDATE DATES
if (!empty($start_date) && !empty($end_date) && $start_date > $end_date) {
    $temp = $start_date;
    $start_date = $end_date;
    $end_date = $temp;
}

// BUILD WHERE CLAUSE
$where_conditions = ["o.order_date BETWEEN '$start_date' AND '$end_date 23:59:59'"];
if ($customer_type != 'all') {
    $where_conditions[] = "c.type = '$customer_type'";
}
$where_clause = !empty($where_conditions) ? "WHERE " . implode(" AND ", $where_conditions) : "";

// BUILD ORDER BY
$order_by_map = [
    'total_spent' => 'total_spent DESC',
    'order_count' => 'order_count DESC',
    'last_order' => 'last_order_date DESC',
    'customer_name' => 'customer_name ASC',
    'avg_order_value' => 'avg_order_value DESC'
];
$order_sql = isset($order_by_map[$sort_by]) ? $order_by_map[$sort_by] : 'total_spent DESC';

// GET CUSTOMER ANALYTICS
$customer_sql = "SELECT 
                    c.id as customer_id,
                    c.customer_code,
                    c.name as customer_name,
                    c.email,
                    c.phone,
                    c.type as customer_type,
                    c.address,
                    c.status as customer_status,
                    c.credit_limit,
                    COUNT(DISTINCT o.id) as order_count,
                    COALESCE(SUM(o.grand_total), 0) as total_spent,
                    COALESCE(AVG(o.grand_total), 0) as avg_order_value,
                    MAX(o.order_date) as last_order_date,
                    GROUP_CONCAT(DISTINCT p.name ORDER BY oi.quantity DESC SEPARATOR ', ') as top_products
                FROM customers c
                LEFT JOIN orders o ON c.id = o.customer_id
                LEFT JOIN order_items oi ON o.id = oi.order_id
                LEFT JOIN products p ON oi.product_id = p.id
                $where_clause
                GROUP BY c.id
                ORDER BY $order_sql
                LIMIT 100";

$customer_result = mysqli_query($conn, $customer_sql);

// GET CUSTOMER TYPE DISTRIBUTION
$type_sql = "SELECT 
                c.type,
                COUNT(DISTINCT c.id) as total_customers,
                COUNT(DISTINCT o.id) as total_orders,
                COALESCE(SUM(o.grand_total), 0) as total_revenue
            FROM customers c
            LEFT JOIN orders o ON c.id = o.customer_id 
                AND o.order_date BETWEEN '$start_date' AND '$end_date 23:59:59'
                AND o.status = 'delivered'
            GROUP BY c.type";

$type_result = mysqli_query($conn, $type_sql);

// GET CUSTOMER ACTIVITY TREND
$activity_sql = "SELECT 
                    DATE(o.order_date) as order_date,
                    COUNT(DISTINCT o.customer_id) as active_customers,
                    COUNT(o.id) as total_orders
                FROM orders o
                WHERE o.order_date BETWEEN '$start_date' AND '$end_date 23:59:59'
                GROUP BY DATE(o.order_date)
                ORDER BY DATE(o.order_date)";

$activity_result = mysqli_query($conn, $activity_sql);

// GET OVERALL STATS
$stats_sql = "SELECT 
                COUNT(DISTINCT c.id) as total_customers,
                COUNT(DISTINCT o.id) as total_orders,
                COALESCE(SUM(o.grand_total), 0) as total_revenue,
                COALESCE(AVG(o.grand_total), 0) as avg_order_value,
                COUNT(DISTINCT CASE WHEN o.order_date >= DATE_SUB('$end_date', INTERVAL 30 DAY) THEN c.id END) as active_30d,
                COUNT(DISTINCT CASE WHEN o.order_date >= DATE_SUB('$end_date', INTERVAL 90 DAY) THEN c.id END) as active_90d
            FROM customers c
            LEFT JOIN orders o ON c.id = o.customer_id 
                AND o.order_date BETWEEN '$start_date' AND '$end_date 23:59:59'
                AND o.status = 'delivered'";

$stats_result = mysqli_query($conn, $stats_sql);
$stats = mysqli_fetch_assoc($stats_result);

// PREPARE DATA FOR CHARTS
$activity_labels = [];
$activity_data = [];
$type_labels = [];
$type_data = [];

// Activity chart data
if(mysqli_num_rows($activity_result) > 0) {
    while($row = mysqli_fetch_assoc($activity_result)) {
        $activity_labels[] = date('M d', strtotime($row['order_date']));
        $activity_data[] = (int)$row['active_customers'];
    }
}

// Type distribution data
if(mysqli_num_rows($type_result) > 0) {
    while($row = mysqli_fetch_assoc($type_result)) {
        $type_labels[] = ucfirst($row['type']);
        $type_data[] = (int)$row['total_customers'];
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cosmetics WMS - Customer Report</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    
    <style>
        .stat-card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.08);
            transition: all 0.3s;
            margin-bottom: 20px;
        }
        
        .stat-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        .stat-icon {
            font-size: 2.5rem;
            opacity: 0.8;
        }
        
        .customer-type-badge {
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 500;
        }
        
        .type-retail { background-color: #e3f2fd; color: #1976d2; }
        .type-distributor { background-color: #e8f5e9; color: #388e3c; }
        .type-reseller { background-color: #fff3e0; color: #f57c00; }
        .type-online_store { background-color: #f3e5f5; color: #7b1fa2; }
        
        .customer-status-active { color: #28a745; font-weight: bold; }
        .customer-status-inactive { color: #dc3545; font-weight: bold; }
        
        .table-hover tbody tr:hover {
            background-color: rgba(0,123,255,0.05);
        }
        
        .chart-container {
            position: relative;
            height: 350px;
            width: 100%;
        }
        
        .avatar-circle {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 18px;
        }
    </style>
</head>
<body>
    <?php include $root_path . 'includes/sidebar.php'; ?>
    
    <div class="main-content" style="margin-left: 250px; padding: 25px;">
        <!-- HEADER -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h3 class="mb-1">👥 Customer Analysis Report</h3>
                <p class="text-muted mb-0">Customer insights and behavior analytics</p>
            </div>
            <div class="d-flex">
                <button onclick="window.print()" class="btn btn-secondary me-2">
                    <i class="fas fa-print"></i> Print
                </button>
                <a href="?<?php echo http_build_query(array_merge($_GET, ['export' => 'csv'])); ?>" 
                   class="btn btn-success">
                    <i class="fas fa-file-csv"></i> Export CSV
                </a>
            </div>
        </div>
        
        <!-- FILTERS -->
        <div class="card mb-4">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0">🔍 Filter Customer Data</h5>
            </div>
            <div class="card-body">
                <form method="GET" action="" class="row g-3">
                    <div class="col-md-3">
                        <label class="form-label">Start Date</label>
                        <input type="date" name="start_date" class="form-control" 
                               value="<?php echo $start_date; ?>" required>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">End Date</label>
                        <input type="date" name="end_date" class="form-control" 
                               value="<?php echo $end_date; ?>" required>
                    </div>
                    <div class="col-md-2">
                        <label class="form-label">Customer Type</label>
                        <select name="customer_type" class="form-select">
                            <option value="all" <?php echo ($customer_type == 'all') ? 'selected' : ''; ?>>All Types</option>
                            <option value="retail" <?php echo ($customer_type == 'retail') ? 'selected' : ''; ?>>Retail</option>
                            <option value="distributor" <?php echo ($customer_type == 'distributor') ? 'selected' : ''; ?>>Distributor</option>
                            <option value="reseller" <?php echo ($customer_type == 'reseller') ? 'selected' : ''; ?>>Reseller</option>
                            <option value="online_store" <?php echo ($customer_type == 'online_store') ? 'selected' : ''; ?>>Online Store</option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <label class="form-label">Sort By</label>
                        <select name="sort_by" class="form-select">
                            <option value="total_spent" <?php echo ($sort_by == 'total_spent') ? 'selected' : ''; ?>>Total Spent</option>
                            <option value="order_count" <?php echo ($sort_by == 'order_count') ? 'selected' : ''; ?>>Order Count</option>
                            <option value="avg_order_value" <?php echo ($sort_by == 'avg_order_value') ? 'selected' : ''; ?>>Avg Order Value</option>
                            <option value="last_order" <?php echo ($sort_by == 'last_order') ? 'selected' : ''; ?>>Last Order Date</option>
                            <option value="customer_name" <?php echo ($sort_by == 'customer_name') ? 'selected' : ''; ?>>Customer Name</option>
                        </select>
                    </div>
                    <div class="col-md-2 d-flex align-items-end">
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="fas fa-filter"></i> Apply Filter
                        </button>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- SUMMARY STATS -->
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="card stat-card border-left-primary">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-1">Total Customers</h6>
                                <h3 class="text-primary mb-0">
                                    <?php echo number_format($stats['total_customers'] ?? 0, 0, ',', '.'); ?>
                                </h3>
                                <small class="text-muted">
                                    <?php echo $stats['active_30d'] ?? 0; ?> active (30d)
                                </small>
                            </div>
                            <div class="stat-icon text-primary">
                                <i class="fas fa-users"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3">
                <div class="card stat-card border-left-success">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-1">Total Revenue</h6>
                                <h3 class="text-success mb-0">
                                    Rp <?php echo number_format($stats['total_revenue'] ?? 0, 0, ',', '.'); ?>
                                </h3>
                                <small class="text-muted">From all customers</small>
                            </div>
                            <div class="stat-icon text-success">
                                <i class="fas fa-money-bill-wave"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3">
                <div class="card stat-card border-left-info">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-1">Total Orders</h6>
                                <h3 class="text-info mb-0">
                                    <?php echo number_format($stats['total_orders'] ?? 0, 0, ',', '.'); ?>
                                </h3>
                                <small class="text-muted">Orders placed</small>
                            </div>
                            <div class="stat-icon text-info">
                                <i class="fas fa-shopping-cart"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3">
                <div class="card stat-card border-left-warning">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-1">Avg. Order Value</h6>
                                <h3 class="text-warning mb-0">
                                    Rp <?php echo number_format($stats['avg_order_value'] ?? 0, 0, ',', '.'); ?>
                                </h3>
                                <small class="text-muted">Per customer</small>
                            </div>
                            <div class="stat-icon text-warning">
                                <i class="fas fa-chart-line"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- CHARTS ROW -->
        <div class="row mb-4">
            <!-- CUSTOMER ACTIVITY CHART -->
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header bg-info text-white">
                        <h5 class="mb-0">📈 Customer Activity Trend</h5>
                    </div>
                    <div class="card-body">
                        <div class="chart-container">
                            <canvas id="activityChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- CUSTOMER TYPE DISTRIBUTION -->
            <div class="col-md-4">
                <div class="card h-100">
                    <div class="card-header bg-success text-white">
                        <h5 class="mb-0">🍰 Customer Type Distribution</h5>
                    </div>
                    <div class="card-body">
                        <div class="chart-container">
                            <canvas id="typeChart"></canvas>
                        </div>
                        <div class="mt-3">
                            <?php if(mysqli_num_rows($type_result) > 0): ?>
                                <?php mysqli_data_seek($type_result, 0); ?>
                                <?php while($type = mysqli_fetch_assoc($type_result)): ?>
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <div>
                                        <span class="customer-type-badge type-<?php echo $type['type']; ?>">
                                            <?php echo ucfirst($type['type']); ?>
                                        </span>
                                    </div>
                                    <div class="text-end">
                                        <strong><?php echo $type['total_customers']; ?> customers</strong><br>
                                        <small class="text-muted">
                                            Rp <?php echo number_format($type['total_revenue'], 0, ',', '.'); ?>
                                        </small>
                                    </div>
                                </div>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <div class="text-center py-4">
                                    <div class="text-muted">
                                        <i class="fas fa-chart-pie fa-2x mb-3"></i><br>
                                        No type distribution data.
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- CUSTOMER DETAILS TABLE -->
        <div class="card mb-4">
            <div class="card-header bg-dark text-white d-flex justify-content-between align-items-center">
                <h5 class="mb-0">📋 Customer Details (<?php echo mysqli_num_rows($customer_result); ?> customers)</h5>
                <div>
                    <span class="badge bg-light text-dark">
                        <i class="fas fa-calendar-alt"></i> 
                        <?php echo date('M d, Y', strtotime($start_date)); ?> - <?php echo date('M d, Y', strtotime($end_date)); ?>
                    </span>
                </div>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Customer</th>
                                <th>Type</th>
                                <th>Contact</th>
                                <th>Orders</th>
                                <th>Total Spent</th>
                                <th>Avg. Order</th>
                                <th>Last Order</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(mysqli_num_rows($customer_result) > 0): ?>
                                <?php $rank = 1; ?>
                                <?php while($customer = mysqli_fetch_assoc($customer_result)): 
                                    $days_since_last = $customer['last_order_date'] ? 
                                        floor((strtotime('now') - strtotime($customer['last_order_date'])) / (60*60*24)) : 
                                        null;
                                ?>
                                <tr>
                                    <td>
                                        <span class="badge bg-<?php echo ($rank <= 10) ? 'primary' : 'secondary'; ?>">
                                            <?php echo $rank; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <div class="avatar-circle me-3">
                                                <?php echo strtoupper(substr($customer['customer_name'], 0, 1)); ?>
                                            </div>
                                            <div>
                                                <strong><?php echo $customer['customer_name']; ?></strong><br>
                                                <small class="text-muted"><?php echo $customer['customer_code']; ?></small>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="customer-type-badge type-<?php echo $customer['customer_type']; ?>">
                                            <?php echo ucfirst($customer['customer_type']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <div>
                                            <small><i class="fas fa-envelope"></i> <?php echo $customer['email']; ?></small><br>
                                            <small><i class="fas fa-phone"></i> <?php echo $customer['phone']; ?></small>
                                        </div>
                                    </td>
                                    <td class="text-center">
                                        <span class="badge bg-info">
                                            <?php echo $customer['order_count']; ?> orders
                                        </span>
                                    </td>
                                    <td>
                                        <strong class="text-success">
                                            Rp <?php echo number_format($customer['total_spent'], 0, ',', '.'); ?>
                                        </strong>
                                    </td>
                                    <td>
                                        Rp <?php echo number_format($customer['avg_order_value'], 0, ',', '.'); ?>
                                    </td>
                                    <td>
                                        <?php if($customer['last_order_date']): ?>
                                            <div><?php echo date('M d, Y', strtotime($customer['last_order_date'])); ?></div>
                                            <?php if($days_since_last !== null): ?>
                                                <small class="<?php echo $days_since_last > 90 ? 'text-danger' : 'text-muted'; ?>">
                                                    <?php echo $days_since_last; ?> days ago
                                                </small>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <span class="text-muted">No orders</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="customer-status-<?php echo $customer['customer_status']; ?>">
                                            <?php echo ucfirst($customer['customer_status']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <div class="btn-group btn-group-sm">
                                            <a href="../customers/view.php?id=<?php echo $customer['customer_id']; ?>" 
                                               class="btn btn-outline-primary" title="View Details">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                            <a href="../customers/orders.php?id=<?php echo $customer['customer_id']; ?>" 
                                               class="btn btn-outline-info" title="View Orders">
                                                <i class="fas fa-shopping-cart"></i>
                                            </a>
                                            <a href="../customers/edit.php?id=<?php echo $customer['customer_id']; ?>" 
                                               class="btn btn-outline-warning" title="Edit Customer">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                                <?php $rank++; ?>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="10" class="text-center py-5">
                                        <div class="text-muted">
                                            <i class="fas fa-users fa-3x mb-3"></i><br>
                                            No customer data found for the selected filters.
                                        </div>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        
        <!-- INSIGHTS & RECOMMENDATIONS -->
        <div class="card">
            <div class="card-header bg-warning text-dark">
                <h5 class="mb-0">💡 Customer Insights & Recommendations</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <div class="alert alert-info">
                            <h6><i class="fas fa-chart-line"></i> Revenue Concentration</h6>
                            <?php 
                            // Calculate top 20% revenue concentration
                            mysqli_data_seek($customer_result, 0);
                            $total_revenue_calc = 0;
                            $revenues = [];
                            while($c = mysqli_fetch_assoc($customer_result)) {
                                $revenues[] = $c['total_spent'];
                                $total_revenue_calc += $c['total_spent'];
                            }
                            
                            if(!empty($revenues) && $total_revenue_calc > 0) {
                                rsort($revenues);
                                $top_20_count = ceil(count($revenues) * 0.2);
                                $top_20_revenue = array_sum(array_slice($revenues, 0, $top_20_count));
                                $concentration = ($top_20_revenue / $total_revenue_calc) * 100;
                            ?>
                                <p>Top 20% customers generate <strong><?php echo round($concentration, 1); ?>%</strong> of total revenue.</p>
                            <?php } else { ?>
                                <p>Insufficient data for revenue concentration analysis.</p>
                            <?php } ?>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="alert alert-warning">
                            <h6><i class="fas fa-clock"></i> Inactive Customers</h6>
                            <?php 
                            mysqli_data_seek($customer_result, 0);
                            $inactive_count = 0;
                            $total_customers_calc = mysqli_num_rows($customer_result);
                            
                            while($c = mysqli_fetch_assoc($customer_result)) {
                                if($c['last_order_date']) {
                                    $days = floor((strtotime('now') - strtotime($c['last_order_date'])) / (60*60*24));
                                    if($days > 90) $inactive_count++;
                                }
                            }
                            
                            if($total_customers_calc > 0) {
                                $inactive_percentage = ($inactive_count / $total_customers_calc) * 100;
                            ?>
                                <p><strong><?php echo $inactive_count; ?></strong> customers haven't ordered in 90+ days (<?php echo round($inactive_percentage, 1); ?>%).</p>
                                <small>Consider reactivation campaigns or special offers.</small>
                            <?php } else { ?>
                                <p>No customer data available for inactivity analysis.</p>
                            <?php } ?>
                        </div>
                    </div>
                </div>
                
                <div class="row mt-3">
                    <div class="col-md-4">
                        <div class="card bg-light">
                            <div class="card-body">
                                <h6><i class="fas fa-bullseye text-danger"></i> High-Value Targets</h6>
                                <p class="mb-1">Focus on top 10 customers</p>
                                <small class="text-muted">They contribute significantly to revenue</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card bg-light">
                            <div class="card-body">
                                <h6><i class="fas fa-user-plus text-success"></i> Growth Opportunity</h6>
                                <p class="mb-1">Engage with inactive customers</p>
                                <small class="text-muted">Send personalized offers or surveys</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card bg-light">
                            <div class="card-body">
                                <h6><i class="fas fa-gift text-primary"></i> Loyalty Program</h6>
                                <p class="mb-1">Implement rewards system</p>
                                <small class="text-muted">Increase repeat purchase frequency</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // CUSTOMER ACTIVITY CHART
        const activityCtx = document.getElementById('activityChart').getContext('2d');
        const activityChart = new Chart(activityCtx, {
            type: 'line',
            data: {
                labels: <?php echo json_encode($activity_labels); ?>,
                datasets: [{
                    label: 'Active Customers',
                    data: <?php echo json_encode($activity_data); ?>,
                    borderColor: 'rgba(0, 123, 255, 1)',
                    backgroundColor: 'rgba(0, 123, 255, 0.1)',
                    borderWidth: 2,
                    fill: true,
                    tension: 0.3
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: true,
                        position: 'top'
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Number of Customers'
                        }
                    },
                    x: {
                        title: {
                            display: true,
                            text: 'Date'
                        }
                    }
                }
            }
        });
        
        // CUSTOMER TYPE DISTRIBUTION CHART
        const typeCtx = document.getElementById('typeChart').getContext('2d');
        const typeChart = new Chart(typeCtx, {
            type: 'doughnut',
            data: {
                labels: <?php echo json_encode($type_labels); ?>,
                datasets: [{
                    data: <?php echo json_encode($type_data); ?>,
                    backgroundColor: [
                        'rgba(25, 118, 210, 0.8)',
                        'rgba(56, 142, 60, 0.8)',
                        'rgba(255, 193, 7, 0.8)',
                        'rgba(123, 31, 162, 0.8)',
                        'rgba(220, 53, 69, 0.8)'
                    ],
                    borderColor: [
                        'rgba(25, 118, 210, 1)',
                        'rgba(56, 142, 60, 1)',
                        'rgba(255, 193, 7, 1)',
                        'rgba(123, 31, 162, 1)',
                        'rgba(220, 53, 69, 1)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: true,
                        position: 'right'
                    }
                }
            }
        });
        
        // EXPORT FUNCTIONALITY
        <?php if(isset($_GET['export']) && $_GET['export'] == 'csv'): ?>
        // This would trigger CSV download via PHP header redirect
        // For now, we'll use the GET parameter approach
        <?php endif; ?>
        
        // AUTO REFRESH EVERY 10 MINUTES (optional)
        setTimeout(function() {
            location.reload();
        }, 600000); // 10 minutes
        
        // TOOLTIP INITIALIZATION
        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[title]'));
        var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });
    </script>
</body>
</html>