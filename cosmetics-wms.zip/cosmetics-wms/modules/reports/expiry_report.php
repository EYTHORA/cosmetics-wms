<?php
// modules/reports/expiry_report.php
$root_path = dirname(dirname(dirname(__FILE__))) . '/';
require_once $root_path . 'includes/config.php';
require_once $root_path . 'includes/auth.php';
checkLogin();

$active_menu = 'reports';
$page_title = "Expiry Report";

// FILTERS
$days_ahead = isset($_GET['days_ahead']) ? (int)$_GET['days_ahead'] : 30;
$status_filter = isset($_GET['status']) ? $_GET['status'] : 'all';
$category_id = isset($_GET['category_id']) ? (int)$_GET['category_id'] : '';
$halal_only = isset($_GET['halal_only']) ? true : false;
$search = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : '';

// BUILD WHERE CLAUSE
$where = "pb.status = 'released'";

// Filter berdasarkan waktu kadaluarsa
if ($days_ahead > 0) {
    $where .= " AND pb.expiry_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL $days_ahead DAY)";
} else {
    // Jika 0, tampilkan semua yang belum expired
    $where .= " AND pb.expiry_date >= CURDATE()";
}

// Filter status expiry
switch($status_filter) {
    case 'expired':
        $where .= " AND pb.expiry_date < CURDATE()";
        break;
    case 'critical':
        $where .= " AND pb.expiry_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)";
        break;
    case 'warning':
        $where .= " AND pb.expiry_date BETWEEN DATE_ADD(CURDATE(), INTERVAL 31 DAY) AND DATE_ADD(CURDATE(), INTERVAL 90 DAY)";
        break;
    case 'safe':
        $where .= " AND pb.expiry_date > DATE_ADD(CURDATE(), INTERVAL 90 DAY)";
        break;
}

if (!empty($category_id)) {
    $where .= " AND p.category_id = $category_id";
}

if ($halal_only) {
    $where .= " AND p.halal_certified = TRUE";
}

if (!empty($search)) {
    $where .= " AND (p.name LIKE '%$search%' OR p.sku LIKE '%$search%' OR pb.batch_number LIKE '%$search%')";
}

// GET CATEGORIES FOR FILTER
$categories_sql = "SELECT id, name FROM categories ORDER BY name";
$categories_result = mysqli_query($conn, $categories_sql);

// GET EXPIRY DATA
$expiry_sql = "SELECT 
                    pb.id as batch_id,
                    pb.batch_number,
                    pb.manufacturing_date,
                    pb.expiry_date,
                    pb.current_quantity,
                    pb.purchase_price,
                    pb.status as batch_status,
                    pb.location_id,
                    wl.location_code,
                    wl.temperature_zone,
                    
                    p.id as product_id,
                    p.sku,
                    p.name as product_name,
                    p.unit_price,
                    p.weight_volume,
                    p.halal_certified,
                    p.bpom_required,
                    p.storage_temperature,
                    
                    c.name as category_name,
                    b.name as brand_name,
                    
                    -- Calculate expiry info
                    DATEDIFF(pb.expiry_date, CURDATE()) as days_remaining,
                    
                    -- Calculate inventory value
                    (pb.current_quantity * pb.purchase_price) as batch_value,
                    
                    -- Get QC status
                    (SELECT passed FROM qc_checks WHERE batch_id = pb.id ORDER BY check_date DESC LIMIT 1) as last_qc_passed,
                    
                    -- Get expiry alerts count
                    (SELECT COUNT(*) FROM expiry_alerts WHERE batch_id = pb.id AND is_resolved = FALSE) as active_alerts
                    
                 FROM product_batches pb
                 JOIN products p ON pb.product_id = p.id
                 LEFT JOIN categories c ON p.category_id = c.id
                 LEFT JOIN brands b ON p.brand_id = b.id
                 LEFT JOIN warehouse_locations wl ON pb.location_id = wl.id
                 WHERE $where
                 ORDER BY 
                    CASE 
                        WHEN pb.expiry_date < CURDATE() THEN 1
                        WHEN pb.expiry_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY) THEN 2
                        WHEN pb.expiry_date BETWEEN DATE_ADD(CURDATE(), INTERVAL 31 DAY) AND DATE_ADD(CURDATE(), INTERVAL 90 DAY) THEN 3
                        ELSE 4
                    END,
                    pb.expiry_date ASC,
                    pb.current_quantity DESC";

$expiry_result = mysqli_query($conn, $expiry_sql);

// GET EXPIRY SUMMARY STATS
$summary_sql = "SELECT 
                  -- Total batches
                  COUNT(*) as total_batches,
                  
                  -- Total quantity expiring
                  SUM(pb.current_quantity) as total_items,
                  
                  -- Total value at risk
                  SUM(pb.current_quantity * pb.purchase_price) as total_value_at_risk,
                  
                  -- Already expired
                  COUNT(CASE WHEN pb.expiry_date < CURDATE() THEN 1 END) as expired_count,
                  SUM(CASE WHEN pb.expiry_date < CURDATE() THEN pb.current_quantity ELSE 0 END) as expired_quantity,
                  SUM(CASE WHEN pb.expiry_date < CURDATE() THEN (pb.current_quantity * pb.purchase_price) ELSE 0 END) as expired_value,
                  
                  -- Critical (0-30 days)
                  COUNT(CASE WHEN pb.expiry_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY) THEN 1 END) as critical_count,
                  SUM(CASE WHEN pb.expiry_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY) THEN pb.current_quantity ELSE 0 END) as critical_quantity,
                  SUM(CASE WHEN pb.expiry_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY) THEN (pb.current_quantity * pb.purchase_price) ELSE 0 END) as critical_value,
                  
                  -- Warning (31-90 days)
                  COUNT(CASE WHEN pb.expiry_date BETWEEN DATE_ADD(CURDATE(), INTERVAL 31 DAY) AND DATE_ADD(CURDATE(), INTERVAL 90 DAY) THEN 1 END) as warning_count,
                  SUM(CASE WHEN pb.expiry_date BETWEEN DATE_ADD(CURDATE(), INTERVAL 31 DAY) AND DATE_ADD(CURDATE(), INTERVAL 90 DAY) THEN pb.current_quantity ELSE 0 END) as warning_quantity,
                  SUM(CASE WHEN pb.expiry_date BETWEEN DATE_ADD(CURDATE(), INTERVAL 31 DAY) AND DATE_ADD(CURDATE(), INTERVAL 90 DAY) THEN (pb.current_quantity * pb.purchase_price) ELSE 0 END) as warning_value,
                  
                  -- Safe (>90 days)
                  COUNT(CASE WHEN pb.expiry_date > DATE_ADD(CURDATE(), INTERVAL 90 DAY) THEN 1 END) as safe_count,
                  SUM(CASE WHEN pb.expiry_date > DATE_ADD(CURDATE(), INTERVAL 90 DAY) THEN pb.current_quantity ELSE 0 END) as safe_quantity,
                  SUM(CASE WHEN pb.expiry_date > DATE_ADD(CURDATE(), INTERVAL 90 DAY) THEN (pb.current_quantity * pb.purchase_price) ELSE 0 END) as safe_value
                  
                FROM product_batches pb
                JOIN products p ON pb.product_id = p.id
                WHERE pb.status = 'released' 
                  AND pb.expiry_date >= CURDATE()";

$summary_result = mysqli_query($conn, $summary_sql);
$summary = mysqli_fetch_assoc($summary_result);

// GET PRODUCTS EXPIRING SOON (For alerts)
$expiring_soon_sql = "SELECT 
                         p.name as product_name,
                         p.sku,
                         MIN(pb.expiry_date) as earliest_expiry,
                         COUNT(pb.id) as batch_count,
                         SUM(pb.current_quantity) as total_quantity
                      FROM product_batches pb
                      JOIN products p ON pb.product_id = p.id
                      WHERE pb.status = 'released'
                        AND pb.expiry_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 60 DAY)
                      GROUP BY p.id
                      ORDER BY earliest_expiry ASC
                      LIMIT 15";

$expiring_soon_result = mysqli_query($conn, $expiring_soon_sql);

// GET MOST RECENT EXPIRY ALERTS
$alerts_sql = "SELECT 
                 ea.*,
                 pb.batch_number,
                 p.name as product_name,
                 p.sku,
                 u.full_name as notified_to_name
               FROM expiry_alerts ea
               JOIN product_batches pb ON ea.batch_id = pb.id
               JOIN products p ON pb.product_id = p.id
               LEFT JOIN users u ON ea.notified_to = u.id
               WHERE ea.is_resolved = FALSE
               ORDER BY ea.created_at DESC
               LIMIT 10";

$alerts_result = mysqli_query($conn, $alerts_sql);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cosmetics WMS - Expiry Report</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css">
    
    <style>
        .summary-card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.08);
            transition: all 0.3s;
            margin-bottom: 20px;
        }
        
        .summary-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        .expired-badge {
            background: linear-gradient(45deg, #dc3545, #c82333);
            color: white;
        }
        
        .critical-badge {
            background: linear-gradient(45deg, #fd7e14, #e8590c);
            color: white;
        }
        
        .warning-badge {
            background: linear-gradient(45deg, #ffc107, #e0a800);
            color: #212529;
        }
        
        .safe-badge {
            background: linear-gradient(45deg, #28a745, #20c997);
            color: white;
        }
        
        .batch-expired {
            background-color: #ffe6e6;
        }
        
        .batch-critical {
            background-color: #fff3cd;
        }
        
        .batch-warning {
            background-color: #e7f1ff;
        }
        
        .batch-safe {
            background-color: #d4edda;
        }
        
        .progress-bar-expired {
            background-color: #dc3545;
        }
        
        .progress-bar-critical {
            background-color: #fd7e14;
        }
        
        .progress-bar-warning {
            background-color: #ffc107;
        }
        
        .progress-bar-safe {
            background-color: #28a745;
        }
        
        .expiry-countdown {
            font-weight: bold;
            padding: 3px 8px;
            border-radius: 4px;
            font-size: 12px;
        }
        
        .halal-badge {
            background: linear-gradient(45deg, #28a745, #20c997);
            color: white;
        }
        
        .qc-failed {
            background-color: #f8d7da;
            border-left: 4px solid #dc3545;
        }
        
        .location-badge {
            background-color: #e9ecef;
            color: #495057;
            font-family: monospace;
            font-size: 12px;
            padding: 3px 6px;
            border-radius: 3px;
        }
    </style>
</head>
<body>
    <?php include $root_path . 'includes/sidebar.php'; ?>
    
    <div class="main-content" style="margin-left: 250px; padding: 25px;">
        <!-- HEADER -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h3 class="mb-1">⚠️ Expiry Monitoring Report</h3>
                <p class="text-muted mb-0">Track and manage product expiration dates</p>
            </div>
            <div class="d-flex">
                <button onclick="window.print()" class="btn btn-secondary me-2">
                    <i class="fas fa-print"></i> Print
                </button>
                <button class="btn btn-danger" onclick="generateExpiryReport()">
                    <i class="fas fa-file-pdf"></i> Export PDF
                </button>
            </div>
        </div>
        
        <!-- FILTERS -->
        <div class="card mb-4">
            <div class="card-header bg-danger text-white">
                <h5 class="mb-0">🔍 Filter Expiry Data</h5>
            </div>
            <div class="card-body">
                <form method="GET" action="" class="row g-3">
                    <div class="col-md-2">
                        <label class="form-label">Days Ahead</label>
                        <select name="days_ahead" class="form-select">
                            <option value="7" <?php echo ($days_ahead == 7) ? 'selected' : ''; ?>>7 Days</option>
                            <option value="30" <?php echo ($days_ahead == 30) ? 'selected' : ''; ?>>30 Days</option>
                            <option value="60" <?php echo ($days_ahead == 60) ? 'selected' : ''; ?>>60 Days</option>
                            <option value="90" <?php echo ($days_ahead == 90) ? 'selected' : ''; ?>>90 Days</option>
                            <option value="180" <?php echo ($days_ahead == 180) ? 'selected' : ''; ?>>180 Days</option>
                            <option value="365" <?php echo ($days_ahead == 365) ? 'selected' : ''; ?>>1 Year</option>
                            <option value="0" <?php echo ($days_ahead == 0) ? 'selected' : ''; ?>>All Future</option>
                        </select>
                    </div>
                    
                    <div class="col-md-2">
                        <label class="form-label">Status</label>
                        <select name="status" class="form-select">
                            <option value="all" <?php echo ($status_filter == 'all') ? 'selected' : ''; ?>>All Status</option>
                            <option value="expired" <?php echo ($status_filter == 'expired') ? 'selected' : ''; ?>>Expired</option>
                            <option value="critical" <?php echo ($status_filter == 'critical') ? 'selected' : ''; ?>>Critical (0-30 days)</option>
                            <option value="warning" <?php echo ($status_filter == 'warning') ? 'selected' : ''; ?>>Warning (31-90 days)</option>
                            <option value="safe" <?php echo ($status_filter == 'safe') ? 'selected' : ''; ?>>Safe (>90 days)</option>
                        </select>
                    </div>
                    
                    <div class="col-md-2">
                        <label class="form-label">Category</label>
                        <select name="category_id" class="form-select">
                            <option value="">All Categories</option>
                            <?php while($cat = mysqli_fetch_assoc($categories_result)): ?>
                            <option value="<?php echo $cat['id']; ?>" 
                                <?php echo ($category_id == $cat['id']) ? 'selected' : ''; ?>>
                                <?php echo $cat['name']; ?>
                            </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    
                    <div class="col-md-3">
                        <label class="form-label">Search</label>
                        <input type="text" name="search" class="form-control" 
                               placeholder="Product name, SKU or Batch number..." 
                               value="<?php echo htmlspecialchars($search); ?>">
                    </div>
                    
                    <div class="col-md-3 d-flex align-items-end">
                        <div class="form-check me-3">
                            <input class="form-check-input" type="checkbox" name="halal_only" id="halal_only" 
                                   <?php echo $halal_only ? 'checked' : ''; ?>>
                            <label class="form-check-label" for="halal_only">
                                Halal Products Only
                            </label>
                        </div>
                        <button type="submit" class="btn btn-danger">
                            <i class="fas fa-filter"></i> Apply Filter
                        </button>
                        <a href="expiry_report.php" class="btn btn-secondary ms-2">
                            <i class="fas fa-redo"></i>
                        </a>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- EXPIRY SUMMARY -->
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="card summary-card">
                    <div class="card-body text-center">
                        <div class="text-danger mb-2">
                            <i class="fas fa-exclamation-triangle fa-3x"></i>
                        </div>
                        <h3 class="mb-1"><?php echo number_format($summary['expired_count'] ?? 0, 0, ',', '.'); ?></h3>
                        <h6 class="text-muted">Expired Batches</h6>
                        <div class="mt-2">
                            <small class="text-danger">
                                <i class="fas fa-box"></i> <?php echo number_format($summary['expired_quantity'] ?? 0, 0, ',', '.'); ?> items
                            </small><br>
                            <small class="text-danger">
                                <i class="fas fa-money-bill-wave"></i> Rp <?php echo number_format($summary['expired_value'] ?? 0, 0, ',', '.'); ?>
                            </small>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3">
                <div class="card summary-card">
                    <div class="card-body text-center">
                        <div class="text-warning mb-2">
                            <i class="fas fa-clock fa-3x"></i>
                        </div>
                        <h3 class="mb-1"><?php echo number_format($summary['critical_count'] ?? 0, 0, ',', '.'); ?></h3>
                        <h6 class="text-muted">Critical (0-30 days)</h6>
                        <div class="mt-2">
                            <small class="text-warning">
                                <i class="fas fa-box"></i> <?php echo number_format($summary['critical_quantity'] ?? 0, 0, ',', '.'); ?> items
                            </small><br>
                            <small class="text-warning">
                                <i class="fas fa-money-bill-wave"></i> Rp <?php echo number_format($summary['critical_value'] ?? 0, 0, ',', '.'); ?>
                            </small>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3">
                <div class="card summary-card">
                    <div class="card-body text-center">
                        <div class="text-info mb-2">
                            <i class="fas fa-hourglass-half fa-3x"></i>
                        </div>
                        <h3 class="mb-1"><?php echo number_format($summary['warning_count'] ?? 0, 0, ',', '.'); ?></h3>
                        <h6 class="text-muted">Warning (31-90 days)</h6>
                        <div class="mt-2">
                            <small class="text-info">
                                <i class="fas fa-box"></i> <?php echo number_format($summary['warning_quantity'] ?? 0, 0, ',', '.'); ?> items
                            </small><br>
                            <small class="text-info">
                                <i class="fas fa-money-bill-wave"></i> Rp <?php echo number_format($summary['warning_value'] ?? 0, 0, ',', '.'); ?>
                            </small>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3">
                <div class="card summary-card">
                    <div class="card-body text-center">
                        <div class="text-success mb-2">
                            <i class="fas fa-check-circle fa-3x"></i>
                        </div>
                        <h3 class="mb-1"><?php echo number_format($summary['safe_count'] ?? 0, 0, ',', '.'); ?></h3>
                        <h6 class="text-muted">Safe (>90 days)</h6>
                        <div class="mt-2">
                            <small class="text-success">
                                <i class="fas fa-box"></i> <?php echo number_format($summary['safe_quantity'] ?? 0, 0, ',', '.'); ?> items
                            </small><br>
                            <small class="text-success">
                                <i class="fas fa-money-bill-wave"></i> Rp <?php echo number_format($summary['safe_value'] ?? 0, 0, ',', '.'); ?>
                            </small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- VALUE AT RISK PROGRESS BAR -->
        <div class="card mb-4">
            <div class="card-header bg-dark text-white">
                <h5 class="mb-0">💰 Value at Risk Summary</h5>
            </div>
            <div class="card-body">
                <?php
                $total_value = $summary['total_value_at_risk'] ?? 1;
                $expired_percent = ($summary['expired_value'] ?? 0) / $total_value * 100;
                $critical_percent = ($summary['critical_value'] ?? 0) / $total_value * 100;
                $warning_percent = ($summary['warning_value'] ?? 0) / $total_value * 100;
                $safe_percent = ($summary['safe_value'] ?? 0) / $total_value * 100;
                ?>
                
                <h5 class="mb-3">Total Inventory Value: <span class="text-primary">Rp <?php echo number_format($total_value, 0, ',', '.'); ?></span></h5>
                
                <div class="progress" style="height: 30px;">
                    <div class="progress-bar progress-bar-expired" 
                         style="width: <?php echo $expired_percent; ?>%"
                         title="Expired: Rp <?php echo number_format($summary['expired_value'] ?? 0, 0, ',', '.'); ?>">
                        Expired: <?php echo number_format($expired_percent, 1); ?>%
                    </div>
                    <div class="progress-bar progress-bar-critical" 
                         style="width: <?php echo $critical_percent; ?>%"
                         title="Critical: Rp <?php echo number_format($summary['critical_value'] ?? 0, 0, ',', '.'); ?>">
                        Critical: <?php echo number_format($critical_percent, 1); ?>%
                    </div>
                    <div class="progress-bar progress-bar-warning" 
                         style="width: <?php echo $warning_percent; ?>%"
                         title="Warning: Rp <?php echo number_format($summary['warning_value'] ?? 0, 0, ',', '.'); ?>">
                        Warning: <?php echo number_format($warning_percent, 1); ?>%
                    </div>
                    <div class="progress-bar progress-bar-safe" 
                         style="width: <?php echo $safe_percent; ?>%"
                         title="Safe: Rp <?php echo number_format($summary['safe_value'] ?? 0, 0, ',', '.'); ?>">
                        Safe: <?php echo number_format($safe_percent, 1); ?>%
                    </div>
                </div>
                
                <div class="row mt-3 text-center">
                    <div class="col-md-3">
                        <span class="badge expired-badge p-2 w-100">
                            <i class="fas fa-skull-crossbones"></i> Expired: Rp <?php echo number_format($summary['expired_value'] ?? 0, 0, ',', '.'); ?>
                        </span>
                    </div>
                    <div class="col-md-3">
                        <span class="badge critical-badge p-2 w-100">
                            <i class="fas fa-fire"></i> Critical: Rp <?php echo number_format($summary['critical_value'] ?? 0, 0, ',', '.'); ?>
                        </span>
                    </div>
                    <div class="col-md-3">
                        <span class="badge warning-badge p-2 w-100">
                            <i class="fas fa-exclamation-triangle"></i> Warning: Rp <?php echo number_format($summary['warning_value'] ?? 0, 0, ',', '.'); ?>
                        </span>
                    </div>
                    <div class="col-md-3">
                        <span class="badge safe-badge p-2 w-100">
                            <i class="fas fa-shield-alt"></i> Safe: Rp <?php echo number_format($summary['safe_value'] ?? 0, 0, ',', '.'); ?>
                        </span>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- EXPIRY DATA TABLE -->
        <div class="card mb-4">
            <div class="card-header bg-danger text-white d-flex justify-content-between align-items-center">
                <h5 class="mb-0">📋 Batch Expiry Details</h5>
                <span class="badge bg-light text-dark">
                    <?php echo mysqli_num_rows($expiry_result); ?> batches found
                </span>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover" id="expiryTable">
                        <thead>
                            <tr>
                                <th>Status</th>
                                <th>Product Info</th>
                                <th>Batch Details</th>
                                <th>Expiry Info</th>
                                <th>Stock & Value</th>
                                <th>Location</th>
                                <th>QC Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(mysqli_num_rows($expiry_result) > 0): ?>
                                <?php while($batch = mysqli_fetch_assoc($expiry_result)): 
                                    // Determine expiry status
                                    $expiry_status = '';
                                    $expiry_class = '';
                                    $row_class = '';
                                    $status_icon = '';
                                    
                                    if ($batch['days_remaining'] < 0) {
                                        $expiry_status = 'EXPIRED';
                                        $expiry_class = 'expired-badge';
                                        $row_class = 'batch-expired';
                                        $status_icon = '<i class="fas fa-skull-crossbones"></i>';
                                    } elseif ($batch['days_remaining'] <= 30) {
                                        $expiry_status = 'CRITICAL';
                                        $expiry_class = 'critical-badge';
                                        $row_class = 'batch-critical';
                                        $status_icon = '<i class="fas fa-fire"></i>';
                                    } elseif ($batch['days_remaining'] <= 90) {
                                        $expiry_status = 'WARNING';
                                        $expiry_class = 'warning-badge';
                                        $row_class = 'batch-warning';
                                        $status_icon = '<i class="fas fa-exclamation-triangle"></i>';
                                    } else {
                                        $expiry_status = 'SAFE';
                                        $expiry_class = 'safe-badge';
                                        $row_class = 'batch-safe';
                                        $status_icon = '<i class="fas fa-check-circle"></i>';
                                    }
                                    
                                    // QC status
                                    $qc_status = '';
                                    $qc_class = '';
                                    if ($batch['last_qc_passed'] === null) {
                                        $qc_status = 'Not Checked';
                                        $qc_class = 'bg-secondary';
                                    } elseif ($batch['last_qc_passed'] == 1) {
                                        $qc_status = 'Passed';
                                        $qc_class = 'bg-success';
                                    } else {
                                        $qc_status = 'Failed';
                                        $qc_class = 'bg-danger';
                                    }
                                ?>
                                <tr class="<?php echo $row_class; ?>">
                                    <td>
                                        <span class="badge <?php echo $expiry_class; ?> p-2">
                                            <?php echo $status_icon; ?> <?php echo $expiry_status; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <strong><?php echo $batch['product_name']; ?></strong><br>
                                        <small class="text-muted">SKU: <?php echo $batch['sku']; ?></small><br>
                                        <small class="text-muted">Category: <?php echo $batch['category_name']; ?></small><br>
                                        <small class="text-muted">Brand: <?php echo $batch['brand_name']; ?></small>
                                        <?php if($batch['halal_certified']): ?>
                                            <span class="badge halal-badge">Halal</span>
                                        <?php endif; ?>
                                        <?php if($batch['bpom_required']): ?>
                                            <span class="badge bg-info">BPOM</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <strong>Batch: <?php echo $batch['batch_number']; ?></strong><br>
                                        <small class="text-muted">Size: <?php echo $batch['weight_volume']; ?></small><br>
                                        <small class="text-muted">MFG: <?php echo date('d M Y', strtotime($batch['manufacturing_date'])); ?></small><br>
                                        <small class="text-muted">Cost: Rp <?php echo number_format($batch['purchase_price'], 0, ',', '.'); ?></small>
                                    </td>
                                    <td>
                                        <div class="mb-2">
                                            <h5 class="<?php echo ($batch['days_remaining'] < 0) ? 'text-danger' : 'text-dark'; ?>">
                                                <?php echo date('d M Y', strtotime($batch['expiry_date'])); ?>
                                            </h5>
                                        </div>
                                        <div>
                                            <?php if($batch['days_remaining'] < 0): ?>
                                                <span class="expiry-countdown bg-danger text-white">
                                                    <i class="fas fa-exclamation-circle"></i> Expired <?php echo abs($batch['days_remaining']); ?> days ago
                                                </span>
                                            <?php else: ?>
                                                <span class="expiry-countdown bg-<?php echo ($batch['days_remaining'] <= 30) ? 'warning' : 'success'; ?> text-<?php echo ($batch['days_remaining'] <= 30) ? 'dark' : 'white'; ?>">
                                                    <i class="fas fa-clock"></i> <?php echo $batch['days_remaining']; ?> days left
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                        <?php if($batch['active_alerts'] > 0): ?>
                                        <div class="mt-2">
                                            <span class="badge bg-danger">
                                                <i class="fas fa-bell"></i> <?php echo $batch['active_alerts']; ?> alerts
                                            </span>
                                        </div>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <h5 class="text-primary"><?php echo number_format($batch['current_quantity'], 0, ',', '.'); ?> pcs</h5>
                                        <div class="mt-2">
                                            <small class="text-muted">Value:</small><br>
                                            <strong class="text-success">Rp <?php echo number_format($batch['batch_value'], 0, ',', '.'); ?></strong>
                                        </div>
                                        <div class="mt-2">
                                            <small class="text-muted">Selling Price:</small><br>
                                            <strong>Rp <?php echo number_format($batch['unit_price'], 0, ',', '.'); ?></strong>
                                        </div>
                                    </td>
                                    <td>
                                        <?php if(!empty($batch['location_code'])): ?>
                                            <span class="location-badge"><?php echo $batch['location_code']; ?></span><br>
                                            <small class="text-muted">
                                                Zone: <?php echo strtoupper($batch['temperature_zone']); ?>
                                            </small><br>
                                            <small class="text-muted">
                                                Required: <?php echo $batch['storage_temperature']; ?>
                                            </small>
                                        <?php else: ?>
                                            <span class="badge bg-warning text-dark">No Location</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="badge <?php echo $qc_class; ?>">
                                            <?php echo $qc_status; ?>
                                        </span>
                                        <?php if($qc_class == 'bg-danger'): ?>
                                            <div class="mt-1">
                                                <small class="text-danger"><i class="fas fa-exclamation-circle"></i> QC Failed</small>
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="dropdown">
                                            <button class="btn btn-sm btn-outline-danger dropdown-toggle" type="button" 
                                                    data-bs-toggle="dropdown" aria-expanded="false">
                                                <i class="fas fa-cog"></i>
                                            </button>
                                            <ul class="dropdown-menu">
                                                <li>
                                                    <a class="dropdown-item" href="../inventory/batch_view.php?id=<?php echo $batch['batch_id']; ?>">
                                                        <i class="fas fa-eye"></i> View Details
                                                    </a>
                                                </li>
                                                <li>
                                                    <a class="dropdown-item" href="../qc/check.php?batch_id=<?php echo $batch['batch_id']; ?>">
                                                        <i class="fas fa-clipboard-check"></i> QC Check
                                                    </a>
                                                </li>
                                                <li>
                                                    <a class="dropdown-item" href="#" onclick="createDisposal(<?php echo $batch['batch_id']; ?>)">
                                                        <i class="fas fa-trash"></i> Dispose Batch
                                                    </a>
                                                </li>
                                                <li>
                                                    <a class="dropdown-item" href="#" onclick="markAsResolved(<?php echo $batch['batch_id']; ?>)">
                                                        <i class="fas fa-check"></i> Mark Resolved
                                                    </a>
                                                </li>
                                                <li><hr class="dropdown-divider"></li>
                                                <li>
                                                    <a class="dropdown-item text-primary" href="#" onclick="createPromotion(<?php echo $batch['batch_id']; ?>)">
                                                        <i class="fas fa-tag"></i> Create Promotion
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="8" class="text-center py-4">
                                        <div class="text-muted">
                                            <i class="fas fa-calendar-times fa-2x mb-3"></i><br>
                                            No batches found with current filters.
                                        </div>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        
        <!-- TWO COLUMNS: PRODUCTS EXPIRING SOON & RECENT ALERTS -->
        <div class="row">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header bg-warning text-dark">
                        <h5 class="mb-0">📊 Products Expiring Soon (Next 60 Days)</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-sm">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Product</th>
                                        <th>Earliest Expiry</th>
                                        <th>Batches</th>
                                        <th>Total Qty</th>
                                        <th>Risk</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(mysqli_num_rows($expiring_soon_result) > 0): ?>
                                        <?php $rank = 1; ?>
                                        <?php while($product = mysqli_fetch_assoc($expiring_soon_result)): 
                                            $days_left = floor((strtotime($product['earliest_expiry']) - time()) / (60*60*24));
                                            $risk_class = ($days_left <= 15) ? 'danger' : (($days_left <= 30) ? 'warning' : 'info');
                                        ?>
                                        <tr>
                                            <td>
                                                <span class="badge bg-<?php echo ($rank <= 3) ? 'danger' : 'secondary'; ?>">
                                                    <?php echo $rank; ?>
                                                </span>
                                            </td>
                                            <td>
                                                <strong><?php echo $product['product_name']; ?></strong><br>
                                                <small class="text-muted"><?php echo $product['sku']; ?></small>
                                            </td>
                                            <td>
                                                <?php echo date('d M Y', strtotime($product['earliest_expiry'])); ?><br>
                                                <span class="badge bg-<?php echo $risk_class; ?>">
                                                    <?php echo $days_left; ?> days
                                                </span>
                                            </td>
                                            <td>
                                                <span class="badge bg-info"><?php echo $product['batch_count']; ?> batches</span>
                                            </td>
                                            <td>
                                                <strong><?php echo number_format($product['total_quantity'], 0, ',', '.'); ?> pcs</strong>
                                            </td>
                                            <td>
                                                <div class="progress" style="height: 8px;">
                                                    <div class="progress-bar bg-<?php echo $risk_class; ?>" role="progressbar" 
                                                         style="width: <?php echo min(100, (60 - $days_left) / 60 * 100); ?>%">
                                                    </div>
                                                </div>
                                                <small><?php echo round((60 - $days_left) / 60 * 100, 0); ?>% risk</small>
                                            </td>
                                        </tr>
                                        <?php $rank++; ?>
                                        <?php endwhile; ?>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="6" class="text-center py-3">
                                                <div class="text-muted">
                                                    <i class="fas fa-check-circle"></i> No products expiring in next 60 days
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header bg-danger text-white">
                        <h5 class="mb-0">🔔 Recent Expiry Alerts</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-sm">
                                <thead>
                                    <tr>
                                        <th>Alert</th>
                                        <th>Product</th>
                                        <th>Batch</th>
                                        <th>Days</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(mysqli_num_rows($alerts_result) > 0): ?>
                                        <?php while($alert = mysqli_fetch_assoc($alerts_result)): 
                                            $alert_class = '';
                                            $alert_icon = '';
                                            switch($alert['alert_type']) {
                                                case 'expired':
                                                    $alert_class = 'bg-danger';
                                                    $alert_icon = '<i class="fas fa-skull-crossbones"></i>';
                                                    break;
                                                case 'critical':
                                                    $alert_class = 'bg-warning text-dark';
                                                    $alert_icon = '<i class="fas fa-fire"></i>';
                                                    break;
                                                case 'warning':
                                                    $alert_class = 'bg-info';
                                                    $alert_icon = '<i class="fas fa-exclamation-triangle"></i>';
                                                    break;
                                            }
                                        ?>
                                        <tr>
                                            <td>
                                                <span class="badge <?php echo $alert_class; ?>">
                                                    <?php echo $alert_icon; ?> <?php echo ucfirst($alert['alert_type']); ?>
                                                </span>
                                            </td>
                                            <td>
                                                <small><strong><?php echo $alert['product_name']; ?></strong></small><br>
                                                <small class="text-muted"><?php echo $alert['sku']; ?></small>
                                            </td>
                                            <td>
                                                <small><?php echo $alert['batch_number']; ?></small>
                                            </td>
                                            <td>
                                                <?php if($alert['days_remaining'] < 0): ?>
                                                    <span class="badge bg-danger">
                                                        <?php echo abs($alert['days_remaining']); ?> days ago
                                                    </span>
                                                <?php else: ?>
                                                    <span class="badge bg-warning">
                                                        <?php echo $alert['days_remaining']; ?> days left
                                                    </span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if($alert['is_resolved']): ?>
                                                    <span class="badge bg-success">Resolved</span>
                                                <?php else: ?>
                                                    <span class="badge bg-danger">Active</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <button class="btn btn-sm btn-outline-primary" 
                                                        onclick="viewAlert(<?php echo $alert['id']; ?>)">
                                                    <i class="fas fa-eye"></i>
                                                </button>
                                            </td>
                                        </tr>
                                        <?php endwhile; ?>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="6" class="text-center py-3">
                                                <div class="text-muted">
                                                    <i class="fas fa-bell-slash"></i> No active expiry alerts
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="mt-3">
                            <button class="btn btn-sm btn-outline-danger w-100" onclick="generateAllAlerts()">
                                <i class="fas fa-bell"></i> Generate Alerts for All Critical Batches
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
    
    <script>
        // Initialize DataTable
        $(document).ready(function() {
            $('#expiryTable').DataTable({
                "pageLength": 25,
                "order": [[0, 'asc']],
                "language": {
                    "search": "Search batches...",
                    "lengthMenu": "Show _MENU_ batches per page",
                    "zeroRecords": "No batches found",
                    "info": "Showing _START_ to _END_ of _TOTAL_ batches",
                    "infoEmpty": "No batches available",
                    "infoFiltered": "(filtered from _MAX_ total batches)",
                    "paginate": {
                        "first": "First",
                        "last": "Last",
                        "next": "Next",
                        "previous": "Previous"
                    }
                }
            });
        });
        
        // Function to generate PDF report
        function generateExpiryReport() {
            const daysAhead = <?php echo $days_ahead; ?>;
            const statusFilter = "<?php echo $status_filter; ?>";
            
            if (confirm(`Generate expiry report PDF for ${daysAhead} days ahead?`)) {
                // Show loading
                alert('Generating PDF report... This might take a moment.');
                
                // In production, redirect to PDF generation script
                window.location.href = `expiry_report_pdf.php?days_ahead=${daysAhead}&status=${statusFilter}&category_id=<?php echo $category_id; ?>&halal_only=<?php echo $halal_only ? 1 : 0; ?>`;
            }
        }
        
        // Function to create disposal request
        function createDisposal(batchId) {
            if (confirm('Create disposal request for this batch?')) {
                window.location.href = `../inventory/dispose.php?batch_id=${batchId}`;
            }
        }
        
        // Function to mark batch as resolved
        function markAsResolved(batchId) {
            if (confirm('Mark all alerts for this batch as resolved?')) {
                // AJAX call to mark as resolved
                $.post('../ajax/resolve_alerts.php', {
                    batch_id: batchId,
                    action: 'resolve'
                }, function(response) {
                    if (response.success) {
                        alert('Alerts marked as resolved!');
                        location.reload();
                    } else {
                        alert('Error: ' + response.message);
                    }
                });
            }
        }
        
        // Function to create promotion for expiring batch
        function createPromotion(batchId) {
            if (confirm('Create promotion for this expiring batch?')) {
                window.location.href = `../promotions/create.php?batch_id=${batchId}`;
            }
        }
        
        // Function to view alert details
        function viewAlert(alertId) {
            window.location.href = `../alerts/view.php?id=${alertId}`;
        }
        
        // Function to generate alerts for all critical batches
        function generateAllAlerts() {
            if (confirm('Generate alerts for all batches expiring within 30 days?')) {
                $.post('../ajax/generate_alerts.php', {
                    days: 30,
                    action: 'generate'
                }, function(response) {
                    if (response.success) {
                        alert(`${response.count} alerts generated!`);
                        location.reload();
                    } else {
                        alert('Error: ' + response.message);
                    }
                });
            }
        }
        
        // Auto-refresh every 2 minutes
        setTimeout(function() {
            location.reload();
        }, 120000);
    </script>
</body>
</html>