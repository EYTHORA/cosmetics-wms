<?php
// modules/reports/analytics.php
$root_path = dirname(dirname(dirname(__FILE__))) . '/';
require_once $root_path . 'includes/config.php';
require_once $root_path . 'includes/auth.php';
checkLogin();

$active_menu = 'reports';
$page_title = "Business Analytics Dashboard";

// SET DEFAULT DATE RANGE
$start_date = isset($_GET['start_date']) ? $_GET['start_date'] : date('Y-m-d', strtotime('-30 days'));
$end_date = isset($_GET['end_date']) ? $_GET['end_date'] : date('Y-m-d');
$time_frame = isset($_GET['time_frame']) ? $_GET['time_frame'] : '30d'; // 7d, 30d, 90d, ytd, 1y

// AUTO SET DATE RANGE BASED ON TIME FRAME
if (isset($_GET['time_frame']) && empty($_GET['start_date'])) {
    switch ($_GET['time_frame']) {
        case '7d':
            $start_date = date('Y-m-d', strtotime('-7 days'));
            break;
        case '30d':
            $start_date = date('Y-m-d', strtotime('-30 days'));
            break;
        case '90d':
            $start_date = date('Y-m-d', strtotime('-90 days'));
            break;
        case 'ytd':
            $start_date = date('Y-01-01');
            break;
        case '1y':
            $start_date = date('Y-m-d', strtotime('-1 year'));
            break;
        case 'all':
            $start_date = '2023-01-01'; // Adjust based on your business start
            break;
    }
}

// VALIDATE DATES
if (!empty($start_date) && !empty($end_date) && $start_date > $end_date) {
    $temp = $start_date;
    $start_date = $end_date;
    $end_date = $temp;
}

// ==================== KPI METRICS ====================

// 1. SALES METRICS
$sales_sql = "SELECT 
                COUNT(o.id) as total_orders,
                SUM(o.grand_total) as total_revenue,
                AVG(o.grand_total) as avg_order_value,
                COUNT(DISTINCT o.customer_id) as unique_customers,
                MIN(o.grand_total) as min_order,
                MAX(o.grand_total) as max_order
            FROM orders o
            WHERE o.status = 'delivered' 
                AND o.order_date BETWEEN '$start_date' AND '$end_date 23:59:59'";

$sales_result = mysqli_query($conn, $sales_sql);
$sales_kpi = mysqli_fetch_assoc($sales_result);

// 2. INVENTORY METRICS
$inventory_sql = "SELECT 
                    COUNT(p.id) as total_products,
                    SUM(pb.current_quantity) as total_stock,
                    COUNT(DISTINCT CASE WHEN pb.current_quantity <= p.min_stock THEN p.id END) as low_stock_items,
                    COUNT(DISTINCT CASE WHEN pb.current_quantity = 0 AND p.status = 'active' THEN p.id END) as out_of_stock,
                    SUM(pb.current_quantity * p.unit_price) as inventory_value
                FROM products p
                LEFT JOIN product_batches pb ON p.id = pb.product_id 
                    AND pb.status = 'released'
                WHERE p.status = 'active'";

$inventory_result = mysqli_query($conn, $inventory_sql);
$inventory_kpi = mysqli_fetch_assoc($inventory_result);

// 3. CUSTOMER METRICS
$customer_sql = "SELECT 
                    COUNT(DISTINCT c.id) as total_customers,
                    COUNT(DISTINCT CASE WHEN o.order_date >= DATE_SUB('$end_date', INTERVAL 30 DAY) THEN c.id END) as active_30d,
                    COUNT(DISTINCT CASE WHEN o.order_date >= DATE_SUB('$end_date', INTERVAL 90 DAY) THEN c.id END) as active_90d,
                    AVG(DATEDIFF('$end_date', o.order_date)) as avg_days_since_last_order
                FROM customers c
                LEFT JOIN orders o ON c.id = o.customer_id 
                    AND o.status = 'delivered'";

$customer_result = mysqli_query($conn, $customer_sql);
$customer_kpi = mysqli_fetch_assoc($customer_result);

// 4. GROWTH METRICS (vs previous period)
$prev_start_date = date('Y-m-d', strtotime($start_date . ' -1 month'));
$prev_end_date = date('Y-m-d', strtotime($end_date . ' -1 month'));

$growth_sql = "SELECT 
                COALESCE(SUM(CASE WHEN o.order_date BETWEEN '$start_date' AND '$end_date 23:59:59' THEN o.grand_total END), 0) as current_revenue,
                COALESCE(SUM(CASE WHEN o.order_date BETWEEN '$prev_start_date' AND '$prev_end_date 23:59:59' THEN o.grand_total END), 0) as prev_revenue,
                COUNT(DISTINCT CASE WHEN o.order_date BETWEEN '$start_date' AND '$end_date 23:59:59' THEN o.customer_id END) as current_customers,
                COUNT(DISTINCT CASE WHEN o.order_date BETWEEN '$prev_start_date' AND '$prev_end_date 23:59:59' THEN o.customer_id END) as prev_customers
            FROM orders o
            WHERE o.status = 'delivered'";

$growth_result = mysqli_query($conn, $growth_sql);
$growth_kpi = mysqli_fetch_assoc($growth_result);

// Calculate growth percentages
$revenue_growth = $growth_kpi['prev_revenue'] > 0 ? 
    (($growth_kpi['current_revenue'] - $growth_kpi['prev_revenue']) / $growth_kpi['prev_revenue']) * 100 : 0;
$customer_growth = $growth_kpi['prev_customers'] > 0 ? 
    (($growth_kpi['current_customers'] - $growth_kpi['prev_customers']) / $growth_kpi['prev_customers']) * 100 : 0;

// ==================== CHARTS DATA ====================

// 1. REVENUE TREND (DAILY)
$revenue_trend_sql = "SELECT 
                        DATE(o.order_date) as date,
                        SUM(o.grand_total) as revenue,
                        COUNT(o.id) as orders,
                        COUNT(DISTINCT o.customer_id) as customers
                    FROM orders o
                    WHERE o.status = 'delivered' 
                        AND o.order_date BETWEEN '$start_date' AND '$end_date 23:59:59'
                    GROUP BY DATE(o.order_date)
                    ORDER BY DATE(o.order_date)";

$revenue_trend_result = mysqli_query($conn, $revenue_trend_sql);
$revenue_dates = [];
$revenue_data = [];
$order_data = [];
$customer_data = [];

while ($row = mysqli_fetch_assoc($revenue_trend_result)) {
    $revenue_dates[] = date('M d', strtotime($row['date']));
    $revenue_data[] = (float)$row['revenue'];
    $order_data[] = (int)$row['orders'];
    $customer_data[] = (int)$row['customers'];
}

// 2. CATEGORY PERFORMANCE
$category_sql = "SELECT 
                    cat.name as category,
                    COUNT(DISTINCT o.id) as orders,
                    SUM(oi.quantity) as quantity_sold,
                    SUM(oi.quantity * oi.unit_price) as revenue,
                    ROUND(SUM(oi.quantity * oi.unit_price) / 
                        (SELECT SUM(grand_total) FROM orders WHERE status = 'delivered' 
                         AND order_date BETWEEN '$start_date' AND '$end_date 23:59:59') * 100, 1) as percentage
                FROM order_items oi
                JOIN products p ON oi.product_id = p.id
                JOIN categories cat ON p.category_id = cat.id
                JOIN orders o ON oi.order_id = o.id
                WHERE o.status = 'delivered' 
                    AND o.order_date BETWEEN '$start_date' AND '$end_date 23:59:59'
                GROUP BY cat.id
                ORDER BY revenue DESC
                LIMIT 10";

$category_result = mysqli_query($conn, $category_sql);
$category_labels = [];
$category_revenue = [];
$category_percent = [];

while ($row = mysqli_fetch_assoc($category_result)) {
    $category_labels[] = $row['category'];
    $category_revenue[] = (float)$row['revenue'];
    $category_percent[] = (float)$row['percentage'];
}

// 3. BRAND PERFORMANCE
$brand_sql = "SELECT 
                b.name as brand,
                COUNT(DISTINCT o.id) as orders,
                SUM(oi.quantity) as quantity_sold,
                SUM(oi.quantity * oi.unit_price) as revenue,
                AVG(oi.unit_price) as avg_price
            FROM order_items oi
            JOIN products p ON oi.product_id = p.id
            JOIN brands b ON p.brand_id = b.id
            JOIN orders o ON oi.order_id = o.id
            WHERE o.status = 'delivered' 
                AND o.order_date BETWEEN '$start_date' AND '$end_date 23:59:59'
            GROUP BY b.id
            ORDER BY revenue DESC
            LIMIT 8";

$brand_result = mysqli_query($conn, $brand_sql);

// 4. ORDER STATUS DISTRIBUTION
$status_sql = "SELECT 
                status,
                COUNT(id) as count,
                ROUND(COUNT(id) / (SELECT COUNT(id) FROM orders 
                     WHERE order_date BETWEEN '$start_date' AND '$end_date 23:59:59') * 100, 1) as percentage
            FROM orders
            WHERE order_date BETWEEN '$start_date' AND '$end_date 23:59:59'
            GROUP BY status
            ORDER BY FIELD(status, 'delivered', 'shipped', 'packing', 'picking', 'confirmed', 'draft', 'cancelled')";

$status_result = mysqli_query($conn, $status_sql);

// 5. TOP 5 PRODUCTS (REVENUE)
$top_products_sql = "SELECT 
                        p.name as product_name,
                        p.sku,
                        cat.name as category,
                        SUM(oi.quantity) as quantity_sold,
                        SUM(oi.quantity * oi.unit_price) as revenue,
                        ROUND(AVG(oi.unit_price), 0) as avg_price
                    FROM order_items oi
                    JOIN products p ON oi.product_id = p.id
                    JOIN categories cat ON p.category_id = cat.id
                    JOIN orders o ON oi.order_id = o.id
                    WHERE o.status = 'delivered' 
                        AND o.order_date BETWEEN '$start_date' AND '$end_date 23:59:59'
                    GROUP BY p.id
                    ORDER BY revenue DESC
                    LIMIT 5";

$top_products_result = mysqli_query($conn, $top_products_sql);

// 6. CUSTOMER SEGMENTATION
$segment_sql = "SELECT 
                    CASE 
                        WHEN total_spent >= 1000000 THEN 'Premium'
                        WHEN total_spent >= 500000 THEN 'Gold'
                        WHEN total_spent >= 200000 THEN 'Silver'
                        ELSE 'Bronze'
                    END as segment,
                    COUNT(*) as customer_count,
                    SUM(total_spent) as segment_revenue,
                    AVG(total_spent) as avg_spent,
                    AVG(order_count) as avg_orders
                FROM (
                    SELECT 
                        c.id,
                        COALESCE(SUM(o.grand_total), 0) as total_spent,
                        COUNT(o.id) as order_count
                    FROM customers c
                    LEFT JOIN orders o ON c.id = o.customer_id 
                        AND o.status = 'delivered'
                        AND o.order_date BETWEEN '$start_date' AND '$end_date 23:59:59'
                    GROUP BY c.id
                ) as customer_stats
                GROUP BY segment
                ORDER BY FIELD(segment, 'Premium', 'Gold', 'Silver', 'Bronze')";

$segment_result = mysqli_query($conn, $segment_sql);

// 7. AVERAGE ORDER VALUE TREND
$aov_sql = "SELECT 
                DATE_FORMAT(o.order_date, '%Y-%m') as month,
                AVG(o.grand_total) as avg_order_value,
                COUNT(o.id) as order_count
            FROM orders o
            WHERE o.status = 'delivered' 
                AND o.order_date >= DATE_SUB('$end_date', INTERVAL 6 MONTH)
            GROUP BY DATE_FORMAT(o.order_date, '%Y-%m')
            ORDER BY month DESC
            LIMIT 6";

$aov_result = mysqli_query($conn, $aov_sql);
$aov_months = [];
$aov_values = [];
$aov_counts = [];

while ($row = mysqli_fetch_assoc($aov_result)) {
    $aov_months[] = date('M Y', strtotime($row['month'] . '-01'));
    $aov_values[] = (float)$row['avg_order_value'];
    $aov_counts[] = (int)$row['order_count'];
}

// Reverse for chronological order
$aov_months = array_reverse($aov_months);
$aov_values = array_reverse($aov_values);
$aov_counts = array_reverse($aov_counts);

// ==================== BUSINESS INSIGHTS ====================

// Inventory Turnover Rate (estimated)
$inventory_turnover = $sales_kpi['total_revenue'] > 0 && $inventory_kpi['inventory_value'] > 0 ?
    round($sales_kpi['total_revenue'] / $inventory_kpi['inventory_value'], 2) : 0;

// Customer Acquisition Cost (simulated - would need marketing cost data)
$cac = $customer_kpi['total_customers'] > 0 ? 
    round(($sales_kpi['total_revenue'] * 0.1) / $customer_kpi['total_customers'], 0) : 0; // Assuming 10% marketing spend

// Customer Lifetime Value (simplified)
$clv = $customer_kpi['total_customers'] > 0 ? 
    round($sales_kpi['total_revenue'] / $customer_kpi['total_customers'], 0) : 0;

// Conversion Rate (if we had leads data)
// $conversion_rate = 0;

// Stockout Rate
$stockout_rate = $inventory_kpi['total_products'] > 0 ? 
    round(($inventory_kpi['out_of_stock'] / $inventory_kpi['total_products']) * 100, 1) : 0;
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cosmetics WMS - Business Analytics</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    
    <style>
        :root {
            --primary: #667eea;
            --secondary: #764ba2;
            --success: #28a745;
            --info: #17a2b8;
            --warning: #ffc107;
            --danger: #dc3545;
        }
        
        .stat-card {
            border: none;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.08);
            transition: all 0.3s ease;
            margin-bottom: 20px;
            border-left: 5px solid var(--primary);
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 20px rgba(0,0,0,0.12);
        }
        
        .stat-icon {
            font-size: 2.5rem;
            opacity: 0.9;
        }
        
        .kpi-value {
            font-size: 1.8rem;
            font-weight: 700;
            margin-bottom: 0.25rem;
        }
        
        .kpi-label {
            font-size: 0.85rem;
            color: #6c757d;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .growth-badge {
            font-size: 0.75rem;
            padding: 3px 8px;
            border-radius: 10px;
        }
        
        .growth-up {
            background-color: rgba(40, 167, 69, 0.15);
            color: #28a745;
        }
        
        .growth-down {
            background-color: rgba(220, 53, 69, 0.15);
            color: #dc3545;
        }
        
        .chart-container {
            position: relative;
            height: 320px;
            width: 100%;
            margin-bottom: 20px;
        }
        
        .insight-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 20px;
        }
        
        .segment-badge {
            padding: 5px 12px;
            border-radius: 20px;
            font-weight: 600;
            font-size: 0.8rem;
        }
        
        .segment-premium { background: linear-gradient(135deg, #FFD700 0%, #FFA500 100%); color: #000; }
        .segment-gold { background: linear-gradient(135deg, #C0C0C0 0%, #A9A9A9 100%); color: #000; }
        .segment-silver { background: linear-gradient(135deg, #CD7F32 0%, #8B4513 100%); color: #fff; }
        .segment-bronze { background: linear-gradient(135deg, #8B4513 0%, #654321 100%); color: #fff; }
        
        .metric-tile {
            background: white;
            border-radius: 10px;
            padding: 15px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
            text-align: center;
            height: 100%;
        }
        
        .metric-value {
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--primary);
        }
        
        .metric-label {
            font-size: 0.8rem;
            color: #6c757d;
            margin-top: 5px;
        }
        
        .table-hover tbody tr:hover {
            background-color: rgba(102, 126, 234, 0.05);
        }
        
        .progress-thin {
            height: 8px;
            border-radius: 4px;
        }
        
        .time-filter-btn {
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 0.85rem;
            transition: all 0.3s;
        }
        
        .time-filter-btn.active {
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            color: white;
            border: none;
        }
    </style>
</head>
<body>
    <?php include $root_path . 'includes/sidebar.php'; ?>
    
    <div class="main-content" style="margin-left: 250px; padding: 25px;">
        <!-- HEADER -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h3 class="mb-1">📊 Business Analytics Dashboard</h3>
                <p class="text-muted mb-0">Comprehensive business intelligence and insights</p>
            </div>
            <div class="d-flex">
                <button onclick="window.print()" class="btn btn-secondary me-2">
                    <i class="fas fa-print"></i> Print Report
                </button>
                <a href="analytics_export.php?<?php echo http_build_query($_GET); ?>" 
                   class="btn btn-success">
                    <i class="fas fa-file-excel"></i> Export Data
                </a>
            </div>
        </div>
        
        <!-- TIME FILTER QUICK SELECT -->
        <div class="card mb-4">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div class="d-flex gap-2">
                        <a href="?time_frame=7d" class="time-filter-btn <?php echo $time_frame == '7d' ? 'active' : 'btn btn-outline-secondary'; ?>">
                            Last 7 Days
                        </a>
                        <a href="?time_frame=30d" class="time-filter-btn <?php echo $time_frame == '30d' ? 'active' : 'btn btn-outline-secondary'; ?>">
                            Last 30 Days
                        </a>
                        <a href="?time_frame=90d" class="time-filter-btn <?php echo $time_frame == '90d' ? 'active' : 'btn btn-outline-secondary'; ?>">
                            Last 90 Days
                        </a>
                        <a href="?time_frame=ytd" class="time-filter-btn <?php echo $time_frame == 'ytd' ? 'active' : 'btn btn-outline-secondary'; ?>">
                            Year to Date
                        </a>
                        <a href="?time_frame=1y" class="time-filter-btn <?php echo $time_frame == '1y' ? 'active' : 'btn btn-outline-secondary'; ?>">
                            Last Year
                        </a>
                    </div>
                    <div class="text-muted">
                        <i class="fas fa-calendar-alt"></i> 
                        <?php echo date('M d, Y', strtotime($start_date)); ?> - <?php echo date('M d, Y', strtotime($end_date)); ?>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- KPI METRICS ROW -->
        <div class="row mb-4">
            <!-- REVENUE KPI -->
            <div class="col-md-3">
                <div class="card stat-card">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-start">
                            <div>
                                <div class="kpi-value text-primary">
                                    Rp <?php echo number_format($sales_kpi['total_revenue'] ?? 0, 0, ',', '.'); ?>
                                </div>
                                <div class="kpi-label">Total Revenue</div>
                                <div class="mt-2">
                                    <span class="growth-badge <?php echo $revenue_growth >= 0 ? 'growth-up' : 'growth-down'; ?>">
                                        <i class="fas fa-arrow-<?php echo $revenue_growth >= 0 ? 'up' : 'down'; ?>"></i>
                                        <?php echo abs(round($revenue_growth, 1)); ?>%
                                    </span>
                                    <small class="text-muted ms-2">vs previous period</small>
                                </div>
                            </div>
                            <div class="stat-icon text-primary">
                                <i class="fas fa-money-bill-wave"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- ORDERS KPI -->
            <div class="col-md-3">
                <div class="card stat-card">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-start">
                            <div>
                                <div class="kpi-value text-success">
                                    <?php echo number_format($sales_kpi['total_orders'] ?? 0, 0, ',', '.'); ?>
                                </div>
                                <div class="kpi-label">Total Orders</div>
                                <div class="mt-2">
                                    <span class="badge bg-success">
                                        Avg: Rp <?php echo number_format($sales_kpi['avg_order_value'] ?? 0, 0, ',', '.'); ?>
                                    </span>
                                </div>
                            </div>
                            <div class="stat-icon text-success">
                                <i class="fas fa-shopping-cart"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- CUSTOMERS KPI -->
            <div class="col-md-3">
                <div class="card stat-card">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-start">
                            <div>
                                <div class="kpi-value text-warning">
                                    <?php echo number_format($customer_kpi['total_customers'] ?? 0, 0, ',', '.'); ?>
                                </div>
                                <div class="kpi-label">Total Customers</div>
                                <div class="mt-2">
                                    <span class="growth-badge <?php echo $customer_growth >= 0 ? 'growth-up' : 'growth-down'; ?>">
                                        <i class="fas fa-arrow-<?php echo $customer_growth >= 0 ? 'up' : 'down'; ?>"></i>
                                        <?php echo abs(round($customer_growth, 1)); ?>%
                                    </span>
                                    <small class="text-muted ms-2">new customers</small>
                                </div>
                            </div>
                            <div class="stat-icon text-warning">
                                <i class="fas fa-users"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- INVENTORY KPI -->
            <div class="col-md-3">
                <div class="card stat-card">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-start">
                            <div>
                                <div class="kpi-value text-info">
                                    <?php echo number_format($inventory_kpi['total_stock'] ?? 0, 0, ',', '.'); ?>
                                </div>
                                <div class="kpi-label">Total Stock Units</div>
                                <div class="mt-2">
                                    <span class="badge bg-danger">
                                        <?php echo $inventory_kpi['low_stock_items'] ?? 0; ?> low stock
                                    </span>
                                </div>
                            </div>
                            <div class="stat-icon text-info">
                                <i class="fas fa-boxes"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- REVENUE & ORDERS CHART -->
        <div class="row mb-4">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0">📈 Revenue & Orders Trend</h5>
                    </div>
                    <div class="card-body">
                        <div class="chart-container">
                            <canvas id="revenueChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- BUSINESS METRICS -->
            <div class="col-md-4">
                <div class="card h-100">
                    <div class="card-header bg-info text-white">
                        <h5 class="mb-0">📊 Business Metrics</h5>
                    </div>
                    <div class="card-body">
                        <div class="row g-3">
                            <div class="col-6">
                                <div class="metric-tile">
                                    <div class="metric-value">
                                        <?php echo $inventory_turnover; ?>x
                                    </div>
                                    <div class="metric-label">Inventory Turnover</div>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="metric-tile">
                                    <div class="metric-value">
                                        Rp <?php echo number_format($clv, 0, ',', '.'); ?>
                                    </div>
                                    <div class="metric-label">Avg. Customer Value</div>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="metric-tile">
                                    <div class="metric-value">
                                        Rp <?php echo number_format($cac, 0, ',', '.'); ?>
                                    </div>
                                    <div class="metric-label">Customer Acquisition Cost</div>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="metric-tile">
                                    <div class="metric-value">
                                        <?php echo $stockout_rate; ?>%
                                    </div>
                                    <div class="metric-label">Stockout Rate</div>
                                </div>
                            </div>
                        </div>
                        
                        <hr class="my-4">
                        
                        <h6 class="mb-3">Order Status Distribution</h6>
                        <?php if(mysqli_num_rows($status_result) > 0): ?>
                            <?php while($status = mysqli_fetch_assoc($status_result)): 
                                $status_color = match($status['status']) {
                                    'delivered' => 'success',
                                    'shipped' => 'info',
                                    'packing' => 'warning',
                                    'picking' => 'primary',
                                    default => 'secondary'
                                };
                            ?>
                            <div class="mb-2">
                                <div class="d-flex justify-content-between mb-1">
                                    <span><?php echo ucfirst($status['status']); ?></span>
                                    <span><?php echo $status['count']; ?> (<?php echo $status['percentage']; ?>%)</span>
                                </div>
                                <div class="progress progress-thin">
                                    <div class="progress-bar bg-<?php echo $status_color; ?>" 
                                         style="width: <?php echo $status['percentage']; ?>%">
                                    </div>
                                </div>
                            </div>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <div class="text-center py-3">
                                <div class="text-muted">No order status data</div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- CATEGORY & BRAND PERFORMANCE -->
        <div class="row mb-4">
            <!-- CATEGORY PERFORMANCE -->
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header bg-success text-white">
                        <h5 class="mb-0">🏷️ Category Performance</h5>
                    </div>
                    <div class="card-body">
                        <div class="chart-container">
                            <canvas id="categoryChart"></canvas>
                        </div>
                        <div class="mt-3">
                            <?php if(!empty($category_labels)): ?>
                                <?php for($i = 0; $i < min(5, count($category_labels)); $i++): ?>
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <div>
                                        <strong><?php echo $category_labels[$i]; ?></strong>
                                        <small class="text-muted ms-2"><?php echo $category_percent[$i]; ?>%</small>
                                    </div>
                                    <div class="text-end">
                                        <strong>Rp <?php echo number_format($category_revenue[$i], 0, ',', '.'); ?></strong>
                                    </div>
                                </div>
                                <?php endfor; ?>
                            <?php else: ?>
                                <div class="text-center py-4">
                                    <div class="text-muted">
                                        <i class="fas fa-tags fa-2x mb-3"></i><br>
                                        No category data available.
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- BRAND PERFORMANCE -->
            <div class="col-md-6">
                <div class="card h-100">
                    <div class="card-header bg-warning text-dark">
                        <h5 class="mb-0">⭐ Brand Performance</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Brand</th>
                                        <th>Orders</th>
                                        <th>Units Sold</th>
                                        <th>Revenue</th>
                                        <th>Avg. Price</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(mysqli_num_rows($brand_result) > 0): ?>
                                        <?php while($brand = mysqli_fetch_assoc($brand_result)): ?>
                                        <tr>
                                            <td>
                                                <strong><?php echo $brand['brand']; ?></strong>
                                            </td>
                                            <td>
                                                <span class="badge bg-info"><?php echo $brand['orders']; ?></span>
                                            </td>
                                            <td>
                                                <?php echo number_format($brand['quantity_sold'], 0, ',', '.'); ?>
                                            </td>
                                            <td>
                                                <strong class="text-success">
                                                    Rp <?php echo number_format($brand['revenue'], 0, ',', '.'); ?>
                                                </strong>
                                            </td>
                                            <td>
                                                Rp <?php echo number_format($brand['avg_price'], 0, ',', '.'); ?>
                                            </td>
                                        </tr>
                                        <?php endwhile; ?>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="5" class="text-center py-4">
                                                <div class="text-muted">
                                                    <i class="fas fa-star fa-2x mb-3"></i><br>
                                                    No brand performance data.
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- CUSTOMER SEGMENTATION & TOP PRODUCTS -->
        <div class="row mb-4">
            <!-- CUSTOMER SEGMENTATION -->
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header bg-dark text-white">
                        <h5 class="mb-0">👥 Customer Segmentation</h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <?php if(mysqli_num_rows($segment_result) > 0): ?>
                                <?php while($segment = mysqli_fetch_assoc($segment_result)): 
                                    $segment_class = 'segment-' . strtolower($segment['segment']);
                                ?>
                                <div class="col-md-6 mb-3">
                                    <div class="card h-100">
                                        <div class="card-body text-center">
                                            <span class="segment-badge <?php echo $segment_class; ?> mb-3">
                                                <?php echo $segment['segment']; ?>
                                            </span>
                                            <h4 class="mb-2"><?php echo $segment['customer_count']; ?> Customers</h4>
                                            <div class="text-muted mb-2">
                                                Rp <?php echo number_format($segment['segment_revenue'], 0, ',', '.'); ?> Revenue
                                            </div>
                                            <div class="small">
                                                Avg. <?php echo round($segment['avg_orders'], 1); ?> orders<br>
                                                Rp <?php echo number_format($segment['avg_spent'], 0, ',', '.'); ?> per customer
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <div class="col-12 text-center py-4">
                                    <div class="text-muted">
                                        <i class="fas fa-users fa-2x mb-3"></i><br>
                                        No customer segmentation data.
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- TOP 5 PRODUCTS -->
            <div class="col-md-6">
                <div class="card h-100">
                    <div class="card-header bg-danger text-white">
                        <h5 class="mb-0">🏆 Top 5 Products</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Product</th>
                                        <th>Category</th>
                                        <th>Sold</th>
                                        <th>Revenue</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(mysqli_num_rows($top_products_result) > 0): ?>
                                        <?php $rank = 1; ?>
                                        <?php while($product = mysqli_fetch_assoc($top_products_result)): ?>
                                        <tr>
                                            <td>
                                                <span class="badge bg-<?php echo ($rank <= 3) ? 'danger' : 'secondary'; ?>">
                                                    <?php echo $rank; ?>
                                                </span>
                                            </td>
                                            <td>
                                                <div>
                                                    <strong><?php echo $product['product_name']; ?></strong><br>
                                                    <small class="text-muted"><?php echo $product['sku']; ?></small>
                                                </div>
                                            </td>
                                            <td>
                                                <span class="badge bg-light text-dark"><?php echo $product['category']; ?></span>
                                            </td>
                                            <td>
                                                <?php echo number_format($product['quantity_sold'], 0, ',', '.'); ?> pcs
                                            </td>
                                            <td>
                                                <strong class="text-success">
                                                    Rp <?php echo number_format($product['revenue'], 0, ',', '.'); ?>
                                                </strong><br>
                                                <small class="text-muted">
                                                    Avg: Rp <?php echo number_format($product['avg_price'], 0, ',', '.'); ?>
                                                </small>
                                            </td>
                                        </tr>
                                        <?php $rank++; ?>
                                        <?php endwhile; ?>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="5" class="text-center py-4">
                                                <div class="text-muted">
                                                    <i class="fas fa-box fa-2x mb-3"></i><br>
                                                    No top products data.
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- AVERAGE ORDER VALUE TREND -->
        <div class="card mb-4">
            <div class="card-header bg-info text-white">
                <h5 class="mb-0">📊 Average Order Value Trend (Last 6 Months)</h5>
            </div>
            <div class="card-body">
                <div class="chart-container">
                    <canvas id="aovChart"></canvas>
                </div>
            </div>
        </div>
        
        <!-- BUSINESS INSIGHTS -->
        <div class="card">
            <div class="card-header bg-gradient text-white" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);">
                <h5 class="mb-0">💡 Business Insights & Recommendations</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-4">
                        <div class="insight-card">
                            <h5><i class="fas fa-chart-line"></i> Growth Opportunity</h5>
                            <p class="mb-0">
                                <?php if($revenue_growth > 0): ?>
                                    Revenue growing at <?php echo round($revenue_growth, 1); ?>% MoM. 
                                    Consider scaling marketing efforts.
                                <?php else: ?>
                                    Revenue declined <?php echo abs(round($revenue_growth, 1)); ?>%. 
                                    Review pricing strategy.
                                <?php endif; ?>
                            </p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="insight-card">
                            <h5><i class="fas fa-boxes"></i> Inventory Health</h5>
                            <p class="mb-0">
                                <?php if($inventory_kpi['low_stock_items'] > 0): ?>
                                    <?php echo $inventory_kpi['low_stock_items']; ?> items low on stock. 
                                    Time to reorder.
                                <?php else: ?>
                                    Inventory levels healthy. 
                                    Stockout rate at <?php echo $stockout_rate; ?>%.
                                <?php endif; ?>
                            </p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="insight-card">
                            <h5><i class="fas fa-users"></i> Customer Focus</h5>
                            <p class="mb-0">
                                <?php if($customer_growth > 0): ?>
                                    <?php echo round($customer_growth, 1); ?>% customer growth. 
                                    Focus on retention.
                                <?php else: ?>
                                    Need customer acquisition strategy. 
                                    Current CLV: Rp <?php echo number_format($clv, 0, ',', '.'); ?>.
                                <?php endif; ?>
                            </p>
                        </div>
                    </div>
                </div>
                
                <div class="row mt-4">
                    <div class="col-md-6">
                        <div class="alert alert-warning">
                            <h6><i class="fas fa-exclamation-triangle"></i> Key Areas for Improvement</h6>
                            <ul class="mb-0">
                                <li>Increase average order value through upselling</li>
                                <li>Reduce stockout rate from <?php echo $stockout_rate; ?>% to below 5%</li>
                                <li>Improve inventory turnover to <?php echo round($inventory_turnover + 1, 1); ?>x</li>
                                <li>Reduce customer acquisition cost by 15%</li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="alert alert-success">
                            <h6><i class="fas fa-check-circle"></i> What's Working Well</h6>
                            <ul class="mb-0">
                                <li>Healthy revenue growth trends</li>
                                <li>Strong performance in top product categories</li>
                                <li>Good customer segmentation mix</li>
                                <li>Effective order fulfillment process</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // REVENUE & ORDERS CHART
        const revenueCtx = document.getElementById('revenueChart').getContext('2d');
        const revenueChart = new Chart(revenueCtx, {
            type: 'line',
            data: {
                labels: <?php echo json_encode($revenue_dates); ?>,
                datasets: [
                    {
                        label: 'Revenue (Rp)',
                        data: <?php echo json_encode($revenue_data); ?>,
                        borderColor: 'rgba(102, 126, 234, 1)',
                        backgroundColor: 'rgba(102, 126, 234, 0.1)',
                        borderWidth: 2,
                        fill: true,
                        yAxisID: 'y'
                    },
                    {
                        label: 'Orders',
                        data: <?php echo json_encode($order_data); ?>,
                        borderColor: 'rgba(40, 167, 69, 1)',
                        backgroundColor: 'rgba(40, 167, 69, 0.1)',
                        borderWidth: 2,
                        fill: false,
                        yAxisID: 'y1'
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                interaction: {
                    mode: 'index',
                    intersect: false,
                },
                plugins: {
                    legend: {
                        display: true,
                        position: 'top'
                    }
                },
                scales: {
                    x: {
                        title: {
                            display: true,
                            text: 'Date'
                        }
                    },
                    y: {
                        type: 'linear',
                        display: true,
                        position: 'left',
                        title: {
                            display: true,
                            text: 'Revenue (Rp)'
                        },
                        ticks: {
                            callback: function(value) {
                                if (value >= 1000000) {
                                    return 'Rp ' + (value / 1000000).toFixed(1) + 'M';
                                } else if (value >= 1000) {
                                    return 'Rp ' + (value / 1000).toFixed(0) + 'K';
                                }
                                return 'Rp ' + value;
                            }
                        }
                    },
                    y1: {
                        type: 'linear',
                        display: true,
                        position: 'right',
                        title: {
                            display: true,
                            text: 'Orders'
                        },
                        grid: {
                            drawOnChartArea: false,
                        },
                    }
                }
            }
        });
        
        // CATEGORY PERFORMANCE CHART
        const categoryCtx = document.getElementById('categoryChart').getContext('2d');
        const categoryChart = new Chart(categoryCtx, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode($category_labels); ?>,
                datasets: [{
                    label: 'Revenue (Rp)',
                    data: <?php echo json_encode($category_revenue); ?>,
                    backgroundColor: [
                        'rgba(102, 126, 234, 0.8)',
                        'rgba(40, 167, 69, 0.8)',
                        'rgba(255, 193, 7, 0.8)',
                        'rgba(23, 162, 184, 0.8)',
                        'rgba(220, 53, 69, 0.8)',
                        'rgba(111, 66, 193, 0.8)',
                        'rgba(255, 87, 34, 0.8)'
                    ],
                    borderColor: [
                        'rgba(102, 126, 234, 1)',
                        'rgba(40, 167, 69, 1)',
                        'rgba(255, 193, 7, 1)',
                        'rgba(23, 162, 184, 1)',
                        'rgba(220, 53, 69, 1)',
                        'rgba(111, 66, 193, 1)',
                        'rgba(255, 87, 34, 1)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                if (value >= 1000000) {
                                    return 'Rp ' + (value / 1000000).toFixed(1) + 'M';
                                } else if (value >= 1000) {
                                    return 'Rp ' + (value / 1000).toFixed(0) + 'K';
                                }
                                return 'Rp ' + value;
                            }
                        }
                    }
                }
            }
        });
        
        // AVERAGE ORDER VALUE CHART
        const aovCtx = document.getElementById('aovChart').getContext('2d');
        const aovChart = new Chart(aovCtx, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode($aov_months); ?>,
                datasets: [
                    {
                        label: 'Avg. Order Value (Rp)',
                        data: <?php echo json_encode($aov_values); ?>,
                        backgroundColor: 'rgba(23, 162, 184, 0.8)',
                        borderColor: 'rgba(23, 162, 184, 1)',
                        borderWidth: 1,
                        yAxisID: 'y'
                    },
                    {
                        label: 'Order Count',
                        data: <?php echo json_encode($aov_counts); ?>,
                        backgroundColor: 'rgba(40, 167, 69, 0.3)',
                        borderColor: 'rgba(40, 167, 69, 1)',
                        borderWidth: 1,
                        type: 'line',
                        yAxisID: 'y1'
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: true,
                        position: 'top'
                    }
                },
                scales: {
                    x: {
                        title: {
                            display: true,
                            text: 'Month'
                        }
                    },
                    y: {
                        type: 'linear',
                        display: true,
                        position: 'left',
                        title: {
                            display: true,
                            text: 'Avg. Order Value (Rp)'
                        },
                        ticks: {
                            callback: function(value) {
                                if (value >= 1000000) {
                                    return 'Rp ' + (value / 1000000).toFixed(1) + 'M';
                                } else if (value >= 1000) {
                                    return 'Rp ' + (value / 1000).toFixed(0) + 'K';
                                }
                                return 'Rp ' + value;
                            }
                        }
                    },
                    y1: {
                        type: 'linear',
                        display: true,
                        position: 'right',
                        title: {
                            display: true,
                            text: 'Order Count'
                        },
                        grid: {
                            drawOnChartArea: false,
                        }
                    }
                }
            }
        });
        
        // AUTO REFRESH EVERY 15 MINUTES
        setTimeout(function() {
            location.reload();
        }, 900000); // 15 minutes
        
        // PRINT FUNCTION
        function printReport() {
            window.print();
        }
        
        // INITIALIZE TOOLTIPS
        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });
    </script>
</body>
</html>