<?php
// modules/reports/sales.php
$root_path = dirname(dirname(dirname(__FILE__))) . '/';
require_once $root_path . 'includes/config.php';
require_once $root_path . 'includes/auth.php';
checkLogin();

$active_menu = 'reports';
$page_title = "Sales Report";

// SET DEFAULT DATE RANGE (Last 30 days)
$start_date = isset($_GET['start_date']) ? $_GET['start_date'] : date('Y-m-d', strtotime('-30 days'));
$end_date = isset($_GET['end_date']) ? $_GET['end_date'] : date('Y-m-d');
$group_by = isset($_GET['group_by']) ? $_GET['group_by'] : 'daily';

// VALIDATE DATES
if (!empty($start_date) && !empty($end_date) && $start_date > $end_date) {
    $temp = $start_date;
    $start_date = $end_date;
    $end_date = $temp;
}

// BUILD SQL BASED ON GROUP BY
switch($group_by) {
    case 'daily':
        $date_format = "DATE(o.order_date) as period";
        $group_sql = "DATE(o.order_date)";
        $order_sql = "DATE(o.order_date) DESC";
        $chart_label = "Harian";
        break;
    case 'weekly':
        $date_format = "CONCAT('Week ', WEEK(o.order_date), ' - ', YEAR(o.order_date)) as period";
        $group_sql = "YEARWEEK(o.order_date)";
        $order_sql = "YEARWEEK(o.order_date) DESC";
        $chart_label = "Mingguan";
        break;
    case 'monthly':
        $date_format = "CONCAT(MONTHNAME(o.order_date), ' ', YEAR(o.order_date)) as period";
        $group_sql = "YEAR(o.order_date), MONTH(o.order_date)";
        $order_sql = "YEAR(o.order_date) DESC, MONTH(o.order_date) DESC";
        $chart_label = "Bulanan";
        break;
    case 'yearly':
        $date_format = "YEAR(o.order_date) as period";
        $group_sql = "YEAR(o.order_date)";
        $order_sql = "YEAR(o.order_date) DESC";
        $chart_label = "Tahunan";
        break;
    default:
        $date_format = "DATE(o.order_date) as period";
        $group_sql = "DATE(o.order_date)";
        $order_sql = "DATE(o.order_date) DESC";
        $chart_label = "Harian";
}

// GET SALES SUMMARY
$sales_sql = "SELECT 
                $date_format,
                COUNT(o.id) as total_orders,
                SUM(o.total_amount) as total_sales,
                AVG(o.total_amount) as avg_order_value,
                SUM(oi.quantity) as total_items
              FROM orders o
              LEFT JOIN order_items oi ON o.id = oi.order_id
              WHERE o.status = 'delivered' 
                AND o.order_date BETWEEN '$start_date' AND '$end_date 23:59:59'
              GROUP BY $group_sql
              ORDER BY $order_sql";

$sales_result = mysqli_query($conn, $sales_sql);

// GET TOP PRODUCTS
$top_products_sql = "SELECT 
                      p.name as product_name,
                      p.sku,
                      SUM(oi.quantity) as total_sold,
                      SUM(oi.quantity * oi.unit_price) as revenue
                    FROM order_items oi
                    JOIN products p ON oi.product_id = p.id
                    JOIN orders o ON oi.order_id = o.id
                    WHERE o.status = 'delivered' 
                      AND o.order_date BETWEEN '$start_date' AND '$end_date 23:59:59'
                    GROUP BY p.id
                    ORDER BY total_sold DESC
                    LIMIT 10";

$top_products_result = mysqli_query($conn, $top_products_sql);

// GET TOP CUSTOMERS
$top_customers_sql = "SELECT 
                       c.name as customer_name,
                       c.email,
                       COUNT(o.id) as total_orders,
                       SUM(o.total_amount) as total_spent
                     FROM orders o
                     JOIN customers c ON o.customer_id = c.id
                     WHERE o.status = 'delivered' 
                       AND o.order_date BETWEEN '$start_date' AND '$end_date 23:59:59'
                     GROUP BY c.id
                     ORDER BY total_spent DESC
                     LIMIT 10";

$top_customers_result = mysqli_query($conn, $top_customers_sql);

// GET OVERALL STATS
$stats_sql = "SELECT 
                COUNT(o.id) as total_orders,
                SUM(o.total_amount) as total_revenue,
                AVG(o.total_amount) as avg_order_value,
                MIN(o.total_amount) as min_order,
                MAX(o.total_amount) as max_order,
                COUNT(DISTINCT o.customer_id) as total_customers
              FROM orders o
              WHERE o.status = 'delivered' 
                AND o.order_date BETWEEN '$start_date' AND '$end_date 23:59:59'";

$stats_result = mysqli_query($conn, $stats_sql);
$stats = mysqli_fetch_assoc($stats_result);

// PREPARE DATA FOR CHART
$chart_labels = [];
$chart_data = [];
$chart_bg_colors = [];

if(mysqli_num_rows($sales_result) > 0) {
    mysqli_data_seek($sales_result, 0);
    while($row = mysqli_fetch_assoc($sales_result)) {
        $chart_labels[] = $row['period'];
        $chart_data[] = (float)$row['total_sales'];
        $chart_bg_colors[] = '#' . substr(md5(rand()), 0, 6); // Random colors
    }
    // Reverse untuk chart dari kiri ke kanan
    $chart_labels = array_reverse($chart_labels);
    $chart_data = array_reverse($chart_data);
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cosmetics WMS - Sales Report</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    
    <style>
        .stat-card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.08);
            transition: all 0.3s;
            margin-bottom: 20px;
        }
        
        .stat-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        .stat-icon {
            font-size: 2.5rem;
            opacity: 0.8;
        }
        
        .revenue-text {
            color: #28a745;
            font-weight: bold;
        }
        
        .orders-text {
            color: #007bff;
            font-weight: bold;
        }
        
        .customers-text {
            color: #ffc107;
            font-weight: bold;
        }
        
        .avg-text {
            color: #17a2b8;
            font-weight: bold;
        }
        
        .table-hover tbody tr:hover {
            background-color: rgba(0,123,255,0.05);
        }
        
        .chart-container {
            position: relative;
            height: 400px;
            width: 100%;
        }
    </style>
</head>
<body>
    <?php include $root_path . 'includes/sidebar.php'; ?>
    
    <div class="main-content" style="margin-left: 250px; padding: 25px;">
        <!-- HEADER -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h3 class="mb-1">📈 Sales Report</h3>
                <p class="text-muted mb-0">Analytics and sales performance</p>
            </div>
            <div class="d-flex">
                <button onclick="window.print()" class="btn btn-secondary me-2">
                    <i class="fas fa-print"></i> Print
                </button>
                <button id="exportBtn" class="btn btn-success">
                    <i class="fas fa-file-excel"></i> Export Excel
                </button>
            </div>
        </div>
        
        <!-- FILTERS -->
        <div class="card mb-4">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0">📅 Filter Report</h5>
            </div>
            <div class="card-body">
                <form method="GET" action="" class="row g-3">
                    <div class="col-md-3">
                        <label class="form-label">Start Date</label>
                        <input type="date" name="start_date" class="form-control" 
                               value="<?php echo $start_date; ?>" required>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">End Date</label>
                        <input type="date" name="end_date" class="form-control" 
                               value="<?php echo $end_date; ?>" required>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Group By</label>
                        <select name="group_by" class="form-select">
                            <option value="daily" <?php echo ($group_by == 'daily') ? 'selected' : ''; ?>>Daily</option>
                            <option value="weekly" <?php echo ($group_by == 'weekly') ? 'selected' : ''; ?>>Weekly</option>
                            <option value="monthly" <?php echo ($group_by == 'monthly') ? 'selected' : ''; ?>>Monthly</option>
                            <option value="yearly" <?php echo ($group_by == 'yearly') ? 'selected' : ''; ?>>Yearly</option>
                        </select>
                    </div>
                    <div class="col-md-3 d-flex align-items-end">
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="fas fa-filter"></i> Apply Filter
                        </button>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- SUMMARY STATS -->
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="card stat-card border-left-primary">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-1">Total Revenue</h6>
                                <h3 class="revenue-text mb-0">
                                    Rp <?php echo number_format($stats['total_revenue'] ?? 0, 0, ',', '.'); ?>
                                </h3>
                                <small class="text-muted"><?php echo date('M d', strtotime($start_date)); ?> - <?php echo date('M d, Y', strtotime($end_date)); ?></small>
                            </div>
                            <div class="stat-icon text-success">
                                <i class="fas fa-money-bill-wave"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3">
                <div class="card stat-card border-left-info">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-1">Total Orders</h6>
                                <h3 class="orders-text mb-0">
                                    <?php echo number_format($stats['total_orders'] ?? 0, 0, ',', '.'); ?>
                                </h3>
                                <small class="text-muted">Delivered orders only</small>
                            </div>
                            <div class="stat-icon text-info">
                                <i class="fas fa-shopping-cart"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3">
                <div class="card stat-card border-left-warning">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-1">Active Customers</h6>
                                <h3 class="customers-text mb-0">
                                    <?php echo number_format($stats['total_customers'] ?? 0, 0, ',', '.'); ?>
                                </h3>
                                <small class="text-muted">Unique customers</small>
                            </div>
                            <div class="stat-icon text-warning">
                                <i class="fas fa-users"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3">
                <div class="card stat-card border-left-success">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-1">Avg. Order Value</h6>
                                <h3 class="avg-text mb-0">
                                    Rp <?php echo number_format($stats['avg_order_value'] ?? 0, 0, ',', '.'); ?>
                                </h3>
                                <small class="text-muted">Per transaction</small>
                            </div>
                            <div class="stat-icon text-primary">
                                <i class="fas fa-chart-line"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- SALES CHART -->
        <div class="card mb-4">
            <div class="card-header bg-success text-white d-flex justify-content-between align-items-center">
                <h5 class="mb-0">📊 Sales Trend (<?php echo $chart_label; ?>)</h5>
                <div class="text-white">
                    <i class="fas fa-calendar-alt"></i> 
                    <?php echo date('M d, Y', strtotime($start_date)); ?> - <?php echo date('M d, Y', strtotime($end_date)); ?>
                </div>
            </div>
            <div class="card-body">
                <div class="chart-container">
                    <canvas id="salesChart"></canvas>
                </div>
            </div>
        </div>
        
        <div class="row">
            <!-- TOP PRODUCTS -->
            <div class="col-md-6">
                <div class="card mb-4">
                    <div class="card-header bg-warning text-dark">
                        <h5 class="mb-0">🏆 Top 10 Products</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Product</th>
                                        <th>SKU</th>
                                        <th>Sold</th>
                                        <th>Revenue</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(mysqli_num_rows($top_products_result) > 0): ?>
                                        <?php $rank = 1; ?>
                                        <?php while($product = mysqli_fetch_assoc($top_products_result)): ?>
                                        <tr>
                                            <td>
                                                <span class="badge bg-<?php echo ($rank <= 3) ? 'warning text-dark' : 'secondary'; ?>">
                                                    <?php echo $rank; ?>
                                                </span>
                                            </td>
                                            <td>
                                                <strong><?php echo $product['product_name']; ?></strong>
                                            </td>
                                            <td>
                                                <span class="badge bg-light text-dark"><?php echo $product['sku']; ?></span>
                                            </td>
                                            <td>
                                                <span class="badge bg-info"><?php echo $product['total_sold']; ?> pcs</span>
                                            </td>
                                            <td>
                                                <strong class="text-success">Rp <?php echo number_format($product['revenue'], 0, ',', '.'); ?></strong>
                                            </td>
                                        </tr>
                                        <?php $rank++; ?>
                                        <?php endwhile; ?>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="5" class="text-center py-4">
                                                <div class="text-muted">
                                                    <i class="fas fa-box-open fa-2x mb-3"></i><br>
                                                    No products sold in this period.
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- TOP CUSTOMERS -->
            <div class="col-md-6">
                <div class="card mb-4">
                    <div class="card-header bg-info text-white">
                        <h5 class="mb-0">👥 Top 10 Customers</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Customer</th>
                                        <th>Email</th>
                                        <th>Orders</th>
                                        <th>Total Spent</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(mysqli_num_rows($top_customers_result) > 0): ?>
                                        <?php $rank = 1; ?>
                                        <?php while($customer = mysqli_fetch_assoc($top_customers_result)): ?>
                                        <tr>
                                            <td>
                                                <span class="badge bg-<?php echo ($rank <= 3) ? 'primary' : 'secondary'; ?>">
                                                    <?php echo $rank; ?>
                                                </span>
                                            </td>
                                            <td>
                                                <strong><?php echo $customer['customer_name']; ?></strong>
                                            </td>
                                            <td>
                                                <small><?php echo $customer['email']; ?></small>
                                            </td>
                                            <td>
                                                <span class="badge bg-warning text-dark"><?php echo $customer['total_orders']; ?> orders</span>
                                            </td>
                                            <td>
                                                <strong class="text-primary">Rp <?php echo number_format($customer['total_spent'], 0, ',', '.'); ?></strong>
                                            </td>
                                        </tr>
                                        <?php $rank++; ?>
                                        <?php endwhile; ?>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="5" class="text-center py-4">
                                                <div class="text-muted">
                                                    <i class="fas fa-users fa-2x mb-3"></i><br>
                                                    No customer data in this period.
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- SALES DETAILS TABLE -->
        <div class="card">
            <div class="card-header bg-dark text-white">
                <h5 class="mb-0">📋 Sales Details (<?php echo $chart_label; ?>)</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover table-striped">
                        <thead class="table-dark">
                            <tr>
                                <th>Period</th>
                                <th>Orders</th>
                                <th>Items Sold</th>
                                <th>Total Sales</th>
                                <th>Avg. Order Value</th>
                                <th>Details</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(mysqli_num_rows($sales_result) > 0): ?>
                                <?php mysqli_data_seek($sales_result, 0); ?>
                                <?php $grand_total = 0; ?>
                                <?php while($sales = mysqli_fetch_assoc($sales_result)): 
                                    $grand_total += $sales['total_sales'];
                                ?>
                                <tr>
                                    <td>
                                        <strong><?php echo $sales['period']; ?></strong>
                                    </td>
                                    <td>
                                        <span class="badge bg-primary"><?php echo $sales['total_orders']; ?> orders</span>
                                    </td>
                                    <td>
                                        <?php echo number_format($sales['total_items'], 0, ',', '.'); ?> pcs
                                    </td>
                                    <td>
                                        <strong class="text-success">Rp <?php echo number_format($sales['total_sales'], 0, ',', '.'); ?></strong>
                                    </td>
                                    <td>
                                        Rp <?php echo number_format($sales['avg_order_value'], 0, ',', '.'); ?>
                                    </td>
                                    <td>
                                        <a href="#" class="btn btn-sm btn-outline-info">
                                            <i class="fas fa-search"></i> View
                                        </a>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                                <!-- GRAND TOTAL ROW -->
                                <tr class="table-success">
                                    <td colspan="3" class="text-end">
                                        <strong>GRAND TOTAL:</strong>
                                    </td>
                                    <td colspan="3">
                                        <h5 class="text-success mb-0">
                                            Rp <?php echo number_format($grand_total, 0, ',', '.'); ?>
                                        </h5>
                                    </td>
                                </tr>
                            <?php else: ?>
                                <tr>
                                    <td colspan="6" class="text-center py-4">
                                        <div class="text-muted">
                                            <i class="fas fa-chart-bar fa-2x mb-3"></i><br>
                                            No sales data in this period.
                                        </div>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // SALES CHART
        const ctx = document.getElementById('salesChart').getContext('2d');
        const salesChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode($chart_labels); ?>,
                datasets: [{
                    label: 'Sales (Rp)',
                    data: <?php echo json_encode($chart_data); ?>,
                    backgroundColor: [
                        'rgba(40, 167, 69, 0.7)',
                        'rgba(0, 123, 255, 0.7)',
                        'rgba(255, 193, 7, 0.7)',
                        'rgba(23, 162, 184, 0.7)',
                        'rgba(220, 53, 69, 0.7)',
                        'rgba(108, 117, 125, 0.7)',
                        'rgba(111, 66, 193, 0.7)'
                    ],
                    borderColor: [
                        'rgba(40, 167, 69, 1)',
                        'rgba(0, 123, 255, 1)',
                        'rgba(255, 193, 7, 1)',
                        'rgba(23, 162, 184, 1)',
                        'rgba(220, 53, 69, 1)',
                        'rgba(108, 117, 125, 1)',
                        'rgba(111, 66, 193, 1)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: true,
                        position: 'top'
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                let label = context.dataset.label || '';
                                if (label) {
                                    label += ': ';
                                }
                                if (context.parsed.y !== null) {
                                    label += new Intl.NumberFormat('id-ID', {
                                        style: 'currency',
                                        currency: 'IDR',
                                        minimumFractionDigits: 0
                                    }).format(context.parsed.y);
                                }
                                return label;
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                if (value >= 1000000) {
                                    return 'Rp ' + (value / 1000000).toFixed(1) + 'M';
                                } else if (value >= 1000) {
                                    return 'Rp ' + (value / 1000).toFixed(0) + 'K';
                                }
                                return 'Rp ' + value;
                            }
                        }
                    }
                }
            }
        });
        
        // EXPORT TO EXCEL FUNCTION
        document.getElementById('exportBtn').addEventListener('click', function() {
            alert('Export to Excel feature will be implemented soon!');
            // You can implement actual export using PHPExcel or similar library
        });
        
        // AUTO REFRESH EVERY 5 MINUTES (optional)
        setTimeout(function() {
            location.reload();
        }, 300000); // 5 minutes
    </script>
</body>
</html>