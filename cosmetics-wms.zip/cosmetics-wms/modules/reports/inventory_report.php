<?php
// modules/reports/inventory_report.php
$root_path = dirname(dirname(dirname(__FILE__))) . '/';
require_once $root_path . 'includes/config.php';
require_once $root_path . 'includes/auth.php';
checkLogin();

$active_menu = 'reports';
$page_title = "Inventory Report";

// FILTERS
$category_id = isset($_GET['category_id']) ? (int)$_GET['category_id'] : '';
$low_stock = isset($_GET['low_stock']) ? true : false;
$expiring_soon = isset($_GET['expiring_soon']) ? true : false;
$out_of_stock = isset($_GET['out_of_stock']) ? true : false;
$search = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : '';

// BUILD WHERE CLAUSE UNTUK PRODUCTS
$where = "p.status = 'active'";
if ($low_stock) {
    $where .= " AND (SELECT COALESCE(SUM(pb.current_quantity), 0) 
                     FROM product_batches pb 
                     WHERE pb.product_id = p.id AND pb.status = 'released') <= p.min_stock";
}
if (!empty($category_id)) {
    $where .= " AND p.category_id = $category_id";
}
if (!empty($search)) {
    $where .= " AND (p.name LIKE '%$search%' OR p.sku LIKE '%$search%')";
}

// GET CATEGORIES FOR FILTER
$categories_sql = "SELECT id, name FROM categories ORDER BY name";
$categories_result = mysqli_query($conn, $categories_sql);

// GET INVENTORY DATA
$inventory_sql = "SELECT 
                    p.id,
                    p.sku,
                    p.name as product_name,
                    c.name as category_name,
                    b.name as brand_name,
                    p.min_stock,
                    p.max_stock,
                    p.unit_price,
                    p.weight_volume,
                    p.halal_certified,
                    -- Calculate total stock from batches
                    COALESCE(SUM(pb.current_quantity), 0) as total_stock,
                    -- Calculate total inventory value
                    COALESCE(SUM(pb.current_quantity * pb.purchase_price), 0) as inventory_value,
                    -- Calculate average cost price
                    COALESCE(AVG(pb.purchase_price), p.unit_price) as avg_cost_price,
                    -- Get nearest expiry date
                    MIN(pb.expiry_date) as nearest_expiry,
                    -- Count active batches
                    COUNT(pb.id) as batch_count
                  FROM products p
                  LEFT JOIN categories c ON p.category_id = c.id
                  LEFT JOIN brands b ON p.brand_id = b.id
                  LEFT JOIN product_batches pb ON p.id = pb.product_id AND pb.status = 'released'
                  WHERE $where
                  GROUP BY p.id
                  ORDER BY 
                    CASE 
                      WHEN COALESCE(SUM(pb.current_quantity), 0) = 0 THEN 1
                      WHEN COALESCE(SUM(pb.current_quantity), 0) <= p.min_stock THEN 2
                      ELSE 3 
                    END,
                    p.name ASC";

$inventory_result = mysqli_query($conn, $inventory_sql);

// GET INVENTORY SUMMARY - QUERY YANG DIPERBAIKI
$summary_sql = "SELECT 
                  -- Total Products
                  (SELECT COUNT(*) FROM products WHERE status = 'active') as total_products,
                  
                  -- Total Stock Items from released batches
                  (SELECT COALESCE(SUM(current_quantity), 0) 
                   FROM product_batches WHERE status = 'released') as total_items,
                  
                  -- Total Inventory Value
                  (SELECT COALESCE(SUM(current_quantity * purchase_price), 0) 
                   FROM product_batches WHERE status = 'released') as total_inventory_value,
                  
                  -- Retail Value (using product unit_price)
                  (SELECT COALESCE(SUM(pb.current_quantity * p.unit_price), 0)
                   FROM product_batches pb
                   JOIN products p ON pb.product_id = p.id
                   WHERE pb.status = 'released') as total_retail_value,
                  
                  -- Out of Stock Products (Cara lebih sederhana)
                  (SELECT COUNT(*)
                   FROM (
                       SELECT p.id, COALESCE(SUM(pb.current_quantity), 0) as total_stock
                       FROM products p
                       LEFT JOIN product_batches pb ON p.id = pb.product_id AND pb.status = 'released'
                       WHERE p.status = 'active'
                       GROUP BY p.id
                   ) as product_stock
                   WHERE total_stock = 0) as out_of_stock_count,
                  
                  -- Low Stock Products (Cara lebih sederhana)
                  (SELECT COUNT(*)
                   FROM (
                       SELECT p.id, p.min_stock, COALESCE(SUM(pb.current_quantity), 0) as total_stock
                       FROM products p
                       LEFT JOIN product_batches pb ON p.id = pb.product_id AND pb.status = 'released'
                       WHERE p.status = 'active'
                       GROUP BY p.id
                       HAVING total_stock > 0
                   ) as product_stock
                   WHERE total_stock <= min_stock) as low_stock_count,
                  
                  -- Expired Batches
                  (SELECT COUNT(*) 
                   FROM product_batches 
                   WHERE status = 'released' AND expiry_date < CURDATE()) as expired_count,
                  
                  -- Expiring Soon (within 30 days)
                  (SELECT COUNT(*) 
                   FROM product_batches 
                   WHERE status = 'released' 
                     AND expiry_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)) as expiring_soon_count";

$summary_result = mysqli_query($conn, $summary_sql);
if (!$summary_result) {
    echo "Error in summary query: " . mysqli_error($conn);
    // Fallback values
    $summary = [
        'total_products' => 0,
        'total_items' => 0,
        'total_inventory_value' => 0,
        'total_retail_value' => 0,
        'out_of_stock_count' => 0,
        'low_stock_count' => 0,
        'expired_count' => 0,
        'expiring_soon_count' => 0
    ];
} else {
    $summary = mysqli_fetch_assoc($summary_result);
}

// GET TOP MOVING PRODUCTS (Last 30 days)
$top_moving_sql = "SELECT 
                     p.name as product_name,
                     p.sku,
                     SUM(oi.quantity) as total_sold,
                     COALESCE(SUM(pb.current_quantity), 0) as current_stock
                   FROM order_items oi
                   JOIN products p ON oi.product_id = p.id
                   JOIN orders o ON oi.order_id = o.id
                   LEFT JOIN product_batches pb ON p.id = pb.product_id AND pb.status = 'released'
                   WHERE o.order_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
                     AND o.status IN ('delivered', 'shipped')
                   GROUP BY p.id
                   ORDER BY total_sold DESC
                   LIMIT 10";

$top_moving_result = mysqli_query($conn, $top_moving_sql);

// GET PRODUCT BATCHES DETAILS untuk report expiring
$expiring_sql = "SELECT 
                    p.name as product_name,
                    p.sku,
                    pb.batch_number,
                    pb.expiry_date,
                    DATEDIFF(pb.expiry_date, CURDATE()) as days_remaining,
                    pb.current_quantity,
                    pb.status
                 FROM product_batches pb
                 JOIN products p ON pb.product_id = p.id
                 WHERE pb.status = 'released'
                   AND pb.expiry_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 90 DAY)
                 ORDER BY pb.expiry_date ASC
                 LIMIT 20";

$expiring_result = mysqli_query($conn, $expiring_sql);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cosmetics WMS - Inventory Report</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css">
    
    <style>
        .summary-card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.08);
            transition: all 0.3s;
            margin-bottom: 20px;
        }
        
        .summary-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        .summary-icon {
            font-size: 2rem;
            opacity: 0.8;
        }
        
        .stock-low {
            color: #ffc107;
            font-weight: bold;
        }
        
        .stock-out {
            color: #dc3545;
            font-weight: bold;
        }
        
        .stock-good {
            color: #28a745;
            font-weight: bold;
        }
        
        .stock-expired {
            color: #dc3545;
            font-weight: bold;
        }
        
        .stock-expiring {
            color: #ffc107;
            font-weight: bold;
        }
        
        .progress {
            height: 10px;
            margin-top: 5px;
        }
        
        .halal-badge {
            background: linear-gradient(45deg, #28a745, #20c997);
            color: white;
        }
        
        .non-halal-badge {
            background: #6c757d;
            color: white;
        }
        
        .batch-badge {
            font-size: 11px;
            padding: 2px 8px;
        }
        
        .alert-danger {
            background-color: #f8d7da;
            border-color: #f5c6cb;
            color: #721c24;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 15px;
        }
    </style>
</head>
<body>
    <?php include $root_path . 'includes/sidebar.php'; ?>
    
    <div class="main-content" style="margin-left: 250px; padding: 25px;">
        <!-- HEADER -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h3 class="mb-1">📦 Inventory Report</h3>
                <p class="text-muted mb-0">Cosmetics Warehouse Management System</p>
            </div>
            <div class="d-flex">
                <button onclick="window.print()" class="btn btn-secondary me-2">
                    <i class="fas fa-print"></i> Print
                </button>
                <button class="btn btn-success" onclick="exportToExcel()">
                    <i class="fas fa-file-excel"></i> Export
                </button>
            </div>
        </div>
        
        <!-- SUMMARY STATS -->
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="card summary-card border-left-primary">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-1">Total Products</h6>
                                <h3 class="text-primary mb-0">
                                    <?php echo number_format($summary['total_products'] ?? 0, 0, ',', '.'); ?>
                                </h3>
                                <small class="text-muted">Active products</small>
                            </div>
                            <div class="summary-icon text-primary">
                                <i class="fas fa-boxes"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3">
                <div class="card summary-card border-left-info">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-1">Total Stock Items</h6>
                                <h3 class="text-info mb-0">
                                    <?php echo number_format($summary['total_items'] ?? 0, 0, ',', '.'); ?>
                                </h3>
                                <small class="text-muted">In warehouse</small>
                            </div>
                            <div class="summary-icon text-info">
                                <i class="fas fa-cubes"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3">
                <div class="card summary-card border-left-warning">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-1">Low Stock</h6>
                                <h3 class="stock-low mb-0">
                                    <?php echo number_format($summary['low_stock_count'] ?? 0, 0, ',', '.'); ?>
                                </h3>
                                <small class="text-muted">Below minimum</small>
                            </div>
                            <div class="summary-icon text-warning">
                                <i class="fas fa-exclamation-triangle"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3">
                <div class="card summary-card border-left-danger">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-1">Out of Stock</h6>
                                <h3 class="stock-out mb-0">
                                    <?php echo number_format($summary['out_of_stock_count'] ?? 0, 0, ',', '.'); ?>
                                </h3>
                                <small class="text-muted">Zero inventory</small>
                            </div>
                            <div class="summary-icon text-danger">
                                <i class="fas fa-times-circle"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- FILTERS -->
        <div class="card mb-4">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0">🔍 Filter Inventory</h5>
            </div>
            <div class="card-body">
                <form method="GET" action="" class="row g-3">
                    <div class="col-md-4">
                        <input type="text" name="search" class="form-control" 
                               placeholder="Search product name or SKU..." 
                               value="<?php echo htmlspecialchars($search); ?>">
                    </div>
                    <div class="col-md-3">
                        <select name="category_id" class="form-select">
                            <option value="">All Categories</option>
                            <?php 
                            if ($categories_result && mysqli_num_rows($categories_result) > 0):
                                mysqli_data_seek($categories_result, 0);
                                while($cat = mysqli_fetch_assoc($categories_result)): 
                            ?>
                                <option value="<?php echo $cat['id']; ?>" 
                                    <?php echo ($category_id == $cat['id']) ? 'selected' : ''; ?>>
                                    <?php echo $cat['name']; ?>
                                </option>
                            <?php 
                                endwhile;
                            endif; 
                            ?>
                        </select>
                    </div>
                    <div class="col-md-5">
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="checkbox" name="low_stock" id="low_stock" 
                                   <?php echo $low_stock ? 'checked' : ''; ?>>
                            <label class="form-check-label" for="low_stock">
                                <span class="badge bg-warning">Low Stock Only</span>
                            </label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="checkbox" name="out_of_stock" id="out_of_stock" 
                                   <?php echo $out_of_stock ? 'checked' : ''; ?>>
                            <label class="form-check-label" for="out_of_stock">
                                <span class="badge bg-danger">Out of Stock Only</span>
                            </label>
                        </div>
                        <button type="submit" class="btn btn-primary btn-sm">
                            <i class="fas fa-filter"></i> Filter
                        </button>
                        <a href="inventory_report.php" class="btn btn-secondary btn-sm">
                            <i class="fas fa-redo"></i> Reset
                        </a>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- INVENTORY VALUE & EXPIRY -->
        <div class="row mb-4">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header bg-success text-white">
                        <h5 class="mb-0">💰 Inventory Value</h5>
                    </div>
                    <div class="card-body">
                        <div class="row text-center">
                            <div class="col-md-6">
                                <h6 class="text-muted">Cost Value</h6>
                                <h3 class="text-primary">
                                    Rp <?php echo number_format($summary['total_inventory_value'] ?? 0, 0, ',', '.'); ?>
                                </h3>
                                <small class="text-muted">Based on purchase price</small>
                            </div>
                            <div class="col-md-6">
                                <h6 class="text-muted">Retail Value</h6>
                                <h3 class="text-success">
                                    Rp <?php echo number_format($summary['total_retail_value'] ?? 0, 0, ',', '.'); ?>
                                </h3>
                                <small class="text-muted">Based on selling price</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header bg-warning text-dark">
                        <h5 class="mb-0">⚠️ Expiry Monitoring</h5>
                    </div>
                    <div class="card-body">
                        <div class="row text-center">
                            <div class="col-md-6">
                                <h6 class="text-muted">Expired Batches</h6>
                                <h3 class="stock-expired">
                                    <?php echo number_format($summary['expired_count'] ?? 0, 0, ',', '.'); ?>
                                </h3>
                                <small class="text-muted">Already expired</small>
                            </div>
                            <div class="col-md-6">
                                <h6 class="text-muted">Expiring Soon</h6>
                                <h3 class="stock-expiring">
                                    <?php echo number_format($summary['expiring_soon_count'] ?? 0, 0, ',', '.'); ?>
                                </h3>
                                <small class="text-muted">Within 30 days</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- INVENTORY TABLE -->
        <div class="card mb-4">
            <div class="card-header bg-dark text-white d-flex justify-content-between align-items-center">
                <h5 class="mb-0">📋 Product Inventory Summary</h5>
                <span class="badge bg-light text-dark">
                    <?php echo mysqli_num_rows($inventory_result); ?> products
                </span>
            </div>
            <div class="card-body">
                <?php if (!$inventory_result): ?>
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-triangle"></i> 
                        Error loading inventory data: <?php echo mysqli_error($conn); ?>
                    </div>
                <?php endif; ?>
                
                <div class="table-responsive">
                    <table class="table table-hover" id="inventoryTable">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Product Info</th>
                                <th>Category & Brand</th>
                                <th>Stock Info</th>
                                <th>Price</th>
                                <th>Value</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($inventory_result && mysqli_num_rows($inventory_result) > 0): ?>
                                <?php $counter = 1; ?>
                                <?php while($product = mysqli_fetch_assoc($inventory_result)): 
                                    // Determine stock status
                                    $stock_status = '';
                                    $stock_badge = '';
                                    $progress_color = '';
                                    $stock_percentage = 0;
                                    
                                    if ($product['total_stock'] == 0) {
                                        $stock_status = 'Out of Stock';
                                        $stock_badge = 'bg-danger';
                                        $progress_color = 'bg-danger';
                                    } elseif ($product['total_stock'] <= $product['min_stock']) {
                                        $stock_status = 'Low Stock';
                                        $stock_badge = 'bg-warning text-dark';
                                        $progress_color = 'bg-warning';
                                        $stock_percentage = ($product['total_stock'] / $product['min_stock']) * 100;
                                    } elseif ($product['max_stock'] > 0) {
                                        $stock_percentage = ($product['total_stock'] / $product['max_stock']) * 100;
                                        if ($stock_percentage >= 80) {
                                            $stock_status = 'High Stock';
                                            $stock_badge = 'bg-info';
                                            $progress_color = 'bg-info';
                                        } else {
                                            $stock_status = 'Normal';
                                            $stock_badge = 'bg-success';
                                            $progress_color = 'bg-success';
                                        }
                                    } else {
                                        $stock_status = 'Normal';
                                        $stock_badge = 'bg-success';
                                        $progress_color = 'bg-success';
                                    }
                                    
                                    if ($stock_percentage > 100) $stock_percentage = 100;
                                    
                                    // Expiry status
                                    $expiry_status = '';
                                    $expiry_badge = '';
                                    if (!empty($product['nearest_expiry'])) {
                                        $days_remaining = floor((strtotime($product['nearest_expiry']) - time()) / (60*60*24));
                                        if ($days_remaining < 0) {
                                            $expiry_status = 'Expired';
                                            $expiry_badge = 'bg-danger';
                                        } elseif ($days_remaining <= 30) {
                                            $expiry_status = $days_remaining . ' days';
                                            $expiry_badge = 'bg-warning text-dark';
                                        } else {
                                            $expiry_status = 'Good';
                                            $expiry_badge = 'bg-success';
                                        }
                                    } else {
                                        $expiry_status = 'No Batch';
                                        $expiry_badge = 'bg-secondary';
                                    }
                                ?>
                                <tr>
                                    <td><?php echo $counter++; ?></td>
                                    <td>
                                        <strong><?php echo $product['product_name']; ?></strong><br>
                                        <small class="text-muted">SKU: <?php echo $product['sku']; ?></small><br>
                                        <small class="text-muted">Size: <?php echo $product['weight_volume']; ?></small>
                                        <?php if($product['halal_certified']): ?>
                                            <span class="badge halal-badge batch-badge">Halal</span>
                                        <?php else: ?>
                                            <span class="badge non-halal-badge batch-badge">Non-Halal</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="badge bg-light text-dark"><?php echo $product['category_name']; ?></span><br>
                                        <small class="text-muted"><?php echo $product['brand_name']; ?></small>
                                    </td>
                                    <td>
                                        <div class="mb-2">
                                            <h5 class="mb-1 <?php 
                                                echo ($product['total_stock'] == 0) ? 'stock-out' : 
                                                     (($product['total_stock'] <= $product['min_stock']) ? 'stock-low' : 'stock-good'); 
                                            ?>">
                                                <?php echo number_format($product['total_stock'], 0, ',', '.'); ?>
                                            </h5>
                                            <small class="text-muted">
                                                Min: <?php echo $product['min_stock']; ?> | 
                                                Max: <?php echo $product['max_stock']; ?> |
                                                Batches: <?php echo $product['batch_count']; ?>
                                            </small>
                                        </div>
                                        <?php if($product['max_stock'] > 0): ?>
                                        <div class="progress" style="height: 8px;">
                                            <div class="progress-bar <?php echo $progress_color; ?>" 
                                                 role="progressbar" 
                                                 style="width: <?php echo $stock_percentage; ?>%">
                                            </div>
                                        </div>
                                        <?php endif; ?>
                                        <?php if(!empty($product['nearest_expiry'])): ?>
                                        <div class="mt-2">
                                            <small class="text-muted">Expiry: <?php echo date('M Y', strtotime($product['nearest_expiry'])); ?></small>
                                            <span class="badge <?php echo $expiry_badge; ?> ms-2">
                                                <?php echo $expiry_status; ?>
                                            </span>
                                        </div>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="mb-1">
                                            <small class="text-muted">Cost:</small><br>
                                            <strong>Rp <?php echo number_format($product['avg_cost_price'], 0, ',', '.'); ?></strong>
                                        </div>
                                        <div>
                                            <small class="text-muted">Price:</small><br>
                                            <strong class="text-success">Rp <?php echo number_format($product['unit_price'], 0, ',', '.'); ?></strong>
                                        </div>
                                    </td>
                                    <td>
                                        <strong class="text-primary">
                                            Rp <?php echo number_format($product['inventory_value'], 0, ',', '.'); ?>
                                        </strong><br>
                                        <small class="text-muted">Inventory Value</small>
                                    </td>
                                    <td>
                                        <span class="badge <?php echo $stock_badge; ?> mb-1">
                                            <?php echo $stock_status; ?>
                                        </span><br>
                                        <?php if($product['batch_count'] > 0): ?>
                                        <span class="badge bg-info">
                                            <?php echo $product['batch_count']; ?> batches
                                        </span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="btn-group" role="group">
                                            <a href="../products/view.php?id=<?php echo $product['id']; ?>" 
                                               class="btn btn-sm btn-info" title="View">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                            <a href="../inventory/batches.php?product_id=<?php echo $product['id']; ?>" 
                                               class="btn btn-sm btn-warning" title="Batches">
                                                <i class="fas fa-boxes"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="8" class="text-center py-4">
                                        <div class="text-muted">
                                            <i class="fas fa-box-open fa-2x mb-3"></i><br>
                                            No products found with current filters.
                                        </div>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        
        <!-- TWO COLUMNS: TOP MOVING & EXPIRING SOON -->
        <div class="row">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header bg-success text-white">
                        <h5 class="mb-0">🚀 Top Selling Products (30 Days)</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-sm">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Product</th>
                                        <th>Sold</th>
                                        <th>Stock</th>
                                        <th>Turnover</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if($top_moving_result && mysqli_num_rows($top_moving_result) > 0): ?>
                                        <?php $rank = 1; ?>
                                        <?php while($product = mysqli_fetch_assoc($top_moving_result)): 
                                            $turnover_rate = ($product['current_stock'] > 0) ? 
                                                ($product['total_sold'] / $product['current_stock']) * 100 : 100;
                                        ?>
                                        <tr>
                                            <td>
                                                <span class="badge bg-<?php echo ($rank <= 3) ? 'warning text-dark' : 'secondary'; ?>">
                                                    <?php echo $rank; ?>
                                                </span>
                                            </td>
                                            <td>
                                                <strong><?php echo $product['product_name']; ?></strong><br>
                                                <small class="text-muted"><?php echo $product['sku']; ?></small>
                                            </td>
                                            <td>
                                                <span class="badge bg-success"><?php echo $product['total_sold']; ?> pcs</span>
                                            </td>
                                            <td>
                                                <?php echo $product['current_stock']; ?> pcs
                                            </td>
                                            <td>
                                                <div class="progress" style="height: 10px;">
                                                    <div class="progress-bar bg-info" role="progressbar" 
                                                         style="width: <?php echo min($turnover_rate, 100); ?>%">
                                                    </div>
                                                </div>
                                                <small><?php echo round($turnover_rate, 1); ?>%</small>
                                            </td>
                                        </tr>
                                        <?php $rank++; ?>
                                        <?php endwhile; ?>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="5" class="text-center py-3">
                                                <div class="text-muted">
                                                    <i class="fas fa-chart-line"></i> No sales data in last 30 days
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header bg-warning text-dark">
                        <h5 class="mb-0">⚠️ Expiring Soon (Next 90 Days)</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-sm">
                                <thead>
                                    <tr>
                                        <th>Product</th>
                                        <th>Batch</th>
                                        <th>Expiry</th>
                                        <th>Days Left</th>
                                        <th>Stock</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if($expiring_result && mysqli_num_rows($expiring_result) > 0): ?>
                                        <?php while($batch = mysqli_fetch_assoc($expiring_result)): 
                                            $days_class = '';
                                            if ($batch['days_remaining'] <= 30) {
                                                $days_class = 'bg-danger';
                                            } elseif ($batch['days_remaining'] <= 60) {
                                                $days_class = 'bg-warning text-dark';
                                            } else {
                                                $days_class = 'bg-info';
                                            }
                                        ?>
                                        <tr>
                                            <td>
                                                <small><strong><?php echo $batch['product_name']; ?></strong></small><br>
                                                <small class="text-muted"><?php echo $batch['sku']; ?></small>
                                            </td>
                                            <td>
                                                <span class="badge bg-light text-dark batch-badge"><?php echo $batch['batch_number']; ?></span>
                                            </td>
                                            <td>
                                                <?php echo date('d M Y', strtotime($batch['expiry_date'])); ?>
                                            </td>
                                            <td>
                                                <span class="badge <?php echo $days_class; ?>">
                                                    <?php echo $batch['days_remaining']; ?> days
                                                </span>
                                            </td>
                                            <td>
                                                <?php echo $batch['current_quantity']; ?> pcs
                                            </td>
                                        </tr>
                                        <?php endwhile; ?>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="5" class="text-center py-3">
                                                <div class="text-muted">
                                                    <i class="fas fa-calendar-check"></i> No batches expiring in next 90 days
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
    
    <script>
        // Initialize DataTable
        $(document).ready(function() {
            $('#inventoryTable').DataTable({
                "pageLength": 25,
                "order": [[0, 'asc']],
                "language": {
                    "search": "Search products:",
                    "lengthMenu": "Show _MENU_ products per page",
                    "zeroRecords": "No products found",
                    "info": "Showing _START_ to _END_ of _TOTAL_ products",
                    "infoEmpty": "No products available",
                    "infoFiltered": "(filtered from _MAX_ total products)",
                    "paginate": {
                        "first": "First",
                        "last": "Last",
                        "next": "Next",
                        "previous": "Previous"
                    }
                }
            });
        });
        
        // Simple export function
        function exportToExcel() {
            alert('Export feature would generate Excel file with current inventory data.');
            // In production, this would redirect to an export script
            // window.location.href = 'export_inventory.php?format=excel';
        }
    </script>
</body>
</html>