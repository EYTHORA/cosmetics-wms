<?php
// modules/reports/sales_export.php
$root_path = dirname(dirname(dirname(__FILE__))) . '/';
require_once $root_path . 'includes/config.php';
require_once $root_path . 'includes/auth.php';
checkLogin();

$start_date = $_GET['start_date'] ?? date('Y-m-d', strtotime('-30 days'));
$end_date = $_GET['end_date'] ?? date('Y-m-d');
$format = $_GET['format'] ?? 'excel';

// HEADER untuk file Excel
if ($format === 'excel' || $format === 'csv') {
    header("Content-Type: application/vnd.ms-excel");
    header("Content-Disposition: attachment; filename=sales_report_" . date('Ymd_His') . ".xls");
    header("Pragma: no-cache");
    header("Expires: 0");
} else {
    // For PDF, you would use a PDF library like TCPDF or Dompdf
    header("Location: sales_report.php?start_date=$start_date&end_date=$end_date&print=1");
    exit;
}

// Query untuk export
$sql = "SELECT 
          o.order_number,
          DATE_FORMAT(o.order_date, '%d/%m/%Y') as order_date,
          c.name as customer_name,
          o.status,
          o.grand_total,
          o.payment_status,
          COUNT(oi.id) as item_count
        FROM orders o
        LEFT JOIN customers c ON o.customer_id = c.id
        LEFT JOIN order_items oi ON o.id = oi.order_id
        WHERE o.order_date BETWEEN '$start_date' AND '$end_date 23:59:59'
        GROUP BY o.id
        ORDER BY o.order_date DESC";

$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Sales Export</title>
</head>
<body>
    <table border="1">
        <tr>
            <th colspan="6" style="background-color: #28a745; color: white; padding: 10px;">
                SALES REPORT - <?php echo date('d M Y', strtotime($start_date)); ?> to <?php echo date('d M Y', strtotime($end_date)); ?>
            </th>
        </tr>
        <tr style="background-color: #343a40; color: white;">
            <th>Order #</th>
            <th>Date</th>
            <th>Customer</th>
            <th>Status</th>
            <th>Amount</th>
            <th>Payment</th>
            <th>Items</th>
        </tr>
        <?php while($row = mysqli_fetch_assoc($result)): ?>
        <tr>
            <td><?php echo $row['order_number']; ?></td>
            <td><?php echo $row['order_date']; ?></td>
            <td><?php echo $row['customer_name']; ?></td>
            <td><?php echo $row['status']; ?></td>
            <td style="text-align: right;"><?php echo number_format($row['grand_total'], 0, ',', '.'); ?></td>
            <td><?php echo $row['payment_status']; ?></td>
            <td style="text-align: center;"><?php echo $row['item_count']; ?></td>
        </tr>
        <?php endwhile; ?>
    </table>
</body>
</html>