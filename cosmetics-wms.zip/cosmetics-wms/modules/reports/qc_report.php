<?php
// modules/reports/qc_report.php
$root_path = dirname(dirname(dirname(__FILE__))) . '/';
require_once $root_path . 'includes/config.php';
require_once $root_path . 'includes/auth.php';
checkLogin();

$active_menu = 'reports';
$page_title = "QC Report";

// FILTERS
$start_date = isset($_GET['start_date']) ? $_GET['start_date'] : date('Y-m-d', strtotime('-30 days'));
$end_date = isset($_GET['end_date']) ? $_GET['end_date'] : date('Y-m-d');
$check_type = isset($_GET['check_type']) ? $_GET['check_type'] : '';
$qc_status = isset($_GET['qc_status']) ? $_GET['qc_status'] : '';
$product_id = isset($_GET['product_id']) ? (int)$_GET['product_id'] : '';
$checked_by = isset($_GET['checked_by']) ? (int)$_GET['checked_by'] : '';
$search = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : '';

// VALIDATE DATES
if (!empty($start_date) && !empty($end_date) && $start_date > $end_date) {
    $temp = $start_date;
    $start_date = $end_date;
    $end_date = $temp;
}

// BUILD WHERE CLAUSE
$where = "qc.check_date BETWEEN '$start_date' AND '$end_date 23:59:59'";

if (!empty($check_type)) {
    $where .= " AND qc.check_type = '$check_type'";
}

if ($qc_status === 'passed') {
    $where .= " AND qc.passed = 1";
} elseif ($qc_status === 'failed') {
    $where .= " AND qc.passed = 0";
}

if (!empty($product_id)) {
    $where .= " AND p.id = $product_id";
}

if (!empty($checked_by)) {
    $where .= " AND qc.checked_by = $checked_by";
}

if (!empty($search)) {
    $where .= " AND (p.name LIKE '%$search%' OR p.sku LIKE '%$search%' OR pb.batch_number LIKE '%$search%')";
}

// GET PRODUCTS FOR FILTER
$products_sql = "SELECT id, name, sku FROM products WHERE status = 'active' ORDER BY name";
$products_result = mysqli_query($conn, $products_sql);

// GET USERS FOR FILTER
$users_sql = "SELECT id, full_name FROM users WHERE role = 'qc_staff' OR role = 'admin' ORDER BY full_name";
$users_result = mysqli_query($conn, $users_sql);

// GET QC DATA
$qc_sql = "SELECT 
              qc.id,
              qc.check_type,
              qc.check_date,
              qc.temperature_check,
              qc.humidity_check,
              qc.packaging_condition,
              qc.product_condition,
              qc.passed,
              qc.notes,
              
              u.full_name as checked_by_name,
              u.role as checker_role,
              
              pb.batch_number,
              pb.expiry_date,
              pb.current_quantity,
              pb.status as batch_status,
              
              p.id as product_id,
              p.sku,
              p.name as product_name,
              p.weight_volume,
              p.halal_certified,
              p.bpom_required,
              
              b.name as brand_name,
              c.name as category_name,
              
              -- Calculate days to expiry at check date
              DATEDIFF(pb.expiry_date, qc.check_date) as days_to_expiry_at_check
              
           FROM qc_checks qc
           JOIN product_batches pb ON qc.batch_id = pb.id
           JOIN products p ON pb.product_id = p.id
           LEFT JOIN users u ON qc.checked_by = u.id
           LEFT JOIN brands b ON p.brand_id = b.id
           LEFT JOIN categories c ON p.category_id = c.id
           WHERE $where
           ORDER BY qc.check_date DESC, qc.id DESC";

$qc_result = mysqli_query($conn, $qc_sql);

// GET QC SUMMARY STATS
$summary_sql = "SELECT 
                  -- Total checks
                  COUNT(*) as total_checks,
                  
                  -- Passed/Failed counts
                  COUNT(CASE WHEN qc.passed = 1 THEN 1 END) as passed_count,
                  COUNT(CASE WHEN qc.passed = 0 THEN 1 END) as failed_count,
                  COUNT(CASE WHEN qc.passed IS NULL THEN 1 END) as pending_count,
                  
                  -- Pass rate
                  ROUND(COUNT(CASE WHEN qc.passed = 1 THEN 1 END) * 100.0 / COUNT(*), 2) as pass_rate,
                  
                  -- By check type
                  COUNT(CASE WHEN qc.check_type = 'incoming' THEN 1 END) as incoming_count,
                  COUNT(CASE WHEN qc.check_type = 'periodic' THEN 1 END) as periodic_count,
                  COUNT(CASE WHEN qc.check_type = 'outgoing' THEN 1 END) as outgoing_count,
                  
                  -- By product condition
                  COUNT(CASE WHEN qc.product_condition = 'good' THEN 1 END) as condition_good,
                  COUNT(CASE WHEN qc.product_condition = 'expired' THEN 1 END) as condition_expired,
                  COUNT(CASE WHEN qc.product_condition = 'damaged' THEN 1 END) as condition_damaged,
                  COUNT(CASE WHEN qc.product_condition = 'contaminated' THEN 1 END) as condition_contaminated,
                  
                  -- By packaging condition
                  COUNT(CASE WHEN qc.packaging_condition = 'good' THEN 1 END) as packaging_good,
                  COUNT(CASE WHEN qc.packaging_condition = 'damaged' THEN 1 END) as packaging_damaged,
                  COUNT(CASE WHEN qc.packaging_condition = 'sealed' THEN 1 END) as packaging_sealed,
                  
                  -- Temperature stats
                  ROUND(AVG(qc.temperature_check), 2) as avg_temperature,
                  MIN(qc.temperature_check) as min_temperature,
                  MAX(qc.temperature_check) as max_temperature,
                  
                  -- Humidity stats
                  ROUND(AVG(qc.humidity_check), 2) as avg_humidity,
                  MIN(qc.humidity_check) as min_humidity,
                  MAX(qc.humidity_check) as max_humidity
                  
                FROM qc_checks qc
                WHERE qc.check_date BETWEEN '$start_date' AND '$end_date 23:59:59'";

$summary_result = mysqli_query($conn, $summary_sql);
$summary = $summary_result ? mysqli_fetch_assoc($summary_result) : [
    'total_checks' => 0,
    'passed_count' => 0,
    'failed_count' => 0,
    'pass_rate' => 0,
    'incoming_count' => 0,
    'periodic_count' => 0,
    'outgoing_count' => 0,
    'condition_good' => 0,
    'condition_expired' => 0,
    'condition_damaged' => 0,
    'condition_contaminated' => 0,
    'packaging_good' => 0,
    'packaging_damaged' => 0,
    'packaging_sealed' => 0
];

// GET FAILURE REASONS ANALYSIS
$failure_sql = "SELECT 
                  qc.product_condition,
                  qc.packaging_condition,
                  COUNT(*) as failure_count,
                  GROUP_CONCAT(DISTINCT p.name SEPARATOR ', ') as products_affected
                FROM qc_checks qc
                JOIN product_batches pb ON qc.batch_id = pb.id
                JOIN products p ON pb.product_id = p.id
                WHERE qc.passed = 0
                  AND qc.check_date BETWEEN '$start_date' AND '$end_date 23:59:59'
                GROUP BY qc.product_condition, qc.packaging_condition
                ORDER BY failure_count DESC";

$failure_result = mysqli_query($conn, $failure_sql);

// GET TOP QC STAFF PERFORMANCE
$staff_sql = "SELECT 
                u.full_name,
                u.role,
                COUNT(qc.id) as total_checks,
                COUNT(CASE WHEN qc.passed = 1 THEN 1 END) as passed_checks,
                ROUND(COUNT(CASE WHEN qc.passed = 1 THEN 1 END) * 100.0 / COUNT(qc.id), 2) as pass_rate,
                AVG(qc.temperature_check) as avg_temperature,
                AVG(qc.humidity_check) as avg_humidity
              FROM qc_checks qc
              JOIN users u ON qc.checked_by = u.id
              WHERE qc.check_date BETWEEN '$start_date' AND '$end_date 23:59:59'
              GROUP BY u.id
              ORDER BY total_checks DESC";

$staff_result = mysqli_query($conn, $staff_sql);

// GET PRODUCTS WITH MOST FAILURES
$problem_products_sql = "SELECT 
                           p.name as product_name,
                           p.sku,
                           b.name as brand_name,
                           COUNT(CASE WHEN qc.passed = 0 THEN 1 END) as failure_count,
                           COUNT(qc.id) as total_checks,
                           ROUND(COUNT(CASE WHEN qc.passed = 0 THEN 1 END) * 100.0 / COUNT(qc.id), 2) as failure_rate,
                           GROUP_CONCAT(DISTINCT qc.product_condition SEPARATOR ', ') as issues
                         FROM qc_checks qc
                         JOIN product_batches pb ON qc.batch_id = pb.id
                         JOIN products p ON pb.product_id = p.id
                         LEFT JOIN brands b ON p.brand_id = b.id
                         WHERE qc.check_date BETWEEN '$start_date' AND '$end_date 23:59:59'
                         GROUP BY p.id
                         HAVING failure_count > 0
                         ORDER BY failure_count DESC
                         LIMIT 10";

$problem_products_result = mysqli_query($conn, $problem_products_sql);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cosmetics WMS - QC Report</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css">
    
    <style>
        .summary-card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.08);
            transition: all 0.3s;
            margin-bottom: 20px;
        }
        
        .summary-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        .qc-passed {
            background-color: #d4edda;
            border-left: 4px solid #28a745;
        }
        
        .qc-failed {
            background-color: #f8d7da;
            border-left: 4px solid #dc3545;
        }
        
        .qc-pending {
            background-color: #fff3cd;
            border-left: 4px solid #ffc107;
        }
        
        .status-badge {
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
        }
        
        .check-type-badge {
            font-size: 11px;
            padding: 3px 8px;
            border-radius: 4px;
        }
        
        .condition-badge {
            font-size: 11px;
            padding: 3px 8px;
            border-radius: 4px;
            margin: 2px;
        }
        
        .temp-badge {
            background: linear-gradient(45deg, #17a2b8, #138496);
            color: white;
        }
        
        .humidity-badge {
            background: linear-gradient(45deg, #6f42c1, #5a2d9c);
            color: white;
        }
        
        .batch-badge {
            background-color: #e9ecef;
            color: #495057;
            font-family: monospace;
            font-size: 11px;
            padding: 3px 6px;
            border-radius: 3px;
        }
        
        .progress-bar-pass {
            background-color: #28a745;
        }
        
        .progress-bar-fail {
            background-color: #dc3545;
        }
        
        .chart-container {
            position: relative;
            height: 250px;
            width: 100%;
        }
    </style>
</head>
<body>
    <?php include $root_path . 'includes/sidebar.php'; ?>
    
    <div class="main-content" style="margin-left: 250px; padding: 25px;">
        <!-- HEADER -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h3 class="mb-1">🔬 Quality Control Report</h3>
                <p class="text-muted mb-0">QC checks and quality assurance analytics</p>
            </div>
            <div class="d-flex">
                <button onclick="window.print()" class="btn btn-secondary me-2">
                    <i class="fas fa-print"></i> Print
                </button>
                <button class="btn btn-info" onclick="exportQCReport()">
                    <i class="fas fa-file-excel"></i> Export Excel
                </button>
            </div>
        </div>
        
        <!-- FILTERS -->
        <div class="card mb-4">
            <div class="card-header bg-info text-white">
                <h5 class="mb-0">🔍 Filter QC Checks</h5>
            </div>
            <div class="card-body">
                <form method="GET" action="" class="row g-3">
                    <div class="col-md-2">
                        <label class="form-label">Start Date</label>
                        <input type="date" name="start_date" class="form-control" 
                               value="<?php echo $start_date; ?>" required>
                    </div>
                    <div class="col-md-2">
                        <label class="form-label">End Date</label>
                        <input type="date" name="end_date" class="form-control" 
                               value="<?php echo $end_date; ?>" required>
                    </div>
                    <div class="col-md-2">
                        <label class="form-label">Check Type</label>
                        <select name="check_type" class="form-select">
                            <option value="">All Types</option>
                            <option value="incoming" <?php echo ($check_type == 'incoming') ? 'selected' : ''; ?>>Incoming</option>
                            <option value="periodic" <?php echo ($check_type == 'periodic') ? 'selected' : ''; ?>>Periodic</option>
                            <option value="outgoing" <?php echo ($check_type == 'outgoing') ? 'selected' : ''; ?>>Outgoing</option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <label class="form-label">QC Status</label>
                        <select name="qc_status" class="form-select">
                            <option value="">All Status</option>
                            <option value="passed" <?php echo ($qc_status == 'passed') ? 'selected' : ''; ?>>Passed</option>
                            <option value="failed" <?php echo ($qc_status == 'failed') ? 'selected' : ''; ?>>Failed</option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <label class="form-label">Product</label>
                        <select name="product_id" class="form-select">
                            <option value="">All Products</option>
                            <?php 
                            if ($products_result && mysqli_num_rows($products_result) > 0):
                                mysqli_data_seek($products_result, 0);
                                while($product = mysqli_fetch_assoc($products_result)): 
                            ?>
                                <option value="<?php echo $product['id']; ?>" 
                                    <?php echo ($product_id == $product['id']) ? 'selected' : ''; ?>>
                                    <?php echo $product['name']; ?> (<?php echo $product['sku']; ?>)
                                </option>
                            <?php 
                                endwhile;
                            endif; 
                            ?>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <label class="form-label">Checked By</label>
                        <select name="checked_by" class="form-select">
                            <option value="">All Staff</option>
                            <?php 
                            if ($users_result && mysqli_num_rows($users_result) > 0):
                                mysqli_data_seek($users_result, 0);
                                while($user = mysqli_fetch_assoc($users_result)): 
                            ?>
                                <option value="<?php echo $user['id']; ?>" 
                                    <?php echo ($checked_by == $user['id']) ? 'selected' : ''; ?>>
                                    <?php echo $user['full_name']; ?>
                                </option>
                            <?php 
                                endwhile;
                            endif; 
                            ?>
                        </select>
                    </div>
                    <div class="col-md-8">
                        <label class="form-label">Search</label>
                        <input type="text" name="search" class="form-control" 
                               placeholder="Product name, SKU or Batch number..." 
                               value="<?php echo htmlspecialchars($search); ?>">
                    </div>
                    <div class="col-md-4 d-flex align-items-end">
                        <button type="submit" class="btn btn-info w-100">
                            <i class="fas fa-filter"></i> Apply Filter
                        </button>
                        <a href="qc_report.php" class="btn btn-secondary ms-2">
                            <i class="fas fa-redo"></i>
                        </a>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- QC SUMMARY STATS -->
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="card summary-card border-left-info">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-1">Total Checks</h6>
                                <h3 class="text-info mb-0"><?php echo number_format($summary['total_checks'] ?? 0, 0, ',', '.'); ?></h3>
                                <small class="text-muted">QC inspections</small>
                            </div>
                            <div class="text-info">
                                <i class="fas fa-clipboard-check fa-2x"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3">
                <div class="card summary-card border-left-success">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-1">Pass Rate</h6>
                                <h3 class="text-success mb-0"><?php echo number_format($summary['pass_rate'] ?? 0, 1, ',', '.'); ?>%</h3>
                                <small class="text-muted">Quality compliance</small>
                            </div>
                            <div class="text-success">
                                <i class="fas fa-check-circle fa-2x"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3">
                <div class="card summary-card border-left-warning">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-1">Avg Temperature</h6>
                                <h3 class="text-warning mb-0"><?php echo number_format($summary['avg_temperature'] ?? 0, 1, ',', '.'); ?>°C</h3>
                                <small class="text-muted">Storage condition</small>
                            </div>
                            <div class="text-warning">
                                <i class="fas fa-thermometer-half fa-2x"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3">
                <div class="card summary-card border-left-primary">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-1">Avg Humidity</h6>
                                <h3 class="text-primary mb-0"><?php echo number_format($summary['avg_humidity'] ?? 0, 1, ',', '.'); ?>%</h3>
                                <small class="text-muted">Humidity level</small>
                            </div>
                            <div class="text-primary">
                                <i class="fas fa-tint fa-2x"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
       
        <!-- QC STATUS OVERVIEW -->
<div class="row mb-4">
    <div class="col-md-4">
        <div class="card">
            <div class="card-header bg-success text-white">
                <h5 class="mb-0">✅ Pass/Fail Overview</h5>
            </div>
            <div class="card-body">
                <?php
                // FIX: Handle division by zero
                $total_checks = $summary['total_checks'] ?? 0;
                $passed_count = $summary['passed_count'] ?? 0;
                $failed_count = $summary['failed_count'] ?? 0;
                $pending_count = $summary['pending_count'] ?? 0;
                
                // Calculate percentages with error handling
                if ($total_checks > 0) {
                    $passed_percent = $passed_count / $total_checks * 100;
                    $failed_percent = $failed_count / $total_checks * 100;
                    $pass_rate = $passed_count / $total_checks * 100;
                } else {
                    $passed_percent = 0;
                    $failed_percent = 0;
                    $pass_rate = 0;
                }
                ?>
                
                <div class="text-center mb-3">
                    <h2><?php echo number_format($pass_rate, 1); ?>%</h2>
                    <small class="text-muted">Overall Pass Rate</small>
                </div>
                
                <?php if ($total_checks > 0): ?>
                <div class="progress" style="height: 20px;">
                    <div class="progress-bar progress-bar-pass" style="width: <?php echo $passed_percent; ?>%">
                        <?php echo $passed_count; ?> Passed
                    </div>
                    <div class="progress-bar progress-bar-fail" style="width: <?php echo $failed_percent; ?>%">
                        <?php echo $failed_count; ?> Failed
                    </div>
                </div>
                <?php else: ?>
                <div class="progress" style="height: 20px;">
                    <div class="progress-bar bg-light text-dark" style="width: 100%;">
                        No QC checks found
                    </div>
                </div>
                <?php endif; ?>
                
                <div class="row mt-3 text-center">
                    <div class="col-md-6">
                        <span class="badge bg-success p-2 w-100">
                            <i class="fas fa-check"></i> Passed: <?php echo $passed_count; ?>
                        </span>
                    </div>
                    <div class="col-md-6">
                        <span class="badge bg-danger p-2 w-100">
                            <i class="fas fa-times"></i> Failed: <?php echo $failed_count; ?>
                        </span>
                    </div>
                </div>
                
                <?php if ($pending_count > 0): ?>
                <div class="row mt-2 text-center">
                    <div class="col-md-12">
                        <span class="badge bg-warning text-dark p-2 w-100">
                            <i class="fas fa-clock"></i> Pending: <?php echo $pending_count; ?>
                        </span>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <div class="col-md-4">
        <div class="card">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0">📋 Check Type Distribution</h5>
            </div>
            <div class="card-body">
                <div class="row text-center">
                    <div class="col-md-4 mb-2">
                        <div class="bg-info text-white p-2 rounded">
                            <h6 class="mb-0"><?php echo $summary['incoming_count'] ?? 0; ?></h6>
                            <small>Incoming</small>
                        </div>
                    </div>
                    <div class="col-md-4 mb-2">
                        <div class="bg-warning text-dark p-2 rounded">
                            <h6 class="mb-0"><?php echo $summary['periodic_count'] ?? 0; ?></h6>
                            <small>Periodic</small>
                        </div>
                    </div>
                    <div class="col-md-4 mb-2">
                        <div class="bg-success text-white p-2 rounded">
                            <h6 class="mb-0"><?php echo $summary['outgoing_count'] ?? 0; ?></h6>
                            <small>Outgoing</small>
                        </div>
                    </div>
                </div>
                
                <div class="mt-3">
                    <?php
                    // FIX: Handle null values for temperature/humidity
                    $min_temp = $summary['min_temperature'] ?? 0;
                    $max_temp = $summary['max_temperature'] ?? 0;
                    $min_humidity = $summary['min_humidity'] ?? 0;
                    $max_humidity = $summary['max_humidity'] ?? 0;
                    ?>
                    <h6>Temperature Range:</h6>
                    <div class="d-flex justify-content-between">
                        <small class="text-muted">Min: <?php echo number_format($min_temp, 1); ?>°C</small>
                        <small class="text-muted">Max: <?php echo number_format($max_temp, 1); ?>°C</small>
                    </div>
                    
                    <h6 class="mt-2">Humidity Range:</h6>
                    <div class="d-flex justify-content-between">
                        <small class="text-muted">Min: <?php echo number_format($min_humidity, 1); ?>%</small>
                        <small class="text-muted">Max: <?php echo number_format($max_humidity, 1); ?>%</small>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-md-4">
        <div class="card">
            <div class="card-header bg-warning text-dark">
                <h5 class="mb-0">⚠️ Product Condition Issues</h5>
            </div>
            <div class="card-body">
                <div class="mb-2">
                    <small class="text-muted">Good Condition:</small>
                    <span class="badge bg-success float-end"><?php echo $summary['condition_good'] ?? 0; ?></span>
                </div>
                <div class="mb-2">
                    <small class="text-muted">Expired:</small>
                    <span class="badge bg-danger float-end"><?php echo $summary['condition_expired'] ?? 0; ?></span>
                </div>
                <div class="mb-2">
                    <small class="text-muted">Damaged:</small>
                    <span class="badge bg-warning float-end"><?php echo $summary['condition_damaged'] ?? 0; ?></span>
                </div>
                <div class="mb-2">
                    <small class="text-muted">Contaminated:</small>
                    <span class="badge bg-dark float-end"><?php echo $summary['condition_contaminated'] ?? 0; ?></span>
                </div>
                
                <hr>
                
                <div class="mt-2">
                    <small class="text-muted">Packaging Good:</small>
                    <span class="badge bg-success float-end"><?php echo $summary['packaging_good'] ?? 0; ?></span>
                </div>
                <div class="mt-2">
                    <small class="text-muted">Packaging Damaged:</small>
                    <span class="badge bg-warning float-end"><?php echo $summary['packaging_damaged'] ?? 0; ?></span>
                </div>
                <div class="mt-2">
                    <small class="text-muted">Properly Sealed:</small>
                    <span class="badge bg-info float-end"><?php echo $summary['packaging_sealed'] ?? 0; ?></span>
                </div>
            </div>
        </div>
    </div>
</div>
        
        <!-- QC CHECKS TABLE -->
        <div class="card mb-4">
            <div class="card-header bg-info text-white d-flex justify-content-between align-items-center">
                <h5 class="mb-0">📋 QC Check Details</h5>
                <span class="badge bg-light text-dark">
                    <?php echo $qc_result ? mysqli_num_rows($qc_result) : 0; ?> checks found
                </span>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover" id="qcTable">
                        <thead>
                            <tr>
                                <th>Status</th>
                                <th>Product & Batch</th>
                                <th>Check Info</th>
                                <th>Condition</th>
                                <th>Parameters</th>
                                <th>Staff</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($qc_result && mysqli_num_rows($qc_result) > 0): ?>
                                <?php while($check = mysqli_fetch_assoc($qc_result)): 
                                    // Determine row class based on pass status
                                    $row_class = $check['passed'] == 1 ? 'qc-passed' : 
                                                ($check['passed'] == 0 ? 'qc-failed' : 'qc-pending');
                                    
                                    // Status badge
                                    $status_class = '';
                                    $status_text = '';
                                    if ($check['passed'] == 1) {
                                        $status_class = 'bg-success';
                                        $status_text = 'PASSED';
                                    } elseif ($check['passed'] == 0) {
                                        $status_class = 'bg-danger';
                                        $status_text = 'FAILED';
                                    } else {
                                        $status_class = 'bg-warning text-dark';
                                        $status_text = 'PENDING';
                                    }
                                    
                                    // Check type badge
                                    $check_type_class = '';
                                    switch($check['check_type']) {
                                        case 'incoming':
                                            $check_type_class = 'bg-info';
                                            break;
                                        case 'periodic':
                                            $check_type_class = 'bg-warning text-dark';
                                            break;
                                        case 'outgoing':
                                            $check_type_class = 'bg-success';
                                            break;
                                    }
                                    
                                    // Product condition badge
                                    $condition_class = '';
                                    switch($check['product_condition']) {
                                        case 'good':
                                            $condition_class = 'bg-success';
                                            break;
                                        case 'expired':
                                            $condition_class = 'bg-danger';
                                            break;
                                        case 'damaged':
                                            $condition_class = 'bg-warning text-dark';
                                            break;
                                        case 'contaminated':
                                            $condition_class = 'bg-dark';
                                            break;
                                    }
                                ?>
                                <tr class="<?php echo $row_class; ?>">
                                    <td>
                                        <span class="badge <?php echo $status_class; ?> status-badge">
                                            <?php echo $status_text; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <strong><?php echo $check['product_name']; ?></strong><br>
                                        <small class="text-muted">SKU: <?php echo $check['sku']; ?></small><br>
                                        <span class="batch-badge"><?php echo $check['batch_number']; ?></span><br>
                                        <small class="text-muted">
                                            Brand: <?php echo $check['brand_name']; ?> | 
                                            Category: <?php echo $check['category_name']; ?>
                                        </small>
                                        <?php if($check['halal_certified']): ?>
                                            <span class="badge bg-success condition-badge">Halal</span>
                                        <?php endif; ?>
                                        <?php if($check['bpom_required']): ?>
                                            <span class="badge bg-info condition-badge">BPOM</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="mb-1">
                                            <span class="badge <?php echo $check_type_class; ?> check-type-badge">
                                                <?php echo ucfirst($check['check_type']); ?>
                                            </span>
                                        </div>
                                        <div>
                                            <small class="text-muted">Date:</small><br>
                                            <strong><?php echo date('d M Y', strtotime($check['check_date'])); ?></strong>
                                        </div>
                                        <div class="mt-1">
                                            <small class="text-muted">Expiry:</small><br>
                                            <small><?php echo date('M Y', strtotime($check['expiry_date'])); ?></small>
                                            <small class="text-<?php echo ($check['days_to_expiry_at_check'] <= 30) ? 'danger' : 'muted'; ?>">
                                                (<?php echo $check['days_to_expiry_at_check']; ?> days)
                                            </small>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="mb-2">
                                            <span class="badge <?php echo $condition_class; ?> condition-badge">
                                                <?php echo ucfirst($check['product_condition']); ?>
                                            </span>
                                        </div>
                                        <div>
                                            <small class="text-muted">Packaging:</small><br>
                                            <span class="badge bg-light text-dark condition-badge">
                                                <?php echo ucfirst($check['packaging_condition']); ?>
                                            </span>
                                        </div>
                                        <div class="mt-2">
                                            <small class="text-muted">Quantity:</small><br>
                                            <strong><?php echo number_format($check['current_quantity'], 0, ',', '.'); ?> pcs</strong>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="mb-2">
                                            <span class="badge temp-badge">
                                                <i class="fas fa-thermometer-half"></i> 
                                                <?php echo number_format($check['temperature_check'], 1); ?>°C
                                            </span>
                                        </div>
                                        <div>
                                            <span class="badge humidity-badge">
                                                <i class="fas fa-tint"></i> 
                                                <?php echo number_format($check['humidity_check'], 1); ?>%
                                            </span>
                                        </div>
                                        <?php if(!empty($check['notes'])): ?>
                                        <div class="mt-2">
                                            <small class="text-muted">Notes:</small><br>
                                            <small><?php echo substr($check['notes'], 0, 50); ?>...</small>
                                        </div>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <strong><?php echo $check['checked_by_name']; ?></strong><br>
                                        <small class="text-muted"><?php echo $check['checker_role']; ?></small>
                                    </td>
                                    <td>
                                        <div class="btn-group" role="group">
                                            <a href="../qc/view.php?id=<?php echo $check['id']; ?>" 
                                               class="btn btn-sm btn-info" title="View">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                            <a href="../qc/edit.php?id=<?php echo $check['id']; ?>" 
                                               class="btn btn-sm btn-warning" title="Edit">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <a href="../qc/print.php?id=<?php echo $check['id']; ?>" 
                                               class="btn btn-sm btn-secondary" title="Print" target="_blank">
                                                <i class="fas fa-print"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="7" class="text-center py-4">
                                        <div class="text-muted">
                                            <i class="fas fa-clipboard-check fa-2x mb-3"></i><br>
                                            No QC checks found with current filters.
                                        </div>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        
        <!-- THREE COLUMNS: FAILURE ANALYSIS, STAFF PERFORMANCE, PROBLEM PRODUCTS -->
        <div class="row">
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header bg-danger text-white">
                        <h5 class="mb-0">📊 Failure Reasons Analysis</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-sm">
                                <thead>
                                    <tr>
                                        <th>Issue</th>
                                        <th>Count</th>
                                        <th>Products</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if($failure_result && mysqli_num_rows($failure_result) > 0): ?>
                                        <?php while($failure = mysqli_fetch_assoc($failure_result)): ?>
                                        <tr>
                                            <td>
                                                <small>
                                                    <strong><?php echo ucfirst($failure['product_condition']); ?></strong><br>
                                                    <span class="text-muted"><?php echo ucfirst($failure['packaging_condition']); ?> packaging</span>
                                                </small>
                                            </td>
                                            <td>
                                                <span class="badge bg-danger"><?php echo $failure['failure_count']; ?></span>
                                            </td>
                                            <td>
                                                <small><?php echo substr($failure['products_affected'], 0, 30); ?>...</small>
                                            </td>
                                        </tr>
                                        <?php endwhile; ?>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="3" class="text-center py-3">
                                                <div class="text-muted">
                                                    <i class="fas fa-check-circle"></i> No failures recorded
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0">👥 QC Staff Performance</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-sm">
                                <thead>
                                    <tr>
                                        <th>Staff</th>
                                        <th>Checks</th>
                                        <th>Pass Rate</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if($staff_result && mysqli_num_rows($staff_result) > 0): ?>
                                        <?php while($staff = mysqli_fetch_assoc($staff_result)): ?>
                                        <tr>
                                            <td>
                                                <small><strong><?php echo $staff['full_name']; ?></strong></small><br>
                                                <small class="text-muted"><?php echo $staff['role']; ?></small>
                                            </td>
                                            <td>
                                                <span class="badge bg-info"><?php echo $staff['total_checks']; ?></span><br>
                                                <small class="text-success">✓ <?php echo $staff['passed_checks']; ?></small>
                                            </td>
                                            <td>
                                                <div class="progress" style="height: 10px;">
                                                    <div class="progress-bar bg-success" role="progressbar" 
                                                         style="width: <?php echo $staff['pass_rate']; ?>%">
                                                    </div>
                                                </div>
                                                <small><?php echo $staff['pass_rate']; ?>%</small>
                                            </td>
                                        </tr>
                                        <?php endwhile; ?>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="3" class="text-center py-3">
                                                <div class="text-muted">
                                                    <i class="fas fa-user"></i> No staff data
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header bg-warning text-dark">
                        <h5 class="mb-0">⚠️ Problem Products (Most Failures)</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-sm">
                                <thead>
                                    <tr>
                                        <th>Product</th>
                                        <th>Failures</th>
                                        <th>Rate</th>
                                        <th>Issues</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if($problem_products_result && mysqli_num_rows($problem_products_result) > 0): ?>
                                        <?php while($product = mysqli_fetch_assoc($problem_products_result)): ?>
                                        <tr>
                                            <td>
                                                <small><strong><?php echo $product['product_name']; ?></strong></small><br>
                                                <small class="text-muted"><?php echo $product['brand_name']; ?></small>
                                            </td>
                                            <td>
                                                <span class="badge bg-danger"><?php echo $product['failure_count']; ?>/<?php echo $product['total_checks']; ?></span>
                                            </td>
                                            <td>
                                                <span class="badge bg-<?php echo ($product['failure_rate'] > 30) ? 'danger' : 'warning'; ?>">
                                                    <?php echo $product['failure_rate']; ?>%
                                                </span>
                                            </td>
                                            <td>
                                                <small><?php echo substr($product['issues'], 0, 20); ?>...</small>
                                            </td>
                                        </tr>
                                        <?php endwhile; ?>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="4" class="text-center py-3">
                                                <div class="text-muted">
                                                    <i class="fas fa-check-circle"></i> No problem products
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
    
    <script>
        // Initialize DataTable
        $(document).ready(function() {
            $('#qcTable').DataTable({
                "pageLength": 25,
                "order": [[0, 'asc']],
                "language": {
                    "search": "Search QC checks...",
                    "lengthMenu": "Show _MENU_ checks per page",
                    "zeroRecords": "No QC checks found",
                    "info": "Showing _START_ to _END_ of _TOTAL_ checks",
                    "infoEmpty": "No QC checks available",
                    "infoFiltered": "(filtered from _MAX_ total checks)",
                    "paginate": {
                        "first": "First",
                        "last": "Last",
                        "next": "Next",
                        "previous": "Previous"
                    }
                }
            });
        });
        
        // Export function
        function exportQCReport() {
            const params = new URLSearchParams(window.location.search);
            
            if (confirm('Export QC report to Excel?')) {
                window.location.href = 'qc_export.php?' + params.toString();
            }
        }
        
        // Auto-refresh every 5 minutes
        setTimeout(function() {
            location.reload();
        }, 300000);
    </script>
</body>
</html>