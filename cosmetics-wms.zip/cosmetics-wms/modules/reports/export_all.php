<?php
// modules/reports/export_all.php
$root_path = dirname(dirname(dirname(__FILE__))) . '/';
require_once $root_path . 'includes/config.php';
require_once $root_path . 'includes/auth.php';
checkLogin();

$start_date = $_GET['start_date'] ?? date('Y-m-d', strtotime('-30 days'));
$end_date = $_GET['end_date'] ?? date('Y-m-d');
$format = $_GET['format'] ?? 'zip';

// Cek jika format = zip, maka generate ZIP
if ($format === 'zip') {
    $zip = new ZipArchive();
    $zip_name = "reports_export_" . date('Ymd_His') . ".zip";
    
    if ($zip->open($zip_name, ZipArchive::CREATE) === TRUE) {
        // Generate dan tambahkan laporan ke ZIP
        // Contoh data dummy untuk demo
        $sales_data = "Date,Product,Quantity,Revenue\n";
        $sales_data .= date('Y-m-d') . ",Lipstick,50,1500000\n";
        $sales_data .= date('Y-m-d') . ",Foundation,30,2100000\n";
        
        $inv_data = "Product,Stock,Min Stock,Status\n";
        $inv_data .= "Lipstick,150,50,OK\n";
        $inv_data .= "Foundation,80,30,OK\n";
        $inv_data .= "Mascara,5,20,LOW\n";
        
        $zip->addFromString("sales_report.csv", $sales_data);
        $zip->addFromString("inventory_report.csv", $inv_data);
        $zip->addFromString("readme.txt", "Reports generated on: " . date('Y-m-d H:i:s'));
        
        $zip->close();
        
        // Force download
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="' . $zip_name . '"');
        header('Content-Length: ' . filesize($zip_name));
        readfile($zip_name);
        unlink($zip_name); // Hapus file temp
        exit;
    } else {
        // Jika gagal buat ZIP, tampilkan error
        $error = "Failed to create ZIP file";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Export All Reports</title>
    <link href='https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body class='bg-light'>
    <div class='container mt-5'>
        <div class='card'>
            <div class='card-header bg-primary text-white'>
                <h4><i class='fas fa-file-archive'></i> Export All Reports</h4>
            </div>
            <div class='card-body text-center'>
                <?php if (isset($error)): ?>
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-triangle"></i> 
                        <?php echo htmlspecialchars($error); ?>
                    </div>
                <?php endif; ?>
                
                <div class='mb-4'>
                    <i class='fas fa-cogs fa-4x text-primary mb-3'></i>
                    <h5>Export Feature in Development</h5>
                    <p class='text-muted'>
                        This feature would generate a ZIP file containing all reports:<br>
                        • Sales Report (<?php echo htmlspecialchars($start_date); ?> to <?php echo htmlspecialchars($end_date); ?>)<br>
                        • Inventory Report (Current stock)<br>
                        • Orders Report (<?php echo htmlspecialchars($start_date); ?> to <?php echo htmlspecialchars($end_date); ?>)<br>
                        • QC Report (<?php echo htmlspecialchars($start_date); ?> to <?php echo htmlspecialchars($end_date); ?>)<br>
                        • Expiry Report (Next 90 days)
                    </p>
                </div>
                
                <div class="alert alert-info">
                    <i class="fas fa-info-circle"></i> 
                    <strong>Test ZIP Export:</strong><br>
                    <form method="get" action="" class="mt-2">
                        <input type="hidden" name="format" value="zip">
                        <button type="submit" class="btn btn-success">
                            <i class="fas fa-download"></i> Download Test ZIP
                        </button>
                        <a href='?format=html' class='btn btn-secondary'>
                            <i class="fas fa-eye"></i> View HTML Version
                        </a>
                    </form>
                </div>
                
                <div class="alert alert-warning">
                    <i class="fas fa-exclamation-triangle"></i> 
                    Note: Current ZIP contains sample data. Connect to database to get real reports.
                </div>
                
                <a href='export.php' class='btn btn-primary'>
                    <i class='fas fa-arrow-left'></i> Back to Export Dashboard
                </a>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>