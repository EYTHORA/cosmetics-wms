<?php
// modules/reports/qc_export.php
$root_path = dirname(dirname(dirname(__FILE__))) . '/';
require_once $root_path . 'includes/config.php';
require_once $root_path . 'includes/auth.php';
checkLogin();

// HEADER untuk file Excel
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=qc_report_" . date('Ymd_His') . ".xls");
header("Pragma: no-cache");
header("Expires: 0");

// Ambil parameter filter
$start_date = isset($_GET['start_date']) ? $_GET['start_date'] : date('Y-m-d', strtotime('-30 days'));
$end_date = isset($_GET['end_date']) ? $_GET['end_date'] : date('Y-m-d');
$check_type = isset($_GET['check_type']) ? $_GET['check_type'] : '';
$qc_status = isset($_GET['qc_status']) ? $_GET['qc_status'] : '';

// BUILD WHERE CLAUSE
$where = "qc.check_date BETWEEN '$start_date' AND '$end_date 23:59:59'";
if (!empty($check_type)) $where .= " AND qc.check_type = '$check_type'";
if ($qc_status === 'passed') $where .= " AND qc.passed = 1";
if ($qc_status === 'failed') $where .= " AND qc.passed = 0";

// Query untuk export
$export_sql = "SELECT 
                 qc.check_type,
                 DATE_FORMAT(qc.check_date, '%d/%m/%Y') as check_date,
                 p.name as product_name,
                 p.sku,
                 pb.batch_number,
                 pb.expiry_date,
                 CASE 
                   WHEN qc.passed = 1 THEN 'PASSED'
                   WHEN qc.passed = 0 THEN 'FAILED'
                   ELSE 'PENDING'
                 END as qc_status,
                 qc.product_condition,
                 qc.packaging_condition,
                 qc.temperature_check,
                 qc.humidity_check,
                 u.full_name as checked_by,
                 qc.notes
               FROM qc_checks qc
               JOIN product_batches pb ON qc.batch_id = pb.id
               JOIN products p ON pb.product_id = p.id
               LEFT JOIN users u ON qc.checked_by = u.id
               WHERE $where
               ORDER BY qc.check_date DESC";

$export_result = mysqli_query($conn, $export_sql);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>QC Report Export</title>
</head>
<body>
    <table border="1">
        <tr>
            <th colspan="13" style="background-color: #17a2b8; color: white; font-size: 16px; padding: 10px;">
                COSMETICS WMS - QUALITY CONTROL REPORT
            </th>
        </tr>
        <tr>
            <th colspan="13" style="background-color: #f8f9fa; padding: 8px;">
                Period: <?php echo date('d M Y', strtotime($start_date)); ?> to <?php echo date('d M Y', strtotime($end_date)); ?>
                | Generated: <?php echo date('d M Y H:i:s'); ?>
            </th>
        </tr>
        <tr style="background-color: #343a40; color: white;">
            <th>No</th>
            <th>Check Type</th>
            <th>Check Date</th>
            <th>Product</th>
            <th>SKU</th>
            <th>Batch Number</th>
            <th>Expiry Date</th>
            <th>QC Status</th>
            <th>Product Condition</th>
            <th>Packaging</th>
            <th>Temperature</th>
            <th>Humidity</th>
            <th>Checked By</th>
            <th>Notes</th>
        </tr>
        
        <?php
        $counter = 1;
        $passed_count = 0;
        $failed_count = 0;
        
        while($row = mysqli_fetch_assoc($export_result)):
            if ($row['qc_status'] == 'PASSED') $passed_count++;
            if ($row['qc_status'] == 'FAILED') $failed_count++;
        ?>
        <tr>
            <td><?php echo $counter++; ?></td>
            <td><?php echo $row['check_type']; ?></td>
            <td><?php echo $row['check_date']; ?></td>
            <td><?php echo $row['product_name']; ?></td>
            <td><?php echo $row['sku']; ?></td>
            <td><?php echo $row['batch_number']; ?></td>
            <td><?php echo date('d M Y', strtotime($row['expiry_date'])); ?></td>
            <td><?php echo $row['qc_status']; ?></td>
            <td><?php echo $row['product_condition']; ?></td>
            <td><?php echo $row['packaging_condition']; ?></td>
            <td><?php echo $row['temperature_check']; ?>°C</td>
            <td><?php echo $row['humidity_check']; ?>%</td>
            <td><?php echo $row['checked_by']; ?></td>
            <td><?php echo substr($row['notes'] ?? '', 0, 50); ?></td>
        </tr>
        <?php endwhile; ?>
        
        <!-- SUMMARY ROW -->
        <tr style="background-color: #f8f9fa; font-weight: bold;">
            <td colspan="7" style="text-align: right;">SUMMARY:</td>
            <td colspan="7">
                Total: <?php echo ($counter - 1); ?> checks | 
                Passed: <?php echo $passed_count; ?> | 
                Failed: <?php echo $failed_count; ?> | 
                Pass Rate: <?php echo ($counter - 1) > 0 ? round($passed_count / ($counter - 1) * 100, 2) : 0; ?>%
            </td>
        </tr>
    </table>
</body>
</html>