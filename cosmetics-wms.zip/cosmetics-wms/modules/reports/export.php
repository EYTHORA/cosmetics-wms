<?php
// modules/reports/export.php
$root_path = dirname(dirname(dirname(__FILE__))) . '/';
require_once $root_path . 'includes/config.php';
require_once $root_path . 'includes/auth.php';
checkLogin();

$active_menu = 'reports';
$page_title = "Export Reports";

// Default date range
$start_date = date('Y-m-d', strtotime('-30 days'));
$end_date = date('Y-m-d');

// GET REPORT COUNTS FOR SUMMARY
$reports_summary = [
    'sales' => [
        'title' => 'Sales Report',
        'icon' => 'fas fa-chart-line',
        'color' => 'success',
        'count' => 0,
        'description' => 'Revenue, orders, and sales analytics'
    ],
    'inventory' => [
        'title' => 'Inventory Report',
        'icon' => 'fas fa-boxes',
        'color' => 'primary',
        'count' => 0,
        'description' => 'Stock levels and inventory valuation'
    ],
    'orders' => [
        'title' => 'Orders Report',
        'icon' => 'fas fa-shopping-cart',
        'color' => 'info',
        'count' => 0,
        'description' => 'Order processing and status tracking'
    ],
    'qc' => [
        'title' => 'QC Report',
        'icon' => 'fas fa-clipboard-check',
        'color' => 'warning',
        'count' => 0,
        'description' => 'Quality control and inspection reports'
    ],
    'expiry' => [
        'title' => 'Expiry Report',
        'icon' => 'fas fa-calendar-times',
        'color' => 'danger',
        'count' => 0,
        'description' => 'Product expiration monitoring'
    ]
];

// Get counts for each report
$count_sql = "SELECT 
                (SELECT COUNT(*) FROM orders WHERE order_date BETWEEN '$start_date' AND '$end_date') as orders_count,
                (SELECT COUNT(*) FROM products WHERE status = 'active') as products_count,
                (SELECT COUNT(*) FROM qc_checks WHERE check_date BETWEEN '$start_date' AND '$end_date') as qc_count,
                (SELECT COUNT(*) FROM product_batches WHERE expiry_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 90 DAY)) as expiring_count";

$count_result = mysqli_query($conn, $count_sql);
if ($count_result && $row = mysqli_fetch_assoc($count_result)) {
    $reports_summary['sales']['count'] = $row['orders_count'] ?? 0;
    $reports_summary['inventory']['count'] = $row['products_count'] ?? 0;
    $reports_summary['orders']['count'] = $row['orders_count'] ?? 0;
    $reports_summary['qc']['count'] = $row['qc_count'] ?? 0;
    $reports_summary['expiry']['count'] = $row['expiring_count'] ?? 0;
}

// Handle export requests
if (isset($_POST['export_type'])) {
    $export_type = $_POST['export_type'];
    $format = $_POST['format'] ?? 'excel';
    $date_range = $_POST['date_range'] ?? 'custom';
    $custom_start = $_POST['custom_start'] ?? $start_date;
    $custom_end = $_POST['custom_end'] ?? $end_date;
    
    // Set dates based on selection
    switch($date_range) {
        case 'today':
            $export_start = date('Y-m-d');
            $export_end = date('Y-m-d');
            break;
        case 'yesterday':
            $export_start = date('Y-m-d', strtotime('-1 day'));
            $export_end = date('Y-m-d', strtotime('-1 day'));
            break;
        case 'this_week':
            $export_start = date('Y-m-d', strtotime('monday this week'));
            $export_end = date('Y-m-d');
            break;
        case 'last_week':
            $export_start = date('Y-m-d', strtotime('monday last week'));
            $export_end = date('Y-m-d', strtotime('sunday last week'));
            break;
        case 'this_month':
            $export_start = date('Y-m-01');
            $export_end = date('Y-m-d');
            break;
        case 'last_month':
            $export_start = date('Y-m-01', strtotime('-1 month'));
            $export_end = date('Y-m-t', strtotime('-1 month'));
            break;
        case 'this_year':
            $export_start = date('Y-01-01');
            $export_end = date('Y-m-d');
            break;
        case 'custom':
        default:
            $export_start = $custom_start;
            $export_end = $custom_end;
            break;
    }
    
    // Redirect to appropriate export script
    switch($export_type) {
        case 'sales':
            header("Location: sales_export.php?start_date=$export_start&end_date=$export_end&format=$format");
            exit;
        case 'inventory':
            header("Location: inventory_export.php?format=$format");
            exit;
        case 'orders':
            header("Location: orders_export.php?start_date=$export_start&end_date=$export_end&format=$format");
            exit;
        case 'qc':
            header("Location: qc_export.php?start_date=$export_start&end_date=$export_end&format=$format");
            exit;
        case 'expiry':
            header("Location: expiry_export.php?format=$format");
            exit;
        case 'all':
            // Generate ZIP file with all reports
            generateAllReportsZip($export_start, $export_end, $format);
            exit;
    }
}

// Function to generate ZIP with all reports
function generateAllReportsZip($start_date, $end_date, $format) {
    // In production, this would generate multiple files and zip them
    // For now, redirect to a script that handles this
    header("Location: export_all.php?start_date=$start_date&end_date=$end_date&format=$format");
    exit;
}

// Get recent exports history
$history_sql = "SELECT 
                  export_type,
                  export_format,
                  export_date,
                  file_size,
                  exported_by
                FROM export_logs 
                ORDER BY export_date DESC 
                LIMIT 10";

// If export_logs table doesn't exist, create dummy data
$history_result = false;
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cosmetics WMS - Export Reports</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <style>
        .export-card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            transition: all 0.3s ease;
            height: 100%;
            overflow: hidden;
        }
        
        .export-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.15);
        }
        
        .export-icon {
            font-size: 2.5rem;
            margin-bottom: 15px;
            opacity: 0.9;
        }
        
        .card-header-custom {
            padding: 20px;
            border-bottom: 1px solid rgba(0,0,0,0.05);
        }
        
        .form-section {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 10px;
            padding: 25px;
            margin-bottom: 30px;
        }
        
        .history-item {
            border-left: 4px solid #007bff;
            padding-left: 15px;
            margin-bottom: 15px;
            background: #f8f9fa;
            padding: 12px;
            border-radius: 5px;
        }
        
        .format-badge {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            margin: 2px;
        }
        
        .count-badge {
            font-size: 12px;
            padding: 3px 8px;
            border-radius: 10px;
        }
        
        .btn-export {
            padding: 10px 20px;
            border-radius: 8px;
            font-weight: 600;
            transition: all 0.3s;
        }
        
        .btn-export:hover {
            transform: scale(1.05);
        }
    </style>
</head>
<body>
    <?php include $root_path . 'includes/sidebar.php'; ?>
    
    <div class="main-content" style="margin-left: 250px; padding: 25px;">
        <!-- HEADER -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h3 class="mb-1">📤 Export Reports</h3>
                <p class="text-muted mb-0">Generate and download system reports</p>
            </div>
            <div class="d-flex">
                <span class="badge bg-primary me-2">
                    <i class="fas fa-calendar"></i> 
                    <?php echo date('d M Y', strtotime($start_date)); ?> - <?php echo date('d M Y', strtotime($end_date)); ?>
                </span>
            </div>
        </div>
        
        <!-- EXPORT FORM -->
        <div class="form-section">
            <h4 class="mb-3"><i class="fas fa-download me-2"></i> Generate Export</h4>
            <form method="POST" action="" id="exportForm">
                <div class="row g-3">
                    <div class="col-md-4">
                        <label class="form-label">Select Report Type</label>
                        <select name="export_type" class="form-select" required id="exportType">
                            <option value="">Choose report type...</option>
                            <option value="sales">Sales Report</option>
                            <option value="inventory">Inventory Report</option>
                            <option value="orders">Orders Report</option>
                            <option value="qc">QC Report</option>
                            <option value="expiry">Expiry Report</option>
                            <option value="all">All Reports (ZIP)</option>
                        </select>
                    </div>
                    
                    <div class="col-md-3">
                        <label class="form-label">Export Format</label>
                        <div class="d-flex">
                            <div class="form-check me-3">
                                <input class="form-check-input" type="radio" name="format" id="formatExcel" value="excel" checked>
                                <label class="form-check-label" for="formatExcel">
                                    <span class="badge bg-success format-badge">Excel</span>
                                </label>
                            </div>
                            <div class="form-check me-3">
                                <input class="form-check-input" type="radio" name="format" id="formatPDF" value="pdf">
                                <label class="form-check-label" for="formatPDF">
                                    <span class="badge bg-danger format-badge">PDF</span>
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="format" id="formatCSV" value="csv">
                                <label class="form-check-label" for="formatCSV">
                                    <span class="badge bg-info format-badge">CSV</span>
                                </label>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-5">
                        <label class="form-label">Date Range</label>
                        <select name="date_range" class="form-select" id="dateRange">
                            <option value="today">Today</option>
                            <option value="yesterday">Yesterday</option>
                            <option value="this_week">This Week</option>
                            <option value="last_week">Last Week</option>
                            <option value="this_month">This Month</option>
                            <option value="last_month">Last Month</option>
                            <option value="this_year">This Year</option>
                            <option value="custom" selected>Custom Range</option>
                        </select>
                    </div>
                    
                    <!-- Custom Date Range (Initially hidden) -->
                    <div class="col-md-6" id="customDateRange">
                        <div class="row g-2">
                            <div class="col-md-6">
                                <label class="form-label">Start Date</label>
                                <input type="date" name="custom_start" class="form-control" value="<?php echo $start_date; ?>">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">End Date</label>
                                <input type="date" name="custom_end" class="form-control" value="<?php echo $end_date; ?>">
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-12 mt-3">
                        <button type="submit" class="btn btn-light btn-export w-100">
                            <i class="fas fa-file-export me-2"></i> Generate Export
                        </button>
                    </div>
                </div>
            </form>
        </div>
        
        <!-- REPORT CARDS -->
        <h4 class="mb-3"><i class="fas fa-chart-bar me-2"></i> Available Reports</h4>
        <div class="row mb-5">
            <?php foreach($reports_summary as $key => $report): ?>
            <div class="col-md-4 mb-4">
                <div class="card export-card border-top-0 border-start-0 border-end-0" 
                     style="border-bottom: 4px solid var(--bs-<?php echo $report['color']; ?>);">
                    <div class="card-header-custom">
                        <div class="d-flex justify-content-between align-items-start">
                            <div>
                                <div class="export-icon text-<?php echo $report['color']; ?>">
                                    <i class="<?php echo $report['icon']; ?>"></i>
                                </div>
                                <h5 class="card-title mb-1"><?php echo $report['title']; ?></h5>
                                <p class="text-muted small mb-2"><?php echo $report['description']; ?></p>
                            </div>
                            <span class="badge bg-<?php echo $report['color']; ?> count-badge">
                                <?php echo number_format($report['count'], 0, ',', '.'); ?> records
                            </span>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="row g-2">
                            <div class="col-6">
                                <button type="button" class="btn btn-outline-<?php echo $report['color']; ?> w-100" 
                                        onclick="quickExport('<?php echo $key; ?>', 'excel')">
                                    <i class="fas fa-file-excel"></i> Excel
                                </button>
                            </div>
                            <div class="col-6">
                                <button type="button" class="btn btn-outline-<?php echo $report['color']; ?> w-100" 
                                        onclick="quickExport('<?php echo $key; ?>', 'pdf')">
                                    <i class="fas fa-file-pdf"></i> PDF
                                </button>
                            </div>
                        </div>
                        <div class="mt-3">
                            <a href="<?php echo $key; ?>_report.php" class="btn btn-link btn-sm p-0">
                                <i class="fas fa-external-link-alt me-1"></i> View Full Report
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        
        <!-- EXPORT HISTORY -->
        <div class="row">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header bg-dark text-white">
                        <h5 class="mb-0"><i class="fas fa-history me-2"></i> Recent Exports</h5>
                    </div>
                    <div class="card-body">
                        <?php if($history_result && mysqli_num_rows($history_result) > 0): ?>
                            <?php while($history = mysqli_fetch_assoc($history_result)): ?>
                            <div class="history-item">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="mb-1"><?php echo ucfirst($history['export_type']); ?> Report</h6>
                                        <small class="text-muted">
                                            <i class="fas fa-user me-1"></i> <?php echo $history['exported_by']; ?> |
                                            <i class="fas fa-calendar me-1"></i> <?php echo date('d M Y H:i', strtotime($history['export_date'])); ?>
                                        </small>
                                    </div>
                                    <div>
                                        <span class="badge bg-<?php echo ($history['export_format'] == 'excel') ? 'success' : 'danger'; ?>">
                                            <?php echo strtoupper($history['export_format']); ?>
                                        </span>
                                        <?php if($history['file_size']): ?>
                                        <small class="text-muted ms-2"><?php echo $history['file_size']; ?> MB</small>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <!-- Dummy history data -->
                            <div class="history-item">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="mb-1">Sales Report</h6>
                                        <small class="text-muted">
                                            <i class="fas fa-user me-1"></i> Admin |
                                            <i class="fas fa-calendar me-1"></i> <?php echo date('d M Y H:i', strtotime('-1 hour')); ?>
                                        </small>
                                    </div>
                                    <div>
                                        <span class="badge bg-success">EXCEL</span>
                                        <small class="text-muted ms-2">1.2 MB</small>
                                    </div>
                                </div>
                            </div>
                            <div class="history-item">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="mb-1">Inventory Report</h6>
                                        <small class="text-muted">
                                            <i class="fas fa-user me-1"></i> Manager |
                                            <i class="fas fa-calendar me-1"></i> <?php echo date('d M Y H:i', strtotime('-3 hours')); ?>
                                        </small>
                                    </div>
                                    <div>
                                        <span class="badge bg-danger">PDF</span>
                                        <small class="text-muted ms-2">0.8 MB</small>
                                    </div>
                                </div>
                            </div>
                            <div class="history-item">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="mb-1">QC Report</h6>
                                        <small class="text-muted">
                                            <i class="fas fa-user me-1"></i> QC Staff |
                                            <i class="fas fa-calendar me-1"></i> <?php echo date('d M Y H:i', strtotime('-1 day')); ?>
                                        </small>
                                    </div>
                                    <div>
                                        <span class="badge bg-success">EXCEL</span>
                                        <small class="text-muted ms-2">0.5 MB</small>
                                    </div>
                                </div>
                            </div>
                            <div class="text-center mt-3">
                                <small class="text-muted">
                                    <i class="fas fa-info-circle me-1"></i>
                                    Export history will be recorded when actual exports are generated
                                </small>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <!-- QUICK ACTIONS -->
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0"><i class="fas fa-bolt me-2"></i> Quick Actions</h5>
                    </div>
                    <div class="card-body">
                        <div class="d-grid gap-2">
                            <button class="btn btn-outline-primary text-start" onclick="exportDailySummary()">
                                <i class="fas fa-sun me-2"></i> Daily Summary Report
                            </button>
                            <button class="btn btn-outline-success text-start" onclick="exportWeeklyReport()">
                                <i class="fas fa-calendar-week me-2"></i> Weekly Performance
                            </button>
                            <button class="btn btn-outline-warning text-start" onclick="exportExpiryAlert()">
                                <i class="fas fa-exclamation-triangle me-2"></i> Expiry Alerts
                            </button>
                            <button class="btn btn-outline-danger text-start" onclick="exportLowStock()">
                                <i class="fas fa-exclamation-circle me-2"></i> Low Stock Report
                            </button>
                            <button class="btn btn-outline-info text-start" onclick="exportMonthlyArchive()">
                                <i class="fas fa-archive me-2"></i> Monthly Archive
                            </button>
                        </div>
                        
                        <hr>
                        
                        <div class="mt-3">
                            <h6><i class="fas fa-cog me-2"></i> Export Settings</h6>
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" id="includeCharts" checked>
                                <label class="form-check-label" for="includeCharts">Include charts in exports</label>
                            </div>
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" id="compressFiles" checked>
                                <label class="form-check-label" for="compressFiles">Compress large files</label>
                            </div>
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" id="emailCopy">
                                <label class="form-check-label" for="emailCopy">Email copy to manager</label>
                            </div>
                        </div>
                        
                        <div class="mt-4">
                            <h6><i class="fas fa-download me-2"></i> Download Templates</h6>
                            <div class="row g-2">
                                <div class="col-6">
                                    <a href="templates/product_import.xlsx" class="btn btn-sm btn-outline-secondary w-100">
                                        <i class="fas fa-file-import"></i> Import Template
                                    </a>
                                </div>
                                <div class="col-6">
                                    <a href="templates/qc_checklist.pdf" class="btn btn-sm btn-outline-secondary w-100">
                                        <i class="fas fa-clipboard-list"></i> QC Checklist
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- SCHEDULED EXPORTS -->
        <div class="card mt-4">
            <div class="card-header bg-success text-white">
                <h5 class="mb-0"><i class="fas fa-clock me-2"></i> Scheduled Exports</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Report</th>
                                <th>Frequency</th>
                                <th>Next Run</th>
                                <th>Recipients</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>
                                    <i class="fas fa-chart-line text-success me-2"></i>
                                    <strong>Daily Sales Report</strong>
                                </td>
                                <td>Daily</td>
                                <td><?php echo date('d M Y', strtotime('+1 day')); ?> 08:00</td>
                                <td>admin@cosmetics.id</td>
                                <td>
                                    <span class="badge bg-success">Active</span>
                                </td>
                                <td>
                                    <button class="btn btn-sm btn-outline-primary">Edit</button>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <i class="fas fa-boxes text-primary me-2"></i>
                                    <strong>Weekly Inventory</strong>
                                </td>
                                <td>Weekly (Monday)</td>
                                <td><?php echo date('d M Y', strtotime('next monday')); ?> 09:00</td>
                                <td>warehouse@cosmetics.id</td>
                                <td>
                                    <span class="badge bg-success">Active</span>
                                </td>
                                <td>
                                    <button class="btn btn-sm btn-outline-primary">Edit</button>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <i class="fas fa-calendar-times text-danger me-2"></i>
                                    <strong>Monthly Expiry Report</strong>
                                </td>
                                <td>Monthly (1st)</td>
                                <td><?php echo date('Y-m-01', strtotime('+1 month')); ?> 10:00</td>
                                <td>qc@cosmetics.id, manager@cosmetics.id</td>
                                <td>
                                    <span class="badge bg-warning">Pending</span>
                                </td>
                                <td>
                                    <button class="btn btn-sm btn-outline-primary">Edit</button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="text-end mt-3">
                    <button class="btn btn-success" onclick="scheduleNewExport()">
                        <i class="fas fa-plus-circle me-2"></i> Schedule New Export
                    </button>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    
    <script>
        // Toggle custom date range
        $(document).ready(function() {
            $('#dateRange').change(function() {
                if ($(this).val() === 'custom') {
                    $('#customDateRange').show();
                } else {
                    $('#customDateRange').hide();
                }
            });
            
            // Trigger change on page load
            $('#dateRange').trigger('change');
        });
        
        // Quick export function
        function quickExport(type, format) {
            const today = new Date().toISOString().split('T')[0];
            const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];
            
            // Set form values and submit
            $('#exportType').val(type);
            $(`#format${format.toUpperCase()}`).prop('checked', true);
            
            // For inventory and expiry reports, use no date range
            if (type === 'inventory' || type === 'expiry') {
                $('#dateRange').val('custom');
                $('input[name="custom_start"]').val('');
                $('input[name="custom_end"]').val('');
            } else {
                $('#dateRange').val('yesterday');
                $('input[name="custom_start"]').val(yesterday);
                $('input[name="custom_end"]').val(yesterday);
            }
            
            $('#dateRange').trigger('change');
            
            // Show confirmation and submit
            if (confirm(`Generate ${type} report in ${format.toUpperCase()} format?`)) {
                $('#exportForm').submit();
            }
        }
        
        // Quick action functions
        function exportDailySummary() {
            const today = new Date().toISOString().split('T')[0];
            window.location.href = `sales_export.php?start_date=${today}&end_date=${today}&format=pdf&type=daily_summary`;
        }
        
        function exportWeeklyReport() {
            const start = new Date(Date.now() - 7 * 86400000).toISOString().split('T')[0];
            const end = new Date().toISOString().split('T')[0];
            window.location.href = `export_all.php?start_date=${start}&end_date=${end}&format=excel&type=weekly`;
        }
        
        function exportExpiryAlert() {
            window.location.href = 'expiry_export.php?format=pdf&alert_type=critical';
        }
        
        function exportLowStock() {
            window.location.href = 'inventory_export.php?format=excel&filter=low_stock';
        }
        
        function exportMonthlyArchive() {
            const year = new Date().getFullYear();
            const month = new Date().getMonth() + 1;
            const monthStr = month.toString().padStart(2, '0');
            window.location.href = `export_all.php?start_date=${year}-${monthStr}-01&end_date=${year}-${monthStr}-31&format=zip&type=monthly`;
        }
        
        // Schedule new export
        function scheduleNewExport() {
            alert('Schedule export feature would open a modal for configuration.\n\nIn production, this would allow:\n1. Selecting report type\n2. Setting frequency (daily/weekly/monthly)\n3. Choosing recipients\n4. Setting export format\n5. Configuring automatic email delivery');
            
            // Example of what could be implemented
            /*
            $('#scheduleModal').modal('show');
            // Or redirect to scheduling page
            window.location.href = 'schedule_export.php';
            */
        }
        
        // Auto-refresh page every 2 minutes
        setTimeout(function() {
            location.reload();
        }, 120000);
        
        // Initialize tooltips
        $(function () {
            $('[data-bs-toggle="tooltip"]').tooltip();
        });
    </script>
</body>
</html>