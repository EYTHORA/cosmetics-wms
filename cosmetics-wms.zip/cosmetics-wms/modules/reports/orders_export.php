<?php
// modules/reports/orders_export.php
$root_path = dirname(dirname(dirname(__FILE__))) . '/';
require_once $root_path . 'includes/config.php';
require_once $root_path . 'includes/auth.php';
checkLogin();

// HEADER untuk file Excel
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=orders_report_" . date('Ymd_His') . ".xls");
header("Pragma: no-cache");
header("Expires: 0");

// Ambil parameter filter sama dengan orders_report.php
$start_date = isset($_GET['start_date']) ? $_GET['start_date'] : date('Y-m-d', strtotime('-30 days'));
$end_date = isset($_GET['end_date']) ? $_GET['end_date'] : date('Y-m-d');
$status = isset($_GET['status']) ? $_GET['status'] : '';
$customer_id = isset($_GET['customer_id']) ? (int)$_GET['customer_id'] : '';
$payment_status = isset($_GET['payment_status']) ? $_GET['payment_status'] : '';
$search = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : '';

// BUILD WHERE CLAUSE (sama dengan orders_report.php)
$where = "o.order_date BETWEEN '$start_date' AND '$end_date 23:59:59'";
if (!empty($status)) $where .= " AND o.status = '$status'";
if (!empty($customer_id)) $where .= " AND o.customer_id = $customer_id";
if (!empty($payment_status)) $where .= " AND o.payment_status = '$payment_status'";
if (!empty($search)) $where .= " AND (o.order_number LIKE '%$search%' OR c.name LIKE '%$search%')";

// Query untuk export
$export_sql = "SELECT 
                 o.order_number,
                 DATE_FORMAT(o.order_date, '%d/%m/%Y') as order_date,
                 c.name as customer_name,
                 c.type as customer_type,
                 c.email as customer_email,
                 o.status,
                 o.priority,
                 o.payment_status,
                 o.total_amount,
                 o.discount,
                 o.tax_amount,
                 o.grand_total,
                 (SELECT COUNT(*) FROM order_items oi WHERE oi.order_id = o.id) as item_count,
                 (SELECT SUM(oi.quantity) FROM order_items oi WHERE oi.order_id = o.id) as total_quantity,
                 DATE_FORMAT(o.delivery_date, '%d/%m/%Y') as delivery_date,
                 o.notes
               FROM orders o
               LEFT JOIN customers c ON o.customer_id = c.id
               WHERE $where
               ORDER BY o.order_date DESC";

$export_result = mysqli_query($conn, $export_sql);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Orders Report Export</title>
</head>
<body>
    <table border="1">
        <tr>
            <th colspan="16" style="background-color: #007bff; color: white; font-size: 16px; padding: 10px;">
                COSMETICS WMS - ORDERS REPORT
            </th>
        </tr>
        <tr>
            <th colspan="16" style="background-color: #f8f9fa; padding: 8px;">
                Period: <?php echo date('d M Y', strtotime($start_date)); ?> to <?php echo date('d M Y', strtotime($end_date)); ?>
                | Generated: <?php echo date('d M Y H:i:s'); ?>
            </th>
        </tr>
        <tr style="background-color: #343a40; color: white;">
            <th>No</th>
            <th>Order Number</th>
            <th>Order Date</th>
            <th>Customer Name</th>
            <th>Customer Type</th>
            <th>Customer Email</th>
            <th>Status</th>
            <th>Priority</th>
            <th>Payment Status</th>
            <th>Total Amount</th>
            <th>Discount</th>
            <th>Tax</th>
            <th>Grand Total</th>
            <th>Items</th>
            <th>Total Qty</th>
            <th>Delivery Date</th>
            <th>Notes</th>
        </tr>
        
        <?php
        $counter = 1;
        $total_amount = 0;
        $total_discount = 0;
        $total_tax = 0;
        $grand_total = 0;
        
        while($row = mysqli_fetch_assoc($export_result)):
            $total_amount += $row['total_amount'];
            $total_discount += $row['discount'];
            $total_tax += $row['tax_amount'];
            $grand_total += $row['grand_total'];
        ?>
        <tr>
            <td><?php echo $counter++; ?></td>
            <td><?php echo $row['order_number']; ?></td>
            <td><?php echo $row['order_date']; ?></td>
            <td><?php echo $row['customer_name']; ?></td>
            <td><?php echo $row['customer_type']; ?></td>
            <td><?php echo $row['customer_email']; ?></td>
            <td><?php echo $row['status']; ?></td>
            <td><?php echo $row['priority']; ?></td>
            <td><?php echo $row['payment_status']; ?></td>
            <td style="text-align: right;"><?php echo number_format($row['total_amount'], 0, ',', '.'); ?></td>
            <td style="text-align: right;"><?php echo number_format($row['discount'], 0, ',', '.'); ?></td>
            <td style="text-align: right;"><?php echo number_format($row['tax_amount'], 0, ',', '.'); ?></td>
            <td style="text-align: right;"><?php echo number_format($row['grand_total'], 0, ',', '.'); ?></td>
            <td style="text-align: center;"><?php echo $row['item_count']; ?></td>
            <td style="text-align: center;"><?php echo $row['total_quantity']; ?></td>
            <td><?php echo $row['delivery_date']; ?></td>
            <td><?php echo substr($row['notes'] ?? '', 0, 50); ?></td>
        </tr>
        <?php endwhile; ?>
        
        <!-- TOTALS ROW -->
        <tr style="background-color: #f8f9fa; font-weight: bold;">
            <td colspan="9" style="text-align: right;">TOTALS:</td>
            <td style="text-align: right;"><?php echo number_format($total_amount, 0, ',', '.'); ?></td>
            <td style="text-align: right;"><?php echo number_format($total_discount, 0, ',', '.'); ?></td>
            <td style="text-align: right;"><?php echo number_format($total_tax, 0, ',', '.'); ?></td>
            <td style="text-align: right;"><?php echo number_format($grand_total, 0, ',', '.'); ?></td>
            <td colspan="4"></td>
        </tr>
    </table>
</body>
</html>