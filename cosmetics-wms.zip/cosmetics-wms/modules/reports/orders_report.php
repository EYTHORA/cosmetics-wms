<?php
// modules/reports/orders_report.php - VERSI FINAL DIPERBAIKI
$root_path = dirname(dirname(dirname(__FILE__))) . '/';
require_once $root_path . 'includes/config.php';
require_once $root_path . 'includes/auth.php';
checkLogin();

$active_menu = 'reports';
$page_title = "Orders Report";

// FILTERS
$start_date = isset($_GET['start_date']) ? $_GET['start_date'] : date('Y-m-d', strtotime('-30 days'));
$end_date = isset($_GET['end_date']) ? $_GET['end_date'] : date('Y-m-d');
$status = isset($_GET['status']) ? $_GET['status'] : '';
$customer_id = isset($_GET['customer_id']) ? (int)$_GET['customer_id'] : '';
$payment_status = isset($_GET['payment_status']) ? $_GET['payment_status'] : '';
$search = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : '';

// VALIDATE DATES
if (!empty($start_date) && !empty($end_date) && $start_date > $end_date) {
    $temp = $start_date;
    $start_date = $end_date;
    $end_date = $temp;
}

// BUILD WHERE CLAUSE
$where = "o.order_date BETWEEN '$start_date' AND '$end_date 23:59:59'";

if (!empty($status)) {
    $where .= " AND o.status = '$status'";
}

if (!empty($customer_id)) {
    $where .= " AND o.customer_id = $customer_id";
}

if (!empty($payment_status)) {
    $where .= " AND o.payment_status = '$payment_status'";
}

if (!empty($search)) {
    $where .= " AND (o.order_number LIKE '%$search%' OR c.name LIKE '%$search%' OR c.email LIKE '%$search%')";
}

// GET CUSTOMERS FOR FILTER
$customers_sql = "SELECT id, name FROM customers WHERE status = 'active' ORDER BY name";
$customers_result = mysqli_query($conn, $customers_sql);

// GET ORDERS DATA
$orders_sql = "SELECT 
                  o.id,
                  o.order_number,
                  o.order_date,
                  o.delivery_date,
                  o.total_amount,
                  o.discount,
                  o.tax_amount,
                  o.grand_total,
                  o.status,
                  o.priority,
                  o.payment_status,
                  o.notes,
                  
                  c.name as customer_name,
                  c.type as customer_type,
                  c.email as customer_email,
                  c.phone as customer_phone,
                  
                  u.full_name as created_by_name,
                  
                  -- Order items count
                  (SELECT COUNT(*) FROM order_items oi WHERE oi.order_id = o.id) as item_count,
                  
                  -- Total quantity
                  (SELECT SUM(oi.quantity) FROM order_items oi WHERE oi.order_id = o.id) as total_quantity,
                  
                  -- Days to delivery
                  CASE 
                    WHEN o.delivery_date IS NOT NULL 
                    THEN DATEDIFF(o.delivery_date, o.order_date)
                    ELSE NULL 
                  END as days_to_delivery
                  
               FROM orders o
               LEFT JOIN customers c ON o.customer_id = c.id
               LEFT JOIN users u ON o.created_by = u.id
               WHERE $where
               ORDER BY o.order_date DESC, o.id DESC";

$orders_result = mysqli_query($conn, $orders_sql);

// GET ORDERS SUMMARY STATS
$summary_sql = "SELECT 
                  -- Total orders
                  COUNT(*) as total_orders,
                  
                  -- Total revenue
                  SUM(o.grand_total) as total_revenue,
                  
                  -- Average order value
                  AVG(o.grand_total) as avg_order_value,
                  
                  -- Min/Max order value
                  MIN(o.grand_total) as min_order_value,
                  MAX(o.grand_total) as max_order_value,
                  
                  -- Total discount given
                  SUM(o.discount) as total_discount,
                  
                  -- Total tax collected
                  SUM(o.tax_amount) as total_tax,
                  
                  -- Unique customers
                  COUNT(DISTINCT o.customer_id) as unique_customers,
                  
                  -- Orders by status
                  COUNT(CASE WHEN o.status = 'draft' THEN 1 END) as draft_count,
                  COUNT(CASE WHEN o.status = 'confirmed' THEN 1 END) as confirmed_count,
                  COUNT(CASE WHEN o.status = 'picking' THEN 1 END) as picking_count,
                  COUNT(CASE WHEN o.status = 'packing' THEN 1 END) as packing_count,
                  COUNT(CASE WHEN o.status = 'shipped' THEN 1 END) as shipped_count,
                  COUNT(CASE WHEN o.status = 'delivered' THEN 1 END) as delivered_count,
                  COUNT(CASE WHEN o.status = 'cancelled' THEN 1 END) as cancelled_count,
                  
                  -- Orders by payment status
                  COUNT(CASE WHEN o.payment_status = 'pending' THEN 1 END) as payment_pending_count,
                  COUNT(CASE WHEN o.payment_status = 'partial' THEN 1 END) as payment_partial_count,
                  COUNT(CASE WHEN o.payment_status = 'paid' THEN 1 END) as payment_paid_count,
                  
                  -- Orders by priority
                  COUNT(CASE WHEN o.priority = 'normal' THEN 1 END) as priority_normal_count,
                  COUNT(CASE WHEN o.priority = 'urgent' THEN 1 END) as priority_urgent_count,
                  COUNT(CASE WHEN o.priority = 'express' THEN 1 END) as priority_express_count
                  
                FROM orders o
                WHERE $where";

$summary_result = mysqli_query($conn, $summary_sql);
$summary = $summary_result ? mysqli_fetch_assoc($summary_result) : [
    'total_orders' => 0,
    'total_revenue' => 0,
    'avg_order_value' => 0,
    'min_order_value' => 0,
    'max_order_value' => 0,
    'total_discount' => 0,
    'total_tax' => 0,
    'unique_customers' => 0,
    'draft_count' => 0,
    'confirmed_count' => 0,
    'picking_count' => 0,
    'packing_count' => 0,
    'shipped_count' => 0,
    'delivered_count' => 0,
    'cancelled_count' => 0,
    'payment_pending_count' => 0,
    'payment_partial_count' => 0,
    'payment_paid_count' => 0,
    'priority_normal_count' => 0,
    'priority_urgent_count' => 0,
    'priority_express_count' => 0
];

// GET DAILY SALES FOR CHART
$daily_sales_sql = "SELECT 
                      DATE(o.order_date) as sale_date,
                      COUNT(o.id) as order_count,
                      SUM(o.grand_total) as daily_revenue,
                      AVG(o.grand_total) as avg_order_value
                    FROM orders o
                    WHERE $where
                    GROUP BY DATE(o.order_date)
                    ORDER BY sale_date DESC
                    LIMIT 30";

$daily_sales_result = mysqli_query($conn, $daily_sales_sql);

// PREPARE CHART DATA
$chart_labels = [];
$chart_revenue = [];
$chart_orders = [];

if ($daily_sales_result && mysqli_num_rows($daily_sales_result) > 0) {
    while ($row = mysqli_fetch_assoc($daily_sales_result)) {
        $chart_labels[] = date('d M', strtotime($row['sale_date']));
        $chart_revenue[] = (float)$row['daily_revenue'];
        $chart_orders[] = (int)$row['order_count'];
    }
    // Reverse untuk chronological order
    $chart_labels = array_reverse($chart_labels);
    $chart_revenue = array_reverse($chart_revenue);
    $chart_orders = array_reverse($chart_orders);
} else {
    // Default data jika tidak ada
    $chart_labels = ['No Data'];
    $chart_revenue = [0];
    $chart_orders = [0];
}

// GET TOP CUSTOMERS BY REVENUE
$top_customers_sql = "SELECT 
                        c.name as customer_name,
                        c.type as customer_type,
                        COUNT(o.id) as order_count,
                        SUM(o.grand_total) as total_spent,
                        AVG(o.grand_total) as avg_order_value,
                        MAX(o.order_date) as last_order_date
                      FROM orders o
                      JOIN customers c ON o.customer_id = c.id
                      WHERE $where
                      GROUP BY c.id
                      ORDER BY total_spent DESC
                      LIMIT 10";

$top_customers_result = mysqli_query($conn, $top_customers_sql);

// GET TOP PRODUCTS SOLD
$top_products_sql = "SELECT 
                       p.name as product_name,
                       p.sku,
                       SUM(oi.quantity) as total_sold,
                       SUM(oi.total_price) as revenue,
                       COUNT(DISTINCT o.id) as order_count
                     FROM order_items oi
                     JOIN products p ON oi.product_id = p.id
                     JOIN orders o ON oi.order_id = o.id
                     WHERE $where
                     GROUP BY p.id
                     ORDER BY total_sold DESC
                     LIMIT 10";

$top_products_result = mysqli_query($conn, $top_products_sql);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cosmetics WMS - Orders Report</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    
    <style>
        .summary-card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.08);
            transition: all 0.3s;
            margin-bottom: 20px;
        }
        
        .summary-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        .status-badge {
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
        }
        
        .priority-badge {
            font-size: 11px;
            padding: 3px 8px;
            border-radius: 4px;
        }
        
        .payment-badge {
            font-size: 11px;
            padding: 3px 8px;
            border-radius: 4px;
        }
        
        .customer-type-badge {
            background-color: #e9ecef;
            color: #495057;
            font-size: 10px;
            padding: 2px 6px;
            border-radius: 3px;
        }
        
        .chart-container {
            position: relative;
            height: 300px;
            width: 100%;
        }
        
        .revenue-text {
            color: #28a745;
            font-weight: bold;
        }
        
        .orders-text {
            color: #007bff;
            font-weight: bold;
        }
        
        .customers-text {
            color: #6f42c1;
            font-weight: bold;
        }
        
        .avg-text {
            color: #17a2b8;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <?php include $root_path . 'includes/sidebar.php'; ?>
    
    <div class="main-content" style="margin-left: 250px; padding: 25px;">
        <!-- HEADER -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h3 class="mb-1">📊 Orders Report</h3>
                <p class="text-muted mb-0">Sales and order analytics</p>
            </div>
            <div class="d-flex">
                <button onclick="window.print()" class="btn btn-secondary me-2">
                    <i class="fas fa-print"></i> Print
                </button>
                <button class="btn btn-success" onclick="exportOrdersReport()">
                    <i class="fas fa-file-excel"></i> Export Excel
                </button>
            </div>
        </div>
        
        <!-- FILTERS -->
        <div class="card mb-4">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0">🔍 Filter Orders</h5>
            </div>
            <div class="card-body">
                <form method="GET" action="" class="row g-3">
                    <div class="col-md-2">
                        <label class="form-label">Start Date</label>
                        <input type="date" name="start_date" class="form-control" 
                               value="<?php echo $start_date; ?>" required>
                    </div>
                    <div class="col-md-2">
                        <label class="form-label">End Date</label>
                        <input type="date" name="end_date" class="form-control" 
                               value="<?php echo $end_date; ?>" required>
                    </div>
                    <div class="col-md-2">
                        <label class="form-label">Order Status</label>
                        <select name="status" class="form-select">
                            <option value="">All Status</option>
                            <option value="draft" <?php echo ($status == 'draft') ? 'selected' : ''; ?>>Draft</option>
                            <option value="confirmed" <?php echo ($status == 'confirmed') ? 'selected' : ''; ?>>Confirmed</option>
                            <option value="picking" <?php echo ($status == 'picking') ? 'selected' : ''; ?>>Picking</option>
                            <option value="packing" <?php echo ($status == 'packing') ? 'selected' : ''; ?>>Packing</option>
                            <option value="shipped" <?php echo ($status == 'shipped') ? 'selected' : ''; ?>>Shipped</option>
                            <option value="delivered" <?php echo ($status == 'delivered') ? 'selected' : ''; ?>>Delivered</option>
                            <option value="cancelled" <?php echo ($status == 'cancelled') ? 'selected' : ''; ?>>Cancelled</option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <label class="form-label">Payment Status</label>
                        <select name="payment_status" class="form-select">
                            <option value="">All Payments</option>
                            <option value="pending" <?php echo ($payment_status == 'pending') ? 'selected' : ''; ?>>Pending</option>
                            <option value="partial" <?php echo ($payment_status == 'partial') ? 'selected' : ''; ?>>Partial</option>
                            <option value="paid" <?php echo ($payment_status == 'paid') ? 'selected' : ''; ?>>Paid</option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <label class="form-label">Customer</label>
                        <select name="customer_id" class="form-select">
                            <option value="">All Customers</option>
                            <?php 
                            if ($customers_result && mysqli_num_rows($customers_result) > 0):
                                mysqli_data_seek($customers_result, 0);
                                while($cust = mysqli_fetch_assoc($customers_result)): 
                            ?>
                                <option value="<?php echo $cust['id']; ?>" 
                                    <?php echo ($customer_id == $cust['id']) ? 'selected' : ''; ?>>
                                    <?php echo $cust['name']; ?>
                                </option>
                            <?php 
                                endwhile;
                            endif; 
                            ?>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <label class="form-label">Search</label>
                        <input type="text" name="search" class="form-control" 
                               placeholder="Order # or Customer..." 
                               value="<?php echo htmlspecialchars($search); ?>">
                    </div>
                    <div class="col-md-12">
                        <div class="d-flex justify-content-end">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-filter"></i> Apply Filter
                            </button>
                            <a href="orders_report.php" class="btn btn-secondary ms-2">
                                <i class="fas fa-redo"></i> Reset
                            </a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- SUMMARY STATS -->
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="card summary-card border-left-success">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-1">Total Revenue</h6>
                                <h3 class="revenue-text mb-0">
                                    Rp <?php echo number_format($summary['total_revenue'] ?? 0, 0, ',', '.'); ?>
                                </h3>
                                <small class="text-muted"><?php echo date('d M', strtotime($start_date)); ?> - <?php echo date('d M Y', strtotime($end_date)); ?></small>
                            </div>
                            <div class="text-success">
                                <i class="fas fa-money-bill-wave fa-2x"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3">
                <div class="card summary-card border-left-primary">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-1">Total Orders</h6>
                                <h3 class="orders-text mb-0">
                                    <?php echo number_format($summary['total_orders'] ?? 0, 0, ',', '.'); ?>
                                </h3>
                                <small class="text-muted">Completed orders</small>
                            </div>
                            <div class="text-primary">
                                <i class="fas fa-shopping-cart fa-2x"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3">
                <div class="card summary-card border-left-info">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-1">Avg. Order Value</h6>
                                <h3 class="avg-text mb-0">
                                    Rp <?php echo number_format($summary['avg_order_value'] ?? 0, 0, ',', '.'); ?>
                                </h3>
                                <small class="text-muted">Per transaction</small>
                            </div>
                            <div class="text-info">
                                <i class="fas fa-chart-line fa-2x"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3">
                <div class="card summary-card border-left-warning">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-1">Unique Customers</h6>
                                <h3 class="customers-text mb-0">
                                    <?php echo number_format($summary['unique_customers'] ?? 0, 0, ',', '.'); ?>
                                </h3>
                                <small class="text-muted">Active customers</small>
                            </div>
                            <div class="text-warning">
                                <i class="fas fa-users fa-2x"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- STATUS SUMMARY & PAYMENT SUMMARY -->
        <div class="row mb-4">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header bg-info text-white">
                        <h5 class="mb-0">📈 Order Status Distribution</h5>
                    </div>
                    <div class="card-body">
                        <div class="row text-center">
                            <div class="col-md-2 mb-2">
                                <div class="bg-secondary text-white p-2 rounded">
                                    <h6 class="mb-0"><?php echo $summary['draft_count'] ?? 0; ?></h6>
                                    <small>Draft</small>
                                </div>
                            </div>
                            <div class="col-md-2 mb-2">
                                <div class="bg-primary text-white p-2 rounded">
                                    <h6 class="mb-0"><?php echo $summary['confirmed_count'] ?? 0; ?></h6>
                                    <small>Confirmed</small>
                                </div>
                            </div>
                            <div class="col-md-2 mb-2">
                                <div class="bg-warning text-dark p-2 rounded">
                                    <h6 class="mb-0"><?php echo $summary['picking_count'] ?? 0; ?></h6>
                                    <small>Picking</small>
                                </div>
                            </div>
                            <div class="col-md-2 mb-2">
                                <div class="bg-info text-white p-2 rounded">
                                    <h6 class="mb-0"><?php echo $summary['packing_count'] ?? 0; ?></h6>
                                    <small>Packing</small>
                                </div>
                            </div>
                            <div class="col-md-2 mb-2">
                                <div class="bg-success text-white p-2 rounded">
                                    <h6 class="mb-0"><?php echo $summary['shipped_count'] ?? 0; ?></h6>
                                    <small>Shipped</small>
                                </div>
                            </div>
                            <div class="col-md-2 mb-2">
                                <div class="bg-dark text-white p-2 rounded">
                                    <h6 class="mb-0"><?php echo $summary['delivered_count'] ?? 0; ?></h6>
                                    <small>Delivered</small>
                                </div>
                            </div>
                        </div>
                        
                        <!-- PROGRESS BAR DENGAN ERROR HANDLING -->
                        <div class="mt-3">
                            <?php
                            $total_orders = $summary['total_orders'] ?? 0;
                            
                            if ($total_orders > 0):
                                $draft_percent = ($summary['draft_count'] ?? 0) / $total_orders * 100;
                                $confirmed_percent = ($summary['confirmed_count'] ?? 0) / $total_orders * 100;
                                $picking_percent = ($summary['picking_count'] ?? 0) / $total_orders * 100;
                                $packing_percent = ($summary['packing_count'] ?? 0) / $total_orders * 100;
                                $shipped_percent = ($summary['shipped_count'] ?? 0) / $total_orders * 100;
                                $delivered_percent = ($summary['delivered_count'] ?? 0) / $total_orders * 100;
                                $cancelled_percent = ($summary['cancelled_count'] ?? 0) / $total_orders * 100;
                            ?>
                            <div class="progress" style="height: 20px;">
                                <div class="progress-bar bg-secondary" style="width: <?php echo $draft_percent; ?>%"></div>
                                <div class="progress-bar bg-primary" style="width: <?php echo $confirmed_percent; ?>%"></div>
                                <div class="progress-bar bg-warning" style="width: <?php echo $picking_percent; ?>%"></div>
                                <div class="progress-bar bg-info" style="width: <?php echo $packing_percent; ?>%"></div>
                                <div class="progress-bar bg-success" style="width: <?php echo $shipped_percent; ?>%"></div>
                                <div class="progress-bar bg-dark" style="width: <?php echo $delivered_percent; ?>%"></div>
                                <div class="progress-bar bg-danger" style="width: <?php echo $cancelled_percent; ?>%"></div>
                            </div>
                            <?php else: ?>
                            <div class="progress" style="height: 20px;">
                                <div class="progress-bar bg-light text-dark" style="width: 100%;">
                                    No orders found
                                </div>
                            </div>
                            <?php endif; ?>
                            
                            <small class="text-muted">Total Orders: <?php echo $total_orders; ?></small>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header bg-success text-white">
                        <h5 class="mb-0">💰 Payment Status Summary</h5>
                    </div>
                    <div class="card-body">
                        <div class="row text-center">
                            <div class="col-md-4 mb-2">
                                <div class="bg-warning text-dark p-2 rounded">
                                    <h6 class="mb-0"><?php echo $summary['payment_pending_count'] ?? 0; ?></h6>
                                    <small>Pending</small>
                                </div>
                            </div>
                            <div class="col-md-4 mb-2">
                                <div class="bg-info text-white p-2 rounded">
                                    <h6 class="mb-0"><?php echo $summary['payment_partial_count'] ?? 0; ?></h6>
                                    <small>Partial</small>
                                </div>
                            </div>
                            <div class="col-md-4 mb-2">
                                <div class="bg-success text-white p-2 rounded">
                                    <h6 class="mb-0"><?php echo $summary['payment_paid_count'] ?? 0; ?></h6>
                                    <small>Paid</small>
                                </div>
                            </div>
                        </div>
                        <div class="mt-3">
                            <?php
                            // Tambahkan error handling untuk nilai null
                            $total_discount = $summary['total_discount'] ?? 0;
                            $total_tax = $summary['total_tax'] ?? 0;
                            $min_order = $summary['min_order_value'] ?? 0;
                            $max_order = $summary['max_order_value'] ?? 0;
                            ?>
                            <h6>Total Discount Given: <span class="text-danger">Rp <?php echo number_format($total_discount, 0, ',', '.'); ?></span></h6>
                            <h6>Total Tax Collected: <span class="text-primary">Rp <?php echo number_format($total_tax, 0, ',', '.'); ?></span></h6>
                            <h6>Min Order: <span class="text-muted">Rp <?php echo number_format($min_order, 0, ',', '.'); ?></span></h6>
                            <h6>Max Order: <span class="text-muted">Rp <?php echo number_format($max_order, 0, ',', '.'); ?></span></h6>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- SALES CHART -->
        <div class="card mb-4">
            <div class="card-header bg-success text-white">
                <h5 class="mb-0">📊 Daily Sales Trend</h5>
            </div>
            <div class="card-body">
                <div class="chart-container">
                    <canvas id="salesChart"></canvas>
                </div>
            </div>
        </div>
        
        <!-- ORDERS TABLE -->
        <div class="card mb-4">
            <div class="card-header bg-dark text-white d-flex justify-content-between align-items-center">
                <h5 class="mb-0">📋 Order Details</h5>
                <span class="badge bg-light text-dark">
                    <?php echo $orders_result ? mysqli_num_rows($orders_result) : 0; ?> orders found
                </span>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover" id="ordersTable">
                        <thead>
                            <tr>
                                <th>Order #</th>
                                <th>Customer</th>
                                <th>Date</th>
                                <th>Items</th>
                                <th>Amount</th>
                                <th>Status</th>
                                <th>Payment</th>
                                <th>Priority</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($orders_result && mysqli_num_rows($orders_result) > 0): ?>
                                <?php while($order = mysqli_fetch_assoc($orders_result)): 
                                    // Status badge
                                    $status_class = '';
                                    switch($order['status']) {
                                        case 'draft':
                                            $status_class = 'bg-secondary';
                                            break;
                                        case 'confirmed':
                                            $status_class = 'bg-primary';
                                            break;
                                        case 'picking':
                                            $status_class = 'bg-warning text-dark';
                                            break;
                                        case 'packing':
                                            $status_class = 'bg-info';
                                            break;
                                        case 'shipped':
                                            $status_class = 'bg-success';
                                            break;
                                        case 'delivered':
                                            $status_class = 'bg-dark';
                                            break;
                                        case 'cancelled':
                                            $status_class = 'bg-danger';
                                            break;
                                    }
                                    
                                    // Payment badge
                                    $payment_class = '';
                                    switch($order['payment_status']) {
                                        case 'pending':
                                            $payment_class = 'bg-warning text-dark';
                                            break;
                                        case 'partial':
                                            $payment_class = 'bg-info';
                                            break;
                                        case 'paid':
                                            $payment_class = 'bg-success';
                                            break;
                                    }
                                    
                                    // Priority badge
                                    $priority_class = '';
                                    switch($order['priority']) {
                                        case 'normal':
                                            $priority_class = 'bg-secondary';
                                            break;
                                        case 'urgent':
                                            $priority_class = 'bg-danger';
                                            break;
                                        case 'express':
                                            $priority_class = 'bg-warning text-dark';
                                            break;
                                    }
                                ?>
                                <tr>
                                    <td>
                                        <strong><?php echo $order['order_number']; ?></strong>
                                        <?php if(!empty($order['notes'])): ?>
                                            <br><small class="text-muted"><i class="fas fa-sticky-note"></i> Note</small>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <strong><?php echo $order['customer_name']; ?></strong><br>
                                        <small class="text-muted"><?php echo $order['customer_email']; ?></small><br>
                                        <span class="customer-type-badge"><?php echo $order['customer_type']; ?></span>
                                    </td>
                                    <td>
                                        <?php echo date('d M Y', strtotime($order['order_date'])); ?><br>
                                        <small class="text-muted">
                                            <?php echo $order['delivery_date'] ? 'Deliver: ' . date('d M', strtotime($order['delivery_date'])) : 'No delivery date'; ?>
                                        </small>
                                    </td>
                                    <td>
                                        <span class="badge bg-primary"><?php echo $order['item_count']; ?> items</span><br>
                                        <small class="text-muted"><?php echo $order['total_quantity']; ?> pcs total</small>
                                    </td>
                                    <td>
                                        <div>
                                            <strong class="text-success">Rp <?php echo number_format($order['grand_total'], 0, ',', '.'); ?></strong>
                                        </div>
                                        <small class="text-muted">
                                            Sub: Rp <?php echo number_format($order['total_amount'], 0, ',', '.'); ?><br>
                                            Disc: Rp <?php echo number_format($order['discount'], 0, ',', '.'); ?>
                                        </small>
                                    </td>
                                    <td>
                                        <span class="badge <?php echo $status_class; ?> status-badge">
                                            <?php echo ucfirst($order['status']); ?>
                                        </span>
                                        <?php if($order['days_to_delivery'] > 0): ?>
                                            <br><small class="text-muted"><?php echo $order['days_to_delivery']; ?> days</small>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="badge <?php echo $payment_class; ?> payment-badge">
                                            <?php echo ucfirst($order['payment_status']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="badge <?php echo $priority_class; ?> priority-badge">
                                            <?php echo ucfirst($order['priority']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <div class="btn-group" role="group">
                                            <a href="../orders/view.php?id=<?php echo $order['id']; ?>" 
                                               class="btn btn-sm btn-info" title="View">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                            <a href="../orders/print.php?id=<?php echo $order['id']; ?>" 
                                               class="btn btn-sm btn-secondary" title="Print" target="_blank">
                                                <i class="fas fa-print"></i>
                                            </a>
                                            <a href="../orders/edit.php?id=<?php echo $order['id']; ?>" 
                                               class="btn btn-sm btn-warning" title="Edit">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="9" class="text-center py-4">
                                        <div class="text-muted">
                                            <i class="fas fa-shopping-cart fa-2x mb-3"></i><br>
                                            No orders found with current filters.
                                        </div>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        
        <!-- TWO COLUMNS: TOP CUSTOMERS & TOP PRODUCTS -->
        <div class="row">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0">👥 Top 10 Customers by Revenue</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-sm">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Customer</th>
                                        <th>Orders</th>
                                        <th>Total Spent</th>
                                        <th>Avg Order</th>
                                        <th>Last Order</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if($top_customers_result && mysqli_num_rows($top_customers_result) > 0): ?>
                                        <?php $rank = 1; ?>
                                        <?php while($customer = mysqli_fetch_assoc($top_customers_result)): ?>
                                        <tr>
                                            <td>
                                                <span class="badge bg-<?php echo ($rank <= 3) ? 'warning text-dark' : 'secondary'; ?>">
                                                    <?php echo $rank; ?>
                                                </span>
                                            </td>
                                            <td>
                                                <strong><?php echo $customer['customer_name']; ?></strong><br>
                                                <small class="text-muted"><?php echo $customer['customer_type']; ?></small>
                                            </td>
                                            <td>
                                                <span class="badge bg-info"><?php echo $customer['order_count']; ?> orders</span>
                                            </td>
                                            <td>
                                                <strong class="text-success">Rp <?php echo number_format($customer['total_spent'], 0, ',', '.'); ?></strong>
                                            </td>
                                            <td>
                                                Rp <?php echo number_format($customer['avg_order_value'], 0, ',', '.'); ?>
                                            </td>
                                            <td>
                                                <?php echo $customer['last_order_date'] ? date('d M', strtotime($customer['last_order_date'])) : 'N/A'; ?>
                                            </td>
                                        </tr>
                                        <?php $rank++; ?>
                                        <?php endwhile; ?>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="6" class="text-center py-3">
                                                <div class="text-muted">
                                                    <i class="fas fa-users"></i> No customer data
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header bg-success text-white">
                        <h5 class="mb-0">🏆 Top 10 Products Sold</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-sm">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Product</th>
                                        <th>SKU</th>
                                        <th>Sold</th>
                                        <th>Revenue</th>
                                        <th>Orders</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if($top_products_result && mysqli_num_rows($top_products_result) > 0): ?>
                                        <?php $rank = 1; ?>
                                        <?php while($product = mysqli_fetch_assoc($top_products_result)): ?>
                                        <tr>
                                            <td>
                                                <span class="badge bg-<?php echo ($rank <= 3) ? 'warning text-dark' : 'secondary'; ?>">
                                                    <?php echo $rank; ?>
                                                </span>
                                            </td>
                                            <td>
                                                <strong><?php echo $product['product_name']; ?></strong>
                                            </td>
                                            <td>
                                                <small class="text-muted"><?php echo $product['sku']; ?></small>
                                            </td>
                                            <td>
                                                <span class="badge bg-primary"><?php echo $product['total_sold']; ?> pcs</span>
                                            </td>
                                            <td>
                                                <strong class="text-success">Rp <?php echo number_format($product['revenue'], 0, ',', '.'); ?></strong>
                                            </td>
                                            <td>
                                                <?php echo $product['order_count']; ?> orders
                                            </td>
                                        </tr>
                                        <?php $rank++; ?>
                                        <?php endwhile; ?>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="6" class="text-center py-3">
                                                <div class="text-muted">
                                                    <i class="fas fa-box-open"></i> No product sales data
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
    
    <script>
        // Initialize DataTable
        $(document).ready(function() {
            $('#ordersTable').DataTable({
                "pageLength": 25,
                "order": [[0, 'desc']],
                "language": {
                    "search": "Search orders...",
                    "lengthMenu": "Show _MENU_ orders per page",
                    "zeroRecords": "No orders found",
                    "info": "Showing _START_ to _END_ of _TOTAL_ orders",
                    "infoEmpty": "No orders available",
                    "infoFiltered": "(filtered from _MAX_ total orders)",
                    "paginate": {
                        "first": "First",
                        "last": "Last",
                        "next": "Next",
                        "previous": "Previous"
                    }
                }
            });
        });
        
        // Sales Chart
        const ctx = document.getElementById('salesChart').getContext('2d');
        const salesChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: <?php echo json_encode($chart_labels); ?>,
                datasets: [
                    {
                        label: 'Revenue (Rp)',
                        data: <?php echo json_encode($chart_revenue); ?>,
                        borderColor: '#28a745',
                        backgroundColor: 'rgba(40, 167, 69, 0.1)',
                        borderWidth: 2,
                        fill: true,
                        yAxisID: 'y'
                    },
                    {
                        label: 'Orders (Count)',
                        data: <?php echo json_encode($chart_orders); ?>,
                        borderColor: '#007bff',
                        backgroundColor: 'rgba(0, 123, 255, 0.1)',
                        borderWidth: 2,
                        fill: true,
                        yAxisID: 'y1'
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                interaction: {
                    mode: 'index',
                    intersect: false,
                },
                scales: {
                    x: {
                        grid: {
                            display: false
                        }
                    },
                    y: {
                        type: 'linear',
                        display: true,
                        position: 'left',
                        title: {
                            display: true,
                            text: 'Revenue (Rp)'
                        },
                        ticks: {
                            callback: function(value) {
                                if (value >= 1000000) {
                                    return 'Rp ' + (value / 1000000).toFixed(1) + 'M';
                                } else if (value >= 1000) {
                                    return 'Rp ' + (value / 1000).toFixed(0) + 'K';
                                }
                                return 'Rp ' + value;
                            }
                        }
                    },
                    y1: {
                        type: 'linear',
                        display: true,
                        position: 'right',
                        title: {
                            display: true,
                            text: 'Orders Count'
                        },
                        grid: {
                            drawOnChartArea: false,
                        },
                    }
                },
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                let label = context.dataset.label || '';
                                if (label.includes('Revenue')) {
                                    label += ': Rp ' + context.parsed.y.toLocaleString('id-ID');
                                } else {
                                    label += ': ' + context.parsed.y + ' orders';
                                }
                                return label;
                            }
                        }
                    },
                    legend: {
                        position: 'top',
                    }
                }
            }
        });
        
        // Export function
        function exportOrdersReport() {
            const params = new URLSearchParams(window.location.search);
            params.append('export', 'excel');
            
            if (confirm('Export orders report to Excel?')) {
                window.location.href = 'orders_export.php?' + params.toString();
            }
        }
        
        // Auto-refresh every 3 minutes
        setTimeout(function() {
            location.reload();
        }, 180000);
    </script>
</body>
</html>