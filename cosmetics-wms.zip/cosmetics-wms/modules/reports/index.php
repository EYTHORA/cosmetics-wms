<?php
// modules/reports/index.php
$root_path = dirname(dirname(dirname(__FILE__))) . '/';
require_once $root_path . 'includes/config.php';
require_once $root_path . 'includes/auth.php';
checkLogin();

$active_menu = 'reports';
$page_title = "Reports & Analytics";
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cosmetics WMS - Reports</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <style>
        .report-card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.08);
            transition: all 0.3s;
            height: 100%;
            text-align: center;
            padding: 30px 20px;
        }
        
        .report-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        .report-icon {
            font-size: 3rem;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <?php include $root_path . 'includes/sidebar.php'; ?>
    
    <div class="main-content" style="margin-left: 250px; padding: 25px;">
        <!-- HEADER -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h3 class="mb-1">📈 Reports & Analytics</h3>
                <p class="text-muted mb-0">Generate and analyze business reports</p>
            </div>
            <div>
                <span class="badge bg-primary">Last updated: Today 09:00</span>
            </div>
        </div>
        
        <!-- REPORT CARDS -->
        <div class="row mb-4">
            <div class="col-md-3 mb-3">
                <div class="report-card bg-primary text-white">
                    <i class="fas fa-chart-line report-icon"></i>
                    <h5>Sales Report</h5>
                    <p>Monthly sales performance</p>
                    <a href="sales.php" class="btn btn-light">View Report</a>
                </div>
            </div>
            
            <div class="col-md-3 mb-3">
                <div class="report-card bg-success text-white">
                    <i class="fas fa-box report-icon"></i>
                    <h5>Inventory Report</h5>
                    <p>Stock levels & movements</p>
                    <a href="inventory_report.php" class="btn btn-light">View Report</a>
                </div>
            </div>
            
            <div class="col-md-3 mb-3">
                <div class="report-card bg-danger text-white">
                    <i class="fas fa-calendar-times report-icon"></i>
                    <h5>Expiry Report</h5>
                    <p>Products nearing expiry</p>
                    <a href="expiry_report.php" class="btn btn-light">View Report</a>
                </div>
            </div>
            
            <div class="col-md-3 mb-3">
                <div class="report-card bg-warning text-white">
                    <i class="fas fa-truck report-icon"></i>
                    <h5>Order Report</h5>
                    <p>Order fulfillment status</p>
                    <a href="orders_report.php" class="btn btn-light">View Report</a>
                </div>
            </div>
        </div>
        
        <!-- MORE REPORTS -->
        <div class="row mb-4">
            <div class="col-md-3 mb-3">
                <div class="report-card bg-info text-white">
                    <i class="fas fa-clipboard-check report-icon"></i>
                    <h5>QC Report</h5>
                    <p>Quality control results</p>
                    <a href="qc_report.php" class="btn btn-light">View Report</a>
                </div>
            </div>
            
            <div class="col-md-3 mb-3">
                <div class="report-card bg-secondary text-white">
                    <i class="fas fa-file-export report-icon"></i>
                    <h5>Export Data</h5>
                    <p>Export to Excel/PDF</p>
                    <a href="export.php" class="btn btn-light">Export</a>
                </div>
            </div>
            
            <div class="col-md-3 mb-3">
                <div class="report-card bg-dark text-white">
                    <i class="fas fa-users report-icon"></i>
                    <h5>Customer Report</h5>
                    <p>Customer orders analysis</p>
                    <a href="customer_report.php" class="btn btn-light">View Report</a>
                </div>
            </div>
            
            <div class="col-md-3 mb-3">
                <div class="report-card" style="background: #9b59b6; color: white;">
                    <i class="fas fa-chart-pie report-icon"></i>
                    <h5>Analytics</h5>
                    <p>Business insights</p>
                    <a href="analytics.php" class="btn btn-light">View Analytics</a>
                </div>
            </div>
        </div>
        
        <!-- QUICK STATISTICS -->
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="mb-0">📊 Quick Statistics (January 2024)</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <h6>Sales Performance</h6>
                        <div class="mb-3">
                            <small class="d-block mb-1">Total Sales</small>
                            <h4 class="text-primary">Rp 48,500,000</h4>
                            <small class="text-success">↑ 15% from December</small>
                        </div>
                        <div class="mb-3">
                            <small class="d-block mb-1">Average Order Value</small>
                            <h4>Rp 310,000</h4>
                        </div>
                        <div class="mb-3">
                            <small class="d-block mb-1">Orders Completed</small>
                            <h4>156 orders</h4>
                            <small>84% success rate</small>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <h6>Inventory Status</h6>
                        <div class="mb-3">
                            <small class="d-block mb-1">Total Products</small>
                            <h4 class="text-success">48 products</h4>
                        </div>
                        <div class="mb-3">
                            <small class="d-block mb-1">Low Stock Items</small>
                            <h4 class="text-warning">12 items</h4>
                            <small>Need replenishment</small>
                        </div>
                        <div class="mb-3">
                            <small class="d-block mb-1">Expiring Soon</small>
                            <h4 class="text-danger">3 batches</h4>
                            <small>Within 30 days</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- REPORT GENERATOR -->
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">🛠️ Custom Report Generator</h5>
            </div>
            <div class="card-body">
                <form>
                    <div class="row g-3 mb-3">
                        <div class="col-md-3">
                            <label class="form-label">Report Type</label>
                            <select class="form-select">
                                <option>Sales Report</option>
                                <option>Inventory Report</option>
                                <option>Order Report</option>
                                <option>Expiry Report</option>
                                <option>Custom Report</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Start Date</label>
                            <input type="date" class="form-control" value="2024-01-01">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">End Date</label>
                            <input type="date" class="form-control" value="2024-01-15">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Format</label>
                            <select class="form-select">
                                <option>PDF</option>
                                <option>Excel</option>
                                <option>CSV</option>
                                <option>HTML</option>
                            </select>
                        </div>
                    </div>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Additional Filters</label>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox">
                                <label class="form-check-label">Include graphs</label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox">
                                <label class="form-check-label">Include details</label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox">
                                <label class="form-check-label">Email report</label>
                            </div>
                        </div>
                        <div class="col-md-6 d-flex align-items-end">
                            <button type="submit" class="btn btn-primary w-100">
                                <i class="fas fa-download"></i> Generate Report
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>