<?php
// modules/products/edit.php
define('ROOT_PATH', dirname(dirname(dirname(__FILE__))) . '/');
require_once ROOT_PATH . 'includes/config.php';
require_once ROOT_PATH . 'includes/auth.php';
checkLogin();

$page_title = "Edit Product";
$success = false;
$error = '';

// Get product ID
$product_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if(!$product_id) {
    header("Location: index.php");
    exit();
}

// Get product data
$product_sql = "SELECT * FROM products WHERE id = $product_id";
$product_result = mysqli_query($conn, $product_sql);

if(mysqli_num_rows($product_result) == 0) {
    header("Location: index.php");
    exit();
}

$product = mysqli_fetch_assoc($product_result);

// Handle form submission
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $sku = mysqli_real_escape_string($conn, $_POST['sku']);
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $category_id = intval($_POST['category_id']);
    $brand_id = intval($_POST['brand_id']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $weight = floatval($_POST['weight']);
    $dimensions = mysqli_real_escape_string($conn, $_POST['dimensions']);
    $unit_price = floatval($_POST['unit_price']);
    $min_stock = intval($_POST['min_stock']);
    $max_stock = intval($_POST['max_stock']);
    $weight_volume = mysqli_real_escape_string($conn, $_POST['weight_volume']);
    $halal_certified = isset($_POST['halal_certified']) ? 1 : 0;
    $bpom_required = isset($_POST['bpom_required']) ? 1 : 0;
    $storage_temperature = mysqli_real_escape_string($conn, $_POST['storage_temperature']);
    $status = mysqli_real_escape_string($conn, $_POST['status']);
    
    // Cek SKU unique (kecuali untuk produk ini)
    $check_sql = "SELECT id FROM products WHERE sku = '$sku' AND id != $product_id";
    $check_result = mysqli_query($conn, $check_sql);
    
    if(mysqli_num_rows($check_result) > 0) {
        $error = "SKU already exists for another product!";
    } else {
        // Update product
        $sql = "UPDATE products SET
                sku = '$sku',
                name = '$name',
                category_id = $category_id,
                brand_id = $brand_id,
                description = '$description',
                weight = $weight,
                dimensions = '$dimensions',
                unit_price = $unit_price,
                min_stock = $min_stock,
                max_stock = $max_stock,
                weight_volume = '$weight_volume',
                halal_certified = $halal_certified,
                bpom_required = $bpom_required,
                storage_temperature = '$storage_temperature',
                status = '$status',
                updated_at = NOW()
                WHERE id = $product_id";
        
        if(mysqli_query($conn, $sql)) {
            $success = true;
            
            // Log activity
            $log_sql = "INSERT INTO audit_logs (user_id, action, table_name, record_id) 
                       VALUES (" . $_SESSION['user_id'] . ", 'UPDATE', 'products', $product_id)";
            mysqli_query($conn, $log_sql);
        } else {
            $error = "Error: " . mysqli_error($conn);
        }
    }
}

// Get categories
$cats_sql = "SELECT id, name FROM categories WHERE status = 'active' ORDER BY name";
$cats_result = mysqli_query($conn, $cats_sql);

// Get brands
$brands_sql = "SELECT id, name FROM brands WHERE status = 'active' ORDER BY name";
$brands_result = mysqli_query($conn, $brands_sql);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cosmetics WMS - Edit Product</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <style>
        body { background: #f8f9fa; }
        .sidebar {
            background: linear-gradient(180deg, #2c3e50 0%, #1a252f 100%);
            color: white;
            min-height: 100vh;
            width: 250px;
            position: fixed;
            left: 0;
            top: 0;
            overflow-y: auto;
        }
        .main-content {
            margin-left: 250px;
            padding: 20px;
            min-height: 100vh;
            background: #f8f9fa;
        }
        .top-navbar {
            background: white;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            padding: 15px 20px;
            margin: -20px -20px 20px -20px;
            border-radius: 0;
        }
        .form-container {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        .product-header {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-header p-4">
                <h4><i class="fas fa-palette"></i> Cosmetics WMS</h4>
                <small class="text-muted">Warehouse System</small>
            </div>
            
            <ul class="sidebar-menu">
                <li>
                    <a href="<?php echo ROOT_PATH; ?>index.php">
                        <i class="fas fa-tachometer-alt me-2"></i> Dashboard
                    </a>
                </li>
                <li class="active">
                    <a href="index.php">
                        <i class="fas fa-cubes me-2"></i> Products
                    </a>
                </li>
                <li>
                    <a href="../batch/">
                        <i class="fas fa-boxes me-2"></i> Batch Management
                    </a>
                </li>
                <li>
                    <a href="<?php echo ROOT_PATH; ?>logout.php">
                        <i class="fas fa-sign-out-alt me-2"></i> Logout
                    </a>
                </li>
            </ul>
        </div>
        
        <!-- Main Content -->
        <div class="main-content">
            <!-- Top Navbar -->
            <div class="top-navbar">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h4 class="mb-0">Edit Product</h4>
                        <small class="text-muted">Update product information</small>
                    </div>
                    <div>
                        <span class="badge bg-primary"><?php echo $_SESSION['username']; ?></span>
                    </div>
                </div>
            </div>
            
            <div class="row">
                <div class="col-lg-8">
                    <div class="form-container">
                        <div class="mb-4">
                            <a href="index.php" class="btn btn-secondary mb-3">
                                <i class="fas fa-arrow-left"></i> Back to Products
                            </a>
                            <h4><i class="fas fa-edit"></i> Edit Product</h4>
                        </div>
                        
                        <?php if($success): ?>
                        <div class="alert alert-success alert-dismissible fade show">
                            <i class="fas fa-check-circle"></i> Product updated successfully!
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                        <?php endif; ?>
                        
                        <?php if($error): ?>
                        <div class="alert alert-danger alert-dismissible fade show">
                            <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                        <?php endif; ?>
                        
                        <!-- Product Header -->
                        <div class="product-header">
                            <div class="row">
                                <div class="col-md-8">
                                    <h5><?php echo $product['sku']; ?> - <?php echo $product['name']; ?></h5>
                                    <p class="text-muted mb-0">Last updated: <?php echo $product['updated_at']; ?></p>
                                </div>
                                <div class="col-md-4 text-end">
                                    <span class="badge bg-<?php echo $product['status'] == 'active' ? 'success' : 'danger'; ?>">
                                        <?php echo ucfirst($product['status']); ?>
                                    </span>
                                    <?php if($product['halal_certified']): ?>
                                    <span class="badge bg-info">Halal</span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        
                        <form method="POST" action="">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">SKU</label>
                                        <input type="text" name="sku" class="form-control" 
                                               value="<?php echo htmlspecialchars($product['sku']); ?>" required>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label class="form-label">Product Name</label>
                                        <input type="text" name="name" class="form-control" 
                                               value="<?php echo htmlspecialchars($product['name']); ?>" required>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label class="form-label">Category</label>
                                        <select name="category_id" class="form-select" required>
                                            <option value="">Select Category</option>
                                            <?php 
                                            mysqli_data_seek($cats_result, 0);
                                            while($cat = mysqli_fetch_assoc($cats_result)): 
                                            ?>
                                            <option value="<?php echo $cat['id']; ?>"
                                                <?php echo $product['category_id'] == $cat['id'] ? 'selected' : ''; ?>>
                                                <?php echo $cat['name']; ?>
                                            </option>
                                            <?php endwhile; ?>
                                        </select>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label class="form-label">Brand</label>
                                        <select name="brand_id" class="form-select" required>
                                            <option value="">Select Brand</option>
                                            <?php 
                                            mysqli_data_seek($brands_result, 0);
                                            while($brand = mysqli_fetch_assoc($brands_result)): 
                                            ?>
                                            <option value="<?php echo $brand['id']; ?>"
                                                <?php echo $product['brand_id'] == $brand['id'] ? 'selected' : ''; ?>>
                                                <?php echo $brand['name']; ?>
                                            </option>
                                            <?php endwhile; ?>
                                        </select>
                                    </div>
                                </div>
                                
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">Unit Price (Rp)</label>
                                        <input type="number" name="unit_price" class="form-control" 
                                               value="<?php echo $product['unit_price']; ?>" required>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label class="form-label">Weight/Volume</label>
                                        <input type="text" name="weight_volume" class="form-control" 
                                               value="<?php echo htmlspecialchars($product['weight_volume']); ?>">
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label class="form-label">Storage Temperature</label>
                                        <select name="storage_temperature" class="form-select">
                                            <option value="room_temp" <?php echo $product['storage_temperature'] == 'room_temp' ? 'selected' : ''; ?>>Room Temperature</option>
                                            <option value="cool" <?php echo $product['storage_temperature'] == 'cool' ? 'selected' : ''; ?>>Cool (10-15°C)</option>
                                            <option value="cold" <?php echo $product['storage_temperature'] == 'cold' ? 'selected' : ''; ?>>Cold (2-8°C)</option>
                                            <option value="freezer" <?php echo $product['storage_temperature'] == 'freezer' ? 'selected' : ''; ?>>Freezer (-20°C)</option>
                                        </select>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label class="form-label">Status</label>
                                        <select name="status" class="form-select">
                                            <option value="active" <?php echo $product['status'] == 'active' ? 'selected' : ''; ?>>Active</option>
                                            <option value="inactive" <?php echo $product['status'] == 'inactive' ? 'selected' : ''; ?>>Inactive</option>
                                            <option value="discontinued" <?php echo $product['status'] == 'discontinued' ? 'selected' : ''; ?>>Discontinued</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Description</label>
                                <textarea name="description" class="form-control" rows="3"><?php echo htmlspecialchars($product['description']); ?></textarea>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="mb-3">
                                        <label class="form-label">Minimum Stock</label>
                                        <input type="number" name="min_stock" class="form-control" 
                                               value="<?php echo $product['min_stock']; ?>" required>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="mb-3">
                                        <label class="form-label">Maximum Stock</label>
                                        <input type="number" name="max_stock" class="form-control" 
                                               value="<?php echo $product['max_stock']; ?>" required>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="mb-3">
                                        <label class="form-label">Weight (g)</label>
                                        <input type="number" step="0.01" name="weight" class="form-control" 
                                               value="<?php echo $product['weight']; ?>">
                                    </div>
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Dimensions</label>
                                <input type="text" name="dimensions" class="form-control" 
                                       value="<?php echo htmlspecialchars($product['dimensions']); ?>">
                            </div>
                            
                            <div class="mb-3 form-check">
                                <input type="checkbox" name="halal_certified" class="form-check-input" 
                                       id="halalCheck" <?php echo $product['halal_certified'] ? 'checked' : ''; ?>>
                                <label class="form-check-label" for="halalCheck">Halal Certified</label>
                            </div>
                            
                            <div class="mb-3 form-check">
                                <input type="checkbox" name="bpom_required" class="form-check-input" 
                                       id="bpomCheck" <?php echo $product['bpom_required'] ? 'checked' : ''; ?>>
                                <label class="form-check-label" for="bpomCheck">BPOM Required</label>
                            </div>
                            
                            <div class="row mt-4">
                                <div class="col-12">
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fas fa-save"></i> Update Product
                                    </button>
                                    <a href="view.php?id=<?php echo $product_id; ?>" class="btn btn-info">
                                        <i class="fas fa-eye"></i> View
                                    </a>
                                    <a href="index.php" class="btn btn-outline-danger">Cancel</a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                
                <div class="col-lg-4">
                    <div class="card">
                        <div class="card-header bg-warning">
                            <h5 class="mb-0"><i class="fas fa-exclamation-triangle"></i> Warning</h5>
                        </div>
                        <div class="card-body">
                            <p>Changing product details may affect:</p>
                            <ul>
                                <li>Existing batches</li>
                                <li>Stock calculations</li>
                                <li>Order processing</li>
                                <li>Reporting data</li>
                            </ul>
                            <p class="mb-0"><strong>Note:</strong> Changing SKU is not recommended if product already has batches.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>