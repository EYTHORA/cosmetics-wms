<?php
// modules/products/index.php
define('ROOT_PATH', dirname(dirname(dirname(__FILE__))) . '/');
require_once ROOT_PATH . 'includes/config.php';
require_once ROOT_PATH . 'includes/auth.php';
checkLogin();

$page_title = "Product Management";

// Filter parameters
$category = isset($_GET['category']) ? intval($_GET['category']) : '';
$brand = isset($_GET['brand']) ? intval($_GET['brand']) : '';
$status = isset($_GET['status']) ? $_GET['status'] : 'active';
$search = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : '';

// Build WHERE clause
$where = "1=1";
if($status != 'all') {
    $where .= " AND p.status = '$status'";
}
if($category) {
    $where .= " AND p.category_id = $category";
}
if($brand) {
    $where .= " AND p.brand_id = $brand";
}
if($search) {
    $where .= " AND (p.sku LIKE '%$search%' OR p.name LIKE '%$search%')";
}

// Get products with join
$sql = "SELECT p.*, 
               c.name as category_name,
               b.name as brand_name,
               (SELECT SUM(pb.current_quantity) 
                FROM product_batches pb 
                WHERE pb.product_id = p.id AND pb.status = 'released') as total_stock
        FROM products p
        LEFT JOIN categories c ON p.category_id = c.id
        LEFT JOIN brands b ON p.brand_id = b.id
        WHERE $where
        ORDER BY p.name ASC";

$result = mysqli_query($conn, $sql);

// Get categories for filter
$cats_sql = "SELECT id, name FROM categories ORDER BY name";
$cats_result = mysqli_query($conn, $cats_sql);

// Get brands for filter
$brands_sql = "SELECT id, name FROM brands ORDER BY name";
$brands_result = mysqli_query($conn, $brands_sql);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cosmetics WMS - Product Management</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">
    
    <style>
        body { background: #f8f9fa; }
        .sidebar {
            background: linear-gradient(180deg, #2c3e50 0%, #1a252f 100%);
            color: white;
            min-height: 100vh;
            width: 250px;
            position: fixed;
            left: 0;
            top: 0;
            overflow-y: auto;
        }
        .main-content {
            margin-left: 250px;
            padding: 20px;
            min-height: 100vh;
            background: #f8f9fa;
        }
        .top-navbar {
            background: white;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            padding: 15px 20px;
            margin: -20px -20px 20px -20px;
            border-radius: 0;
        }
        .sidebar-menu {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        .sidebar-menu li a {
            color: #bdc3c7;
            padding: 12px 20px;
            display: block;
            text-decoration: none;
            border-left: 4px solid transparent;
        }
        .sidebar-menu li a:hover,
        .sidebar-menu li.active a {
            background: rgba(255,255,255,0.05);
            color: white;
            border-left-color: #3498db;
        }
        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 20px;
        }
        .product-card {
            transition: transform 0.2s;
            border: 1px solid #e9ecef;
        }
        .product-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        .badge-stock {
            font-size: 12px;
            padding: 5px 10px;
            border-radius: 10px;
        }
        .stock-low { background: #ffc107; color: #212529; }
        .stock-normal { background: #28a745; color: white; }
        .stock-over { background: #6c757d; color: white; }
        .status-active { color: #28a745; }
        .status-inactive { color: #dc3545; }
        .halal-badge { background: #20c997; color: white; }
    </style>
</head>
<body>
    <div class="wrapper">
        <!-- Sidebar -->
        <?php include ROOT_PATH . 'includes/sidebar.php'; ?>
        
        <!-- Main Content -->
        <div class="main-content">
            <!-- Top Navbar -->
            <div class="top-navbar">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h4 class="mb-0">Product Management</h4>
                        <small class="text-muted">Manage cosmetic products</small>
                    </div>
                    <div>
                        <span class="badge bg-primary"><?php echo $_SESSION['username']; ?></span>
                    </div>
                </div>
            </div>
            
            <!-- Stats Cards -->
            <div class="row mb-4">
                <div class="col-md-3">
                    <div class="card bg-primary text-white">
                        <div class="card-body">
                            <h6>Total Products</h6>
                            <?php
                            $total_sql = "SELECT COUNT(*) as total FROM products";
                            $total_result = mysqli_query($conn, $total_sql);
                            $total = mysqli_fetch_assoc($total_result)['total'];
                            ?>
                            <h2><?php echo $total; ?></h2>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-3">
                    <div class="card bg-success text-white">
                        <div class="card-body">
                            <h6>Active Products</h6>
                            <?php
                            $active_sql = "SELECT COUNT(*) as total FROM products WHERE status = 'active'";
                            $active_result = mysqli_query($conn, $active_sql);
                            $active = mysqli_fetch_assoc($active_result)['total'];
                            ?>
                            <h2><?php echo $active; ?></h2>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-3">
                    <div class="card bg-warning text-white">
                        <div class="card-body">
                            <h6>Low Stock</h6>
                            <?php
                            $low_sql = "SELECT COUNT(DISTINCT p.id) as total 
                                       FROM products p 
                                       JOIN product_batches pb ON p.id = pb.product_id 
                                       WHERE pb.current_quantity <= p.min_stock 
                                       AND pb.status = 'released'";
                            $low_result = mysqli_query($conn, $low_sql);
                            $low = mysqli_fetch_assoc($low_result)['total'];
                            ?>
                            <h2><?php echo $low; ?></h2>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-3">
                    <div class="card bg-info text-white">
                        <div class="card-body">
                            <h6>Halal Certified</h6>
                            <?php
                            $halal_sql = "SELECT COUNT(*) as total FROM products WHERE halal_certified = 1";
                            $halal_result = mysqli_query($conn, $halal_sql);
                            $halal = mysqli_fetch_assoc($halal_result)['total'];
                            ?>
                            <h2><?php echo $halal; ?></h2>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Filter & Search -->
            <div class="card mb-4">
                <div class="card-body">
                    <form method="GET" class="row g-3">
                        <div class="col-md-3">
                            <label>Search</label>
                            <input type="text" name="search" class="form-control" placeholder="SKU or Product Name" 
                                   value="<?php echo htmlspecialchars($search); ?>">
                        </div>
                        
                        <div class="col-md-2">
                            <label>Status</label>
                            <select name="status" class="form-select">
                                <option value="all" <?php echo $status == 'all' ? 'selected' : ''; ?>>All Status</option>
                                <option value="active" <?php echo $status == 'active' ? 'selected' : ''; ?>>Active</option>
                                <option value="inactive" <?php echo $status == 'inactive' ? 'selected' : ''; ?>>Inactive</option>
                            </select>
                        </div>
                        
                        <div class="col-md-3">
                            <label>Category</label>
                            <select name="category" class="form-select">
                                <option value="">All Categories</option>
                                <?php while($cat = mysqli_fetch_assoc($cats_result)): ?>
                                <option value="<?php echo $cat['id']; ?>" 
                                    <?php echo $category == $cat['id'] ? 'selected' : ''; ?>>
                                    <?php echo $cat['name']; ?>
                                </option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        
                        <div class="col-md-2">
                            <label>Brand</label>
                            <select name="brand" class="form-select">
                                <option value="">All Brands</option>
                                <?php while($brand_row = mysqli_fetch_assoc($brands_result)): ?>
                                <option value="<?php echo $brand_row['id']; ?>" 
                                    <?php echo $brand == $brand_row['id'] ? 'selected' : ''; ?>>
                                    <?php echo $brand_row['name']; ?>
                                </option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        
                        <div class="col-md-2 d-flex align-items-end">
                            <button type="submit" class="btn btn-primary w-100">
                                <i class="fas fa-search"></i> Filter
                            </button>
                        </div>
                    </form>
                </div>
            </div>
            
            <!-- Action Buttons -->
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h5 class="mb-0">Product List</h5>
                <div>
                    <a href="add.php" class="btn btn-primary">
                        <i class="fas fa-plus-circle"></i> Add New Product
                    </a>
                    <button class="btn btn-outline-secondary" onclick="window.print()">
                        <i class="fas fa-print"></i> Print
                    </button>
                </div>
            </div>
            
            <!-- Products Table -->
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover" id="productsTable">
                            <thead class="table-light">
                                <tr>
                                    <th>SKU</th>
                                    <th>Product Name</th>
                                    <th>Category</th>
                                    <th>Brand</th>
                                    <th>Price</th>
                                    <th>Stock</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while($product = mysqli_fetch_assoc($result)): 
                                    $stock = $product['total_stock'] ?? 0;
                                    $min_stock = $product['min_stock'] ?? 0;
                                    $max_stock = $product['max_stock'] ?? 0;
                                    
                                    // Tentukan status stock
                                    if($stock <= $min_stock) {
                                        $stock_class = 'stock-low';
                                        $stock_text = 'Low';
                                    } elseif($stock >= $max_stock) {
                                        $stock_class = 'stock-over';
                                        $stock_text = 'Over';
                                    } else {
                                        $stock_class = 'stock-normal';
                                        $stock_text = 'Normal';
                                    }
                                ?>
                                <tr>
                                    <td>
                                        <strong><?php echo $product['sku']; ?></strong>
                                        <?php if($product['halal_certified']): ?>
                                        <br><span class="badge halal-badge">Halal</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php echo $product['name']; ?>
                                        <br>
                                        <small class="text-muted"><?php echo $product['weight_volume']; ?></small>
                                    </td>
                                    <td><?php echo $product['category_name']; ?></td>
                                    <td><?php echo $product['brand_name']; ?></td>
                                    <td>
                                        Rp <?php echo number_format($product['unit_price'], 0, ',', '.'); ?>
                                    </td>
                                    <td>
                                        <span class="badge badge-stock <?php echo $stock_class; ?>">
                                            <?php echo $stock; ?> <?php echo $stock_text; ?>
                                        </span>
                                        <br>
                                        <small class="text-muted">
                                            Min: <?php echo $min_stock; ?> | 
                                            Max: <?php echo $max_stock; ?>
                                        </small>
                                    </td>
                                    <td>
                                        <?php if($product['status'] == 'active'): ?>
                                        <span class="status-active">
                                            <i class="fas fa-check-circle"></i> Active
                                        </span>
                                        <?php else: ?>
                                        <span class="status-inactive">
                                            <i class="fas fa-times-circle"></i> Inactive
                                        </span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="btn-group btn-group-sm">
                                            <a href="view.php?id=<?php echo $product['id']; ?>" 
                                               class="btn btn-info" title="View">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                            <a href="edit.php?id=<?php echo $product['id']; ?>" 
                                               class="btn btn-warning" title="Edit">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <a href="../batch/add.php?product_id=<?php echo $product['id']; ?>" 
                                               class="btn btn-success" title="Add Batch">
                                                <i class="fas fa-box"></i>
                                            </a>
                                            <?php if($product['status'] == 'active'): ?>
                                            <a href="delete.php?id=<?php echo $product['id']; ?>" 
                                               class="btn btn-danger" title="Disable"
                                               onclick="return confirm('Disable this product?')">
                                                <i class="fas fa-ban"></i>
                                            </a>
                                            <?php else: ?>
                                            <a href="activate.php?id=<?php echo $product['id']; ?>" 
                                               class="btn btn-success" title="Activate">
                                                <i class="fas fa-check"></i>
                                            </a>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
    
    <script>
    $(document).ready(function() {
        $('#productsTable').DataTable({
            pageLength: 25,
            lengthMenu: [[10, 25, 50, 100, -1], [10, 25, 50, 100, "All"]],
            language: {
                search: "Search products:",
                lengthMenu: "Show _MENU_ entries",
                info: "Showing _START_ to _END_ of _TOTAL_ products",
                paginate: {
                    first: "First",
                    last: "Last",
                    next: "Next",
                    previous: "Previous"
                }
            },
            order: [[0, 'asc']]
        });
        
        // Auto-generate SKU
        $('#generateSku').click(function() {
            var category = $('#categorySelect').val();
            var brand = $('#brandSelect').val();
            
            if(category && brand) {
                // Generate simple SKU
                var timestamp = new Date().getTime();
                var sku = 'COSM-' + category + '-' + brand + '-' + (timestamp % 10000);
                $('#skuInput').val(sku);
            }
        });
    });
    </script>
</body>
</html>