<?php
// modules/products/view.php
define('ROOT_PATH', dirname(dirname(dirname(__FILE__))) . '/');
require_once ROOT_PATH . 'includes/config.php';
require_once ROOT_PATH . 'includes/auth.php';
checkLogin();

$page_title = "Product Details";

// Get product ID
$product_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if(!$product_id) {
    header("Location: index.php");
    exit();
}

// Get product details with joins
$sql = "SELECT p.*, 
               c.name as category_name,
               b.name as brand_name,
               (SELECT SUM(pb.current_quantity) 
                FROM product_batches pb 
                WHERE pb.product_id = p.id AND pb.status = 'released') as total_stock
        FROM products p
        LEFT JOIN categories c ON p.category_id = c.id
        LEFT JOIN brands b ON p.brand_id = b.id
        WHERE p.id = $product_id";

$result = mysqli_query($conn, $sql);

if(mysqli_num_rows($result) == 0) {
    header("Location: index.php");
    exit();
}

$product = mysqli_fetch_assoc($result); // ✅ PERBAIKAN DI SINI!

// Get related batches
$batches_sql = "SELECT pb.*, 
                       DATEDIFF(pb.expiry_date, CURDATE()) as days_remaining
                FROM product_batches pb
                WHERE pb.product_id = $product_id
                ORDER BY pb.expiry_date ASC
                LIMIT 10";

$batches_result = mysqli_query($conn, $batches_sql);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cosmetics WMS - Product Details</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <style>
        body { background: #f8f9fa; }
        .sidebar {
            background: linear-gradient(180deg, #2c3e50 0%, #1a252f 100%);
            color: white;
            min-height: 100vh;
            width: 250px;
            position: fixed;
            left: 0;
            top: 0;
            overflow-y: auto;
        }
        .main-content {
            margin-left: 250px;
            padding: 20px;
            min-height: 100vh;
            background: #f8f9fa;
        }
        .top-navbar {
            background: white;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            padding: 15px 20px;
            margin: -20px -20px 20px -20px;
            border-radius: 0;
        }
        .product-header {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 20px;
        }
        .info-card {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 20px;
        }
        .badge-halal { background: #20c997; color: white; }
        .badge-bpom { background: #17a2b8; color: white; }
        .info-table td { padding: 8px 0; border-bottom: 1px solid #f0f0f0; }
        .info-table tr:last-child td { border-bottom: none; }
    </style>
</head>
<body>
    <div class="wrapper">
        <!-- Sidebar -->
       <?php include ROOT_PATH . 'includes/sidebar.php'; ?>
        
        <!-- Main Content -->
        <div class="main-content">
            <!-- Top Navbar -->
            <div class="top-navbar">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h4 class="mb-0">Product Details</h4>
                        <small class="text-muted">View product information</small>
                    </div>
                    <div>
                        <span class="badge bg-primary"><?php echo $_SESSION['username']; ?></span>
                    </div>
                </div>
            </div>
            
            <!-- Product Header -->
            <div class="product-header">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <h2><?php echo htmlspecialchars($product['name']); ?></h2>
                        <h4 class="text-muted"><?php echo htmlspecialchars($product['sku']); ?></h4>
                        <div class="mt-2">
                            <?php if($product['status'] == 'active'): ?>
                            <span class="badge bg-success">Active</span>
                            <?php else: ?>
                            <span class="badge bg-danger">Inactive</span>
                            <?php endif; ?>
                            
                            <?php if($product['halal_certified']): ?>
                            <span class="badge badge-halal">Halal Certified</span>
                            <?php endif; ?>
                            
                            <?php if($product['bpom_required']): ?>
                            <span class="badge badge-bpom">BPOM Required</span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-md-4 text-end">
                        <div class="btn-group">
                            <a href="edit.php?id=<?php echo $product_id; ?>" class="btn btn-warning">
                                <i class="fas fa-edit"></i> Edit
                            </a>
                            <a href="../batch/add.php?product_id=<?php echo $product_id; ?>" class="btn btn-success">
                                <i class="fas fa-plus"></i> Add Batch
                            </a>
                            <a href="index.php" class="btn btn-secondary">
                                <i class="fas fa-list"></i> Back to List
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="row">
                <!-- Left Column: Product Info -->
                <div class="col-md-6">
                    <div class="info-card">
                        <h5><i class="fas fa-info-circle"></i> Basic Information</h5>
                        <table class="table info-table">
                            <tr>
                                <td width="40%"><strong>Category</strong></td>
                                <td><?php echo htmlspecialchars($product['category_name'] ?? 'N/A'); ?></td>
                            </tr>
                            <tr>
                                <td><strong>Brand</strong></td>
                                <td><?php echo htmlspecialchars($product['brand_name'] ?? 'N/A'); ?></td>
                            </tr>
                            <tr>
                                <td><strong>Description</strong></td>
                                <td><?php echo nl2br(htmlspecialchars($product['description'] ?? 'No description')); ?></td>
                            </tr>
                            <tr>
                                <td><strong>Created</strong></td>
                                <td><?php echo $product['created_at']; ?></td>
                            </tr>
                            <tr>
                                <td><strong>Last Updated</strong></td>
                                <td><?php echo $product['updated_at']; ?></td>
                            </tr>
                        </table>
                    </div>
                    
                    <div class="info-card">
                        <h5><i class="fas fa-box"></i> Stock Information</h5>
                        <table class="table info-table">
                            <tr>
                                <td width="40%"><strong>Current Stock</strong></td>
                                <td>
                                    <?php 
                                    $stock = $product['total_stock'] ?? 0;
                                    $min = $product['min_stock'] ?? 0;
                                    $max = $product['max_stock'] ?? 0;
                                    
                                    if($stock <= $min) {
                                        $stock_class = 'warning';
                                        $stock_text = 'Low Stock';
                                    } elseif($stock >= $max) {
                                        $stock_class = 'info';
                                        $stock_text = 'Over Stock';
                                    } else {
                                        $stock_class = 'success';
                                        $stock_text = 'Normal';
                                    }
                                    ?>
                                    <span class="badge bg-<?php echo $stock_class; ?>">
                                        <?php echo $stock; ?> units - <?php echo $stock_text; ?>
                                    </span>
                                </td>
                            </tr>
                            <tr>
                                <td><strong>Minimum Stock</strong></td>
                                <td><?php echo $min; ?> units</td>
                            </tr>
                            <tr>
                                <td><strong>Maximum Stock</strong></td>
                                <td><?php echo $max; ?> units</td>
                            </tr>
                            <tr>
                                <td><strong>Reorder Point</strong></td>
                                <td><?php echo $min + 5; ?> units</td>
                            </tr>
                        </table>
                    </div>
                </div>
                
                <!-- Right Column: Product Details -->
                <div class="col-md-6">
                    <div class="info-card">
                        <h5><i class="fas fa-cube"></i> Product Details</h5>
                        <table class="table info-table">
                            <tr>
                                <td width="40%"><strong>Unit Price</strong></td>
                                <td>Rp <?php echo number_format($product['unit_price'], 0, ',', '.'); ?></td>
                            </tr>
                            <tr>
                                <td><strong>Weight/Volume</strong></td>
                                <td><?php echo htmlspecialchars($product['weight_volume'] ?? 'N/A'); ?></td>
                            </tr>
                            <tr>
                                <td><strong>Weight</strong></td>
                                <td><?php echo $product['weight'] ?? '0'; ?> grams</td>
                            </tr>
                            <tr>
                                <td><strong>Dimensions</strong></td>
                                <td><?php echo htmlspecialchars($product['dimensions'] ?? 'N/A'); ?></td>
                            </tr>
                            <tr>
                                <td><strong>Storage Temperature</strong></td>
                                <td>
                                    <?php 
                                    $temp_map = [
                                        'room_temp' => 'Room Temperature',
                                        'cool' => 'Cool (10-15°C)',
                                        'cold' => 'Cold (2-8°C)',
                                        'freezer' => 'Freezer (-20°C)'
                                    ];
                                    $storage_temp = $product['storage_temperature'] ?? 'room_temp';
                                    echo $temp_map[$storage_temp] ?? $storage_temp;
                                    ?>
                                </td>
                            </tr>
                        </table>
                    </div>
                    
                    <div class="info-card">
                        <h5><i class="fas fa-clipboard-list"></i> Recent Batches</h5>
                        <?php if(mysqli_num_rows($batches_result) > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-sm">
                                <thead>
                                    <tr>
                                        <th>Batch No</th>
                                        <th>Expiry</th>
                                        <th>Days Left</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while($batch = mysqli_fetch_assoc($batches_result)): 
                                        $days = $batch['days_remaining'] ?? 0;
                                        $status = $batch['status'] ?? 'unknown';
                                        
                                        if($status == 'expired' || $days < 0) {
                                            $status_class = 'danger';
                                            $status_text = 'Expired';
                                        } elseif($status == 'quarantine') {
                                            $status_class = 'warning';
                                            $status_text = 'Quarantine';
                                        } elseif($days <= 30) {
                                            $status_class = 'danger';
                                            $status_text = 'Critical';
                                        } elseif($days <= 90) {
                                            $status_class = 'warning';
                                            $status_text = 'Warning';
                                        } else {
                                            $status_class = 'success';
                                            $status_text = 'Good';
                                        }
                                    ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($batch['batch_number']); ?></td>
                                        <td><?php echo date('d/m/Y', strtotime($batch['expiry_date'])); ?></td>
                                        <td>
                                            <span class="badge bg-<?php echo $status_class; ?>">
                                                <?php echo $days > 0 ? $days . ' days' : 'EXPIRED'; ?>
                                            </span>
                                        </td>
                                        <td>
                                            <span class="badge bg-<?php echo $status_class; ?>">
                                                <?php echo $status_text; ?>
                                            </span>
                                        </td>
                                    </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                        <a href="../batch/?product_id=<?php echo $product_id; ?>" class="btn btn-sm btn-outline-primary">
                            View All Batches
                        </a>
                        <?php else: ?>
                        <div class="alert alert-info">
                            No batches found for this product.
                        </div>
                        <a href="../batch/add.php?product_id=<?php echo $product_id; ?>" class="btn btn-sm btn-success">
                            <i class="fas fa-plus"></i> Add First Batch
                        </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <!-- Quick Actions -->
            <div class="info-card">
                <h5><i class="fas fa-bolt"></i> Quick Actions</h5>
                <div class="row">
                    <div class="col-md-3">
                        <a href="edit.php?id=<?php echo $product_id; ?>" class="btn btn-warning w-100 mb-2">
                            <i class="fas fa-edit"></i> Edit Product
                        </a>
                    </div>
                    <div class="col-md-3">
                        <a href="../batch/add.php?product_id=<?php echo $product_id; ?>" class="btn btn-success w-100 mb-2">
                            <i class="fas fa-plus"></i> Add Batch
                        </a>
                    </div>
                    <div class="col-md-3">
                        <a href="#" class="btn btn-info w-100 mb-2">
                            <i class="fas fa-chart-bar"></i> View Reports
                        </a>
                    </div>
                    <div class="col-md-3">
                        <?php if($product['status'] == 'active'): ?>
                        <a href="delete.php?id=<?php echo $product_id; ?>" class="btn btn-danger w-100 mb-2"
                           onclick="return confirm('Disable this product?')">
                            <i class="fas fa-ban"></i> Disivate
                        </a>
                        <?php else: ?>
                        <a href="activate.php?id=<?php echo $product_id; ?>" class="btn btn-success w-100 mb-2">
                            <i class="fas fa-check"></i> Activate
                        </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>