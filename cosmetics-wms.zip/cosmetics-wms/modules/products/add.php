<?php
// modules/products/add.php
define('ROOT_PATH', dirname(dirname(dirname(__FILE__))) . '/');
require_once ROOT_PATH . 'includes/config.php';
require_once ROOT_PATH . 'includes/auth.php';
checkLogin();

$page_title = "Add New Product";
$success = false;
$error = '';

// Handle form submission
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $sku = mysqli_real_escape_string($conn, $_POST['sku']);
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $category_id = intval($_POST['category_id']);
    $brand_id = intval($_POST['brand_id']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $weight = floatval($_POST['weight']);
    $dimensions = mysqli_real_escape_string($conn, $_POST['dimensions']);
    $unit_price = floatval($_POST['unit_price']);
    $min_stock = intval($_POST['min_stock']);
    $max_stock = intval($_POST['max_stock']);
    $weight_volume = mysqli_real_escape_string($conn, $_POST['weight_volume']);
    $halal_certified = isset($_POST['halal_certified']) ? 1 : 0;
    $bpom_required = isset($_POST['bpom_required']) ? 1 : 0;
    $storage_temperature = mysqli_real_escape_string($conn, $_POST['storage_temperature']);
    
    // Validasi
    if(empty($sku) || empty($name) || empty($unit_price)) {
        $error = "Please fill required fields!";
    } else {
        // Cek SKU unique
        $check_sql = "SELECT id FROM products WHERE sku = '$sku'";
        $check_result = mysqli_query($conn, $check_sql);
        
        if(mysqli_num_rows($check_result) > 0) {
            $error = "SKU already exists!";
        } else {
            // Insert product
            $sql = "INSERT INTO products 
                   (sku, name, category_id, brand_id, description, weight, dimensions, 
                    unit_price, min_stock, max_stock, weight_volume, halal_certified, 
                    bpom_required, storage_temperature, status) 
                   VALUES 
                   ('$sku', '$name', $category_id, $brand_id, '$description', $weight, 
                    '$dimensions', $unit_price, $min_stock, $max_stock, '$weight_volume', 
                    $halal_certified, $bpom_required, '$storage_temperature', 'active')";
            
            if(mysqli_query($conn, $sql)) {
                $product_id = mysqli_insert_id($conn);
                $success = true;
                
                // Log activity
                $log_sql = "INSERT INTO audit_logs (user_id, action, table_name, record_id) 
                           VALUES (" . $_SESSION['user_id'] . ", 'CREATE', 'products', $product_id)";
                mysqli_query($conn, $log_sql);
            } else {
                $error = "Error: " . mysqli_error($conn);
            }
        }
    }
}

// Get categories
// MENJADI INI
$cats_sql = "SELECT id, name FROM categories ORDER BY name";
$brands_sql = "SELECT id, name FROM brands ORDER BY name";

// Get brands
$brands_sql = "SELECT id, name FROM brands WHERE status = 'active' ORDER BY name";
$brands_result = mysqli_query($conn, $brands_sql);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cosmetics WMS - Add Product</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <style>
        body { background: #f8f9fa; }
        .sidebar {
            background: linear-gradient(180deg, #2c3e50 0%, #1a252f 100%);
            color: white;
            min-height: 100vh;
            width: 250px;
            position: fixed;
            left: 0;
            top: 0;
            overflow-y: auto;
        }
        .main-content {
            margin-left: 250px;
            padding: 20px;
            min-height: 100vh;
            background: #f8f9fa;
        }
        .top-navbar {
            background: white;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            padding: 15px 20px;
            margin: -20px -20px 20px -20px;
            border-radius: 0;
        }
        .sidebar-menu {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        .sidebar-menu li a {
            color: #bdc3c7;
            padding: 12px 20px;
            display: block;
            text-decoration: none;
            border-left: 4px solid transparent;
        }
        .sidebar-menu li a:hover,
        .sidebar-menu li.active a {
            background: rgba(255,255,255,0.05);
            color: white;
            border-left-color: #3498db;
        }
        .form-container {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        .required:after {
            content: " *";
            color: red;
        }
        .form-section {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-header p-4">
                <h4><i class="fas fa-palette"></i> Cosmetics WMS</h4>
                <small class="text-muted">Warehouse System</small>
            </div>
            
            <ul class="sidebar-menu">
                <li>
                    <a href="<?php echo ROOT_PATH; ?>index.php">
                        <i class="fas fa-tachometer-alt me-2"></i> Dashboard
                    </a>
                </li>
                <li class="active">
                    <a href="index.php">
                        <i class="fas fa-cubes me-2"></i> Products
                    </a>
                </li>
                <li>
                    <a href="../batch/">
                        <i class="fas fa-boxes me-2"></i> Batch Management
                    </a>
                </li>
                <li>
                    <a href="#">
                        <i class="fas fa-shopping-cart me-2"></i> Orders
                    </a>
                </li>
                <li>
                    <a href="<?php echo ROOT_PATH; ?>logout.php">
                        <i class="fas fa-sign-out-alt me-2"></i> Logout
                    </a>
                </li>
            </ul>
        </div>
        
        <!-- Main Content -->
        <div class="main-content">
            <!-- Top Navbar -->
            <div class="top-navbar">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h4 class="mb-0">Add New Product</h4>
                        <small class="text-muted">Add cosmetic product to inventory</small>
                    </div>
                    <div>
                        <span class="badge bg-primary"><?php echo $_SESSION['username']; ?></span>
                    </div>
                </div>
            </div>
            
            <div class="row">
                <div class="col-lg-8">
                    <div class="form-container">
                        <div class="mb-4">
                            <a href="index.php" class="btn btn-secondary mb-3">
                                <i class="fas fa-arrow-left"></i> Back to Products
                            </a>
                            <h4><i class="fas fa-plus-circle"></i> Product Information</h4>
                        </div>
                        
                        <?php if($success): ?>
                        <div class="alert alert-success alert-dismissible fade show">
                            <i class="fas fa-check-circle"></i> Product added successfully!
                            <a href="index.php" class="alert-link">View product list</a>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                        <?php endif; ?>
                        
                        <?php if($error): ?>
                        <div class="alert alert-danger alert-dismissible fade show">
                            <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                        <?php endif; ?>
                        
                        <form method="POST" action="" id="productForm">
                            <!-- Basic Information -->
                            <div class="form-section">
                                <h5 class="mb-3">Basic Information</h5>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label class="form-label required">SKU</label>
                                            <input type="text" name="sku" class="form-control" required
                                                   placeholder="e.g., LIP-001">
                                            <small class="text-muted">Unique product identifier</small>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label class="form-label required">Product Name</label>
                                            <input type="text" name="name" class="form-control" required
                                                   placeholder="e.g., Wardah Lip Cream Matte">
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label class="form-label required">Category</label>
                                            <select name="category_id" class="form-select" required>
                                                <option value="">Select Category</option>
                                                <?php while($cat = mysqli_fetch_assoc($cats_result)): ?>
                                                <option value="<?php echo $cat['id']; ?>">
                                                    <?php echo $cat['name']; ?>
                                                </option>
                                                <?php endwhile; ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label class="form-label required">Brand</label>
                                            <select name="brand_id" class="form-select" required>
                                                <option value="">Select Brand</option>
                                                <?php while($brand = mysqli_fetch_assoc($brands_result)): ?>
                                                <option value="<?php echo $brand['id']; ?>">
                                                    <?php echo $brand['name']; ?>
                                                </option>
                                                <?php endwhile; ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="mb-3">
                                    <label class="form-label">Description</label>
                                    <textarea name="description" class="form-control" rows="3"
                                              placeholder="Product description..."></textarea>
                                </div>
                            </div>
                            
                            <!-- Product Details -->
                            <div class="form-section">
                                <h5 class="mb-3">Product Details</h5>
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="mb-3">
                                            <label class="form-label">Weight (g)</label>
                                            <input type="number" step="0.01" name="weight" class="form-control"
                                                   placeholder="e.g., 50.00">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="mb-3">
                                            <label class="form-label">Dimensions</label>
                                            <input type="text" name="dimensions" class="form-control"
                                                   placeholder="e.g., 5x3x10 cm">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="mb-3">
                                            <label class="form-label">Weight/Volume</label>
                                            <input type="text" name="weight_volume" class="form-control"
                                                   placeholder="e.g., 4.5g or 30ml">
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label class="form-label required">Unit Price (Rp)</label>
                                            <input type="number" name="unit_price" class="form-control" required
                                                   min="0" step="100" placeholder="e.g., 75000">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label class="form-label">Storage Temperature</label>
                                            <select name="storage_temperature" class="form-select">
                                                <option value="room_temp">Room Temperature</option>
                                                <option value="cool">Cool (10-15°C)</option>
                                                <option value="cold">Cold (2-8°C)</option>
                                                <option value="freezer">Freezer (-20°C)</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Stock Management -->
                            <div class="form-section">
                                <h5 class="mb-3">Stock Management</h5>
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="mb-3">
                                            <label class="form-label required">Minimum Stock</label>
                                            <input type="number" name="min_stock" class="form-control" required
                                                   min="1" value="10">
                                            <small class="text-muted">Alert when stock below this</small>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="mb-3">
                                            <label class="form-label required">Maximum Stock</label>
                                            <input type="number" name="max_stock" class="form-control" required
                                                   min="1" value="100">
                                            <small class="text-muted">Maximum capacity</small>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="mb-3">
                                            <label class="form-label">Reorder Point</label>
                                            <input type="number" class="form-control" 
                                                   value="15" readonly>
                                            <small class="text-muted">Auto-calculated (min + 5)</small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Certifications -->
                            <div class="form-section">
                                <h5 class="mb-3">Certifications & Requirements</h5>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-check mb-3">
                                            <input type="checkbox" name="halal_certified" 
                                                   class="form-check-input" id="halalCheck">
                                            <label class="form-check-label" for="halalCheck">
                                                Halal Certified (MUI)
                                            </label>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-check mb-3">
                                            <input type="checkbox" name="bpom_required" 
                                                   class="form-check-input" id="bpomCheck" checked>
                                            <label class="form-check-label" for="bpomCheck">
                                                BPOM Required
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Form Actions -->
                            <div class="row mt-4">
                                <div class="col-12">
                                    <button type="submit" class="btn btn-primary btn-lg">
                                        <i class="fas fa-save"></i> Save Product
                                    </button>
                                    <button type="reset" class="btn btn-secondary">Reset</button>
                                    <a href="index.php" class="btn btn-outline-danger">Cancel</a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                
                <!-- Help Section -->
                <div class="col-lg-4">
                    <div class="card mb-3">
                        <div class="card-header bg-info text-white">
                            <h5 class="mb-0"><i class="fas fa-lightbulb"></i> Tips</h5>
                        </div>
                        <div class="card-body">
                            <ul class="mb-0">
                                <li>SKU must be unique</li>
                                <li>Set appropriate min/max stock</li>
                                <li>Check halal certification if applicable</li>
                                <li>Most cosmetics require BPOM registration</li>
                                <li>Proper storage temperature extends shelf life</li>
                            </ul>
                        </div>
                    </div>
                    
                    <div class="card">
                        <div class="card-header bg-warning">
                            <h5 class="mb-0"><i class="fas fa-exclamation-triangle"></i> Important</h5>
                        </div>
                        <div class="card-body">
                            <div class="alert alert-warning">
                                <strong>For Cosmetics:</strong>
                                <ul class="mb-0">
                                    <li>Expiry typically 24-36 months</li>
                                    <li>Store away from direct sunlight</li>
                                    <li>Maintain proper temperature</li>
                                    <li>BPOM number required for sale</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
    $(document).ready(function() {
        // Auto-calculate reorder point
        $('input[name="min_stock"]').on('input', function() {
            var min = parseInt($(this).val()) || 0;
            var reorder = min + 5;
            $(this).closest('.row').find('input[readonly]').val(reorder);
        });
        
        // Auto-generate SKU based on category and brand
        $('select[name="category_id"], select[name="brand_id"]').change(function() {
            var category = $('select[name="category_id"] option:selected').text().substring(0, 3).toUpperCase();
            var brand = $('select[name="brand_id"] option:selected').text().substring(0, 3).toUpperCase();
            
            if(category && brand && category != 'SELECT' && brand != 'SELECT') {
                // Generate timestamp-based suffix
                var timestamp = new Date().getTime();
                var suffix = timestamp.toString().slice(-4);
                
                var sku = category + '-' + brand + '-' + suffix;
                $('input[name="sku"]').val(sku);
            }
        });
        
        // Form validation
        $('#productForm').submit(function(e) {
            var min = parseInt($('input[name="min_stock"]').val());
            var max = parseInt($('input[name="max_stock"]').val());
            
            if(min >= max) {
                e.preventDefault();
                alert('Minimum stock must be less than maximum stock!');
                return false;
            }
            
            return true;
        });
    });
    </script>
</body>
</html>