<?php
// modules/products/delete.php
define('ROOT_PATH', dirname(dirname(dirname(__FILE__))) . '/');
require_once ROOT_PATH . 'includes/config.php';
require_once ROOT_PATH . 'includes/auth.php';
checkLogin();

// Get product ID
$product_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if(!$product_id) {
    header("Location: index.php");
    exit();
}

// Soft delete (update status to inactive)
$sql = "UPDATE products SET status = 'inactive', updated_at = NOW() WHERE id = $product_id";

if(mysqli_query($conn, $sql)) {
    // Log activity
    $log_sql = "INSERT INTO audit_logs (user_id, action, table_name, record_id) 
               VALUES (" . $_SESSION['user_id'] . ", 'DELETE', 'products', $product_id)";
    mysqli_query($conn, $log_sql);
    
    header("Location: index.php?success=deleted");
} else {
    header("Location: index.php?error=delete_failed");
}
exit();
?>