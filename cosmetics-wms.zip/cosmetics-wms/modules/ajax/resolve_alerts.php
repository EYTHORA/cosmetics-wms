<?php
// modules/ajax/resolve_alerts.php
$root_path = dirname(dirname(dirname(__FILE__))) . '/';
require_once $root_path . 'includes/config.php';
require_once $root_path . 'includes/auth.php';
checkLogin();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

$batch_id = isset($_POST['batch_id']) ? (int)$_POST['batch_id'] : 0;
$action = isset($_POST['action']) ? $_POST['action'] : '';

if ($batch_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid batch ID']);
    exit;
}

if ($action === 'resolve') {
    // Mark all alerts for this batch as resolved
    $sql = "UPDATE expiry_alerts 
            SET is_resolved = TRUE, 
                resolved_by = " . $_SESSION['user_id'] . ",
                resolved_at = NOW()
            WHERE batch_id = $batch_id 
            AND is_resolved = FALSE";
    
    if (mysqli_query($conn, $sql)) {
        echo json_encode(['success' => true, 'message' => 'Alerts resolved successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Database error: ' . mysqli_error($conn)]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid action']);
}
?>