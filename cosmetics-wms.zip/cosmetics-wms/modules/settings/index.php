<?php
// modules/settings/index.php
$root_path = dirname(dirname(dirname(__FILE__))) . '/';
require_once $root_path . 'includes/config.php';
require_once $root_path . 'includes/auth.php';
checkLogin();

$active_menu = 'settings';
$page_title = "System Settings";
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cosmetics WMS - Settings</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <?php include $root_path . 'includes/sidebar.php'; ?>
    
    <div class="main-content" style="margin-left: 250px; padding: 25px;">
        <!-- HEADER -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h3 class="mb-1">⚙️ System Settings</h3>
                <p class="text-muted mb-0">Configure your warehouse management system</p>
            </div>
            <div>
                <button class="btn btn-success">
                    <i class="fas fa-save"></i> Save All Changes
                </button>
            </div>
        </div>
        
        <!-- SETTINGS TABS -->
        <div class="card">
            <div class="card-header">
                <ul class="nav nav-tabs card-header-tabs" id="settingsTab">
                    <li class="nav-item">
                        <a class="nav-link active" data-bs-toggle="tab" href="#general">General</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" data-bs-toggle="tab" href="#users">Users</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" data-bs-toggle="tab" href="#notifications">Notifications</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" data-bs-toggle="tab" href="#backup">Backup</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" data-bs-toggle="tab" href="#system">System</a>
                    </li>
                </ul>
            </div>
            
            <div class="card-body">
                <div class="tab-content">
                    <!-- GENERAL SETTINGS -->
                    <div class="tab-pane fade show active" id="general">
                        <h5 class="mb-4">General Settings</h5>
                        <form>
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label class="form-label">Warehouse Name</label>
                                    <input type="text" class="form-control" value="Cosmetics Main Warehouse">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Contact Email</label>
                                    <input type="email" class="form-control" value="admin@cosmeticswms.com">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Phone Number</label>
                                    <input type="text" class="form-control" value="+62 812-3456-7890">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Address</label>
                                    <input type="text" class="form-control" value="Jl. Sudirman No. 123, Jakarta">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Default Currency</label>
                                    <select class="form-select">
                                        <option selected>IDR - Indonesian Rupiah</option>
                                        <option>USD - US Dollar</option>
                                        <option>EUR - Euro</option>
                                    </select>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Time Zone</label>
                                    <select class="form-select">
                                        <option selected>Asia/Jakarta (WIB)</option>
                                        <option>Asia/Makassar (WITA)</option>
                                        <option>Asia/Jayapura (WIT)</option>
                                    </select>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Expiry Alert Days</label>
                                    <input type="number" class="form-control" value="30" min="1" max="180">
                                    <small class="text-muted">Alert before expiry (days)</small>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Low Stock Threshold</label>
                                    <input type="number" class="form-control" value="20" min="1" max="100">
                                    <small class="text-muted">Percentage of minimum stock</small>
                                </div>
                                <div class="col-12">
                                    <button type="submit" class="btn btn-primary">Save General Settings</button>
                                </div>
                            </div>
                        </form>
                    </div>
                    
                    <!-- USER MANAGEMENT -->
                    <div class="tab-pane fade" id="users">
                        <h5 class="mb-4">User Management</h5>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Username</th>
                                        <th>Full Name</th>
                                        <th>Email</th>
                                        <th>Role</th>
                                        <th>Status</th>
                                        <th>Last Login</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td><strong>admin</strong></td>
                                        <td>System Administrator</td>
                                        <td>admin@cosmeticswms.com</td>
                                        <td><span class="badge bg-danger">Administrator</span></td>
                                        <td><span class="badge bg-success">Active</span></td>
                                        <td>2024-01-15 14:30</td>
                                        <td>
                                            <button class="btn btn-sm btn-warning">Edit</button>
                                            <button class="btn btn-sm btn-secondary">Reset Pass</button>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><strong>staff1</strong></td>
                                        <td>John Doe</td>
                                        <td>staff1@cosmeticswms.com</td>
                                        <td><span class="badge bg-primary">Staff</span></td>
                                        <td><span class="badge bg-success">Active</span></td>
                                        <td>2024-01-15 10:15</td>
                                        <td>
                                            <button class="btn btn-sm btn-warning">Edit</button>
                                            <button class="btn btn-sm btn-secondary">Reset Pass</button>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><strong>warehouse</strong></td>
                                        <td>Jane Smith</td>
                                        <td>warehouse@cosmeticswms.com</td>
                                        <td><span class="badge bg-info">Warehouse</span></td>
                                        <td><span class="badge bg-success">Active</span></td>
                                        <td>2024-01-14 16:45</td>
                                        <td>
                                            <button class="btn btn-sm btn-warning">Edit</button>
                                            <button class="btn btn-sm btn-secondary">Reset Pass</button>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><strong>qc_officer</strong></td>
                                        <td>Robert Brown</td>
                                        <td>qc@cosmeticswms.com</td>
                                        <td><span class="badge bg-warning">QC Officer</span></td>
                                        <td><span class="badge bg-success">Active</span></td>
                                        <td>2024-01-14 09:20</td>
                                        <td>
                                            <button class="btn btn-sm btn-warning">Edit</button>
                                            <button class="btn btn-sm btn-secondary">Reset Pass</button>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <button class="btn btn-success mt-3">
                            <i class="fas fa-user-plus"></i> Add New User
                        </button>
                    </div>
                    
                    <!-- NOTIFICATION SETTINGS -->
                    <div class="tab-pane fade" id="notifications">
                        <h5 class="mb-4">Notification Settings</h5>
                        <form>
                            <div class="mb-4">
                                <h6>Email Notifications</h6>
                                <div class="form-check mb-2">
                                    <input class="form-check-input" type="checkbox" checked>
                                    <label class="form-check-label">
                                        Low stock alerts
                                    </label>
                                </div>
                                <div class="form-check mb-2">
                                    <input class="form-check-input" type="checkbox" checked>
                                    <label class="form-check-label">
                                        Expiry date alerts
                                    </label>
                                </div>
                                <div class="form-check mb-2">
                                    <input class="form-check-input" type="checkbox" checked>
                                    <label class="form-check-label">
                                        QC failure alerts
                                    </label>
                                </div>
                                <div class="form-check mb-2">
                                    <input class="form-check-input" type="checkbox">
                                    <label class="form-check-label">
                                        Daily summary report
                                    </label>
                                </div>
                                <div class="form-check mb-2">
                                    <input class="form-check-input" type="checkbox">
                                    <label class="form-check-label">
                                        Weekly performance report
                                    </label>
                                </div>
                            </div>
                            
                            <div class="mb-4">
                                <h6>Alert Frequency</h6>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="alertFrequency" checked>
                                    <label class="form-check-label">
                                        Immediate
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="alertFrequency">
                                    <label class="form-check-label">
                                        Daily digest
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="alertFrequency">
                                    <label class="form-check-label">
                                        Weekly summary
                                    </label>
                                </div>
                            </div>
                            
                            <div class="mb-4">
                                <h6>Notification Recipients</h6>
                                <div class="mb-3">
                                    <label class="form-label">Primary Email</label>
                                    <input type="email" class="form-control" value="manager@cosmeticswms.com">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Secondary Email (optional)</label>
                                    <input type="email" class="form-control" placeholder="backup@example.com">
                                </div>
                            </div>
                            
                            <button type="submit" class="btn btn-primary">Save Notification Settings</button>
                        </form>
                    </div>
                    
                    <!-- BACKUP SETTINGS -->
                    <div class="tab-pane fade" id="backup">
                        <h5 class="mb-4">Backup & Restore</h5>
                        <div class="alert alert-info">
                            <i class="fas fa-info-circle"></i> 
                            <strong>Last backup:</strong> 2024-01-14 23:00 (Size: 45MB)
                        </div>
                        
                        <div class="row g-3 mb-4">
                            <div class="col-md-6">
                                <button class="btn btn-primary w-100 mb-2">
                                    <i class="fas fa-download"></i> Backup Now
                                </button>
                                <small class="text-muted">Creates a full backup of database and files</small>
                            </div>
                            <div class="col-md-6">
                                <button class="btn btn-warning w-100 mb-2">
                                    <i class="fas fa-upload"></i> Restore Backup
                                </button>
                                <small class="text-muted">Restore from a previous backup file</small>
                            </div>
                        </div>
                        
                        <div class="mb-4">
                            <h6>Auto Backup Schedule</h6>
                            <select class="form-select mb-3">
                                <option selected>Daily at 23:00</option>
                                <option>Weekly (Sunday at 02:00)</option>
                                <option>Monthly (1st day at 03:00)</option>
                                <option>Disabled</option>
                            </select>
                            <small class="text-muted">Automatic backups will be stored for 30 days</small>
                        </div>
                        
                        <div>
                            <h6>Recent Backups</h6>
                            <ul class="list-group">
                                <li class="list-group-item d-flex justify-content-between">
                                    <span>2024-01-14 23:00</span>
                                    <span>45MB <button class="btn btn-sm btn-info">Download</button></span>
                                </li>
                                <li class="list-group-item d-flex justify-content-between">
                                    <span>2024-01-13 23:00</span>
                                    <span>44MB <button class="btn btn-sm btn-info">Download</button></span>
                                </li>
                                <li class="list-group-item d-flex justify-content-between">
                                    <span>2024-01-12 23:00</span>
                                    <span>43MB <button class="btn btn-sm btn-info">Download</button></span>
                                </li>
                            </ul>
                        </div>
                    </div>
                    
                    <!-- SYSTEM INFO -->
                    <div class="tab-pane fade" id="system">
                        <h5 class="mb-4">System Information</h5>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="card mb-3">
                                    <div class="card-body">
                                        <h6>Application Info</h6>
                                        <table class="table table-sm">
                                            <tr><td>Version</td><td><strong>v2.1.0</strong></td></tr>
                                            <tr><td>License</td><td>Proprietary</td></tr>
                                            <tr><td>Last Updated</td><td>2024-01-10</td></tr>
                                            <tr><td>Support Until</td><td>2025-12-31</td></tr>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="card mb-3">
                                    <div class="card-body">
                                        <h6>Server Info</h6>
                                        <table class="table table-sm">
                                            <tr><td>PHP Version</td><td><?php echo phpversion(); ?></td></tr>
                                            <tr><td>Database</td><td>MySQL 8.0</td></tr>
                                            <tr><td>Server OS</td><td><?php echo php_uname('s'); ?></td></tr>
                                            <tr><td>Memory Limit</td><td><?php echo ini_get('memory_limit'); ?></td></tr>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="alert alert-warning">
                            <i class="fas fa-exclamation-triangle"></i>
                            <strong>Important:</strong> Keep your system updated for security and performance.
                        </div>
                        
                        <button class="btn btn-primary">
                            <i class="fas fa-sync-alt"></i> Check for Updates
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Initialize tabs
        var tabEl = document.querySelectorAll('a[data-bs-toggle="tab"]')
        tabEl.forEach(function(tab) {
            tab.addEventListener('click', function (e) {
                e.preventDefault()
                var tabTrigger = new bootstrap.Tab(this)
                tabTrigger.show()
            })
        })
    </script>
</body>
</html>