<?php
// modules/batch/release.php
define('ROOT_PATH', dirname(dirname(dirname(__FILE__))) . '/');
require_once ROOT_PATH . 'includes/config.php';
require_once ROOT_PATH . 'includes/auth.php';
checkLogin();

$page_title = "Release Batch";

// Get batch ID
$batch_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if(!$batch_id) {
    header("Location: index.php");
    exit();
}

// Get batch info
$batch_sql = "SELECT pb.*, p.name as product_name, p.sku 
              FROM product_batches pb
              JOIN products p ON pb.product_id = p.id
              WHERE pb.id = $batch_id AND pb.status = 'quarantine'";
$batch_result = mysqli_query($conn, $batch_sql);

if(mysqli_num_rows($batch_result) == 0) {
    header("Location: index.php?error=not_quarantine");
    exit();
}

$batch = mysqli_fetch_assoc($batch_result);

// Handle release
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $release_notes = mysqli_real_escape_string($conn, $_POST['release_notes']);
    
    // Update batch status
    $sql = "UPDATE product_batches SET 
            status = 'released',
            notes = CONCAT(IFNULL(notes, ''), '\nReleased: ', '$release_notes'),
            updated_at = NOW()
            WHERE id = $batch_id";
    
    if(mysqli_query($conn, $sql)) {
        // Log activity
        $log_sql = "INSERT INTO audit_logs (user_id, action, table_name, record_id, notes) 
                   VALUES (" . $_SESSION['user_id'] . ", 'RELEASE', 'product_batches', $batch_id, '$release_notes')";
        mysqli_query($conn, $log_sql);
        
        // Redirect to batch view
        header("Location: view.php?id=$batch_id&success=released");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cosmetics WMS - Release Batch</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <style>
        body { background: #f8f9fa; }
        .sidebar {
            background: #2c3e50;
            color: white;
            min-height: 100vh;
            width: 200px;
            position: fixed;
        }
        .main { margin-left: 200px; padding: 20px; }
        .nav-link { color: #bdc3c7; }
        .nav-link:hover { color: white; background: rgba(255,255,255,0.1); }
        .nav-link.active { color: #3498db; background: rgba(52, 152, 219, 0.1); }
        .release-card {
            max-width: 600px;
            margin: 0 auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            text-align: center;
        }
        .icon-large {
            font-size: 80px;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="d-flex">
        <!-- Sidebar -->
        <div class="sidebar p-3">
            <h4><i class="fas fa-palette"></i> Cosmetics WMS</h4>
            <hr>
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo ROOT_PATH; ?>index.php">
                        <i class="fas fa-tachometer-alt"></i> Dashboard
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="index.php">
                        <i class="fas fa-boxes"></i> Batch List
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="#">
                        <i class="fas fa-check-circle"></i> Release Batch
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo ROOT_PATH; ?>logout.php">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </a>
                </li>
            </ul>
        </div>
        
        <!-- Main Content -->
        <div class="main flex-grow-1">
            <div class="mb-4">
                <a href="view.php?id=<?php echo $batch_id; ?>" class="btn btn-secondary mb-3">
                    <i class="fas fa-arrow-left"></i> Back to Batch
                </a>
            </div>
            
            <div class="release-card">
                <div class="icon-large text-success">
                    <i class="fas fa-check-circle"></i>
                </div>
                
                <h3>Release Batch from Quarantine</h3>
                <p class="text-muted mb-4">
                    You are about to release batch <strong><?php echo $batch['batch_number']; ?></strong>
                    from quarantine. This will make it available for sale.
                </p>
                
                <div class="alert alert-warning mb-4">
                    <i class="fas fa-exclamation-triangle"></i>
                    <strong>Please confirm:</strong>
                    <ul class="mb-0 mt-2">
                        <li>QC check has been performed and passed</li>
                        <li>Product meets quality standards</li>
                        <li>BPOM requirements are satisfied</li>
                        <li>Packaging is intact and proper</li>
                    </ul>
                </div>
                
                <form method="POST" action="">
                    <div class="mb-4">
                        <label class="form-label">Release Notes</label>
                        <textarea name="release_notes" class="form-control" rows="3" 
                                  placeholder="Enter release notes or comments..." required></textarea>
                        <small class="text-muted">Briefly describe why this batch is being released.</small>
                    </div>
                    
                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-success btn-lg">
                            <i class="fas fa-check"></i> Confirm Release
                        </button>
                        <a href="view.php?id=<?php echo $batch_id; ?>" class="btn btn-outline-danger">
                            Cancel Release
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>