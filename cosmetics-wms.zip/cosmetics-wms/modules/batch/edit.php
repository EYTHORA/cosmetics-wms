<?php
// modules/batch/edit.php
define('ROOT_PATH', dirname(dirname(dirname(__FILE__))) . '/');
require_once ROOT_PATH . 'includes/config.php';
require_once ROOT_PATH . 'includes/auth.php';
checkLogin();

$page_title = "Edit Batch";
$success = false;
$error = '';

// Get batch ID
$batch_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if(!$batch_id) {
    header("Location: index.php");
    exit();
}

// Get batch data
$batch_sql = "SELECT pb.*, p.sku, p.name as product_name 
              FROM product_batches pb
              JOIN products p ON pb.product_id = p.id
              WHERE pb.id = $batch_id";
$batch_result = mysqli_query($conn, $batch_sql);

if(mysqli_num_rows($batch_result) == 0) {
    header("Location: index.php");
    exit();
}

$batch = mysqli_fetch_assoc($batch_result);

// Handle form submission
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $batch_number = mysqli_real_escape_string($conn, $_POST['batch_number']);
    $manufacturing_date = mysqli_real_escape_string($conn, $_POST['manufacturing_date']);
    $expiry_date = mysqli_real_escape_string($conn, $_POST['expiry_date']);
    $bpom_number = mysqli_real_escape_string($conn, $_POST['bpom_number']);
    $supplier_id = intval($_POST['supplier_id']);
    $notes = mysqli_real_escape_string($conn, $_POST['notes']);
    
    // Update batch
    $sql = "UPDATE product_batches SET
            batch_number = '$batch_number',
            manufacturing_date = '$manufacturing_date',
            expiry_date = '$expiry_date',
            bpom_number = '$bpom_number',
            supplier_id = $supplier_id,
            notes = '$notes',
            updated_at = NOW()
            WHERE id = $batch_id";
    
    if(mysqli_query($conn, $sql)) {
        $success = true;
        
        // Log activity
        $log_sql = "INSERT INTO audit_logs (user_id, action, table_name, record_id) 
                   VALUES (" . $_SESSION['user_id'] . ", 'UPDATE', 'product_batches', $batch_id)";
        mysqli_query($conn, $log_sql);
    } else {
        $error = "Error: " . mysqli_error($conn);
    }
}

// Get suppliers
$suppliers_sql = "SELECT id, company_name FROM suppliers WHERE status = 'active' ORDER BY company_name";
$suppliers_result = mysqli_query($conn, $suppliers_sql);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cosmetics WMS - Edit Batch</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <style>
        body { background: #f8f9fa; }
        .sidebar {
            background: #2c3e50;
            color: white;
            min-height: 100vh;
            width: 200px;
            position: fixed;
        }
        .main { margin-left: 200px; padding: 20px; }
        .nav-link { color: #bdc3c7; }
        .nav-link:hover { color: white; background: rgba(255,255,255,0.1); }
        .nav-link.active { color: #3498db; background: rgba(52, 152, 219, 0.1); }
        .form-container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .batch-info {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        .status-badge {
            font-size: 14px;
            padding: 8px 15px;
            border-radius: 20px;
        }
    </style>
</head>
<body>
    <div class="d-flex">
        <!-- Sidebar -->
        <div class="sidebar p-3">
            <h4><i class="fas fa-palette"></i> Cosmetics WMS</h4>
            <hr>
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo ROOT_PATH; ?>index.php">
                        <i class="fas fa-tachometer-alt"></i> Dashboard
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="index.php">
                        <i class="fas fa-boxes"></i> Batch List
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="#">
                        <i class="fas fa-edit"></i> Edit Batch
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo ROOT_PATH; ?>logout.php">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </a>
                </li>
            </ul>
        </div>
        
        <!-- Main Content -->
        <div class="main flex-grow-1">
            <div class="mb-4">
                <a href="index.php" class="btn btn-secondary mb-3">
                    <i class="fas fa-arrow-left"></i> Back to Batch List
                </a>
                <h2><i class="fas fa-edit"></i> Edit Batch</h2>
                <p class="text-muted">Edit batch information</p>
            </div>
            
            <?php if($success): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <i class="fas fa-check-circle"></i> Batch updated successfully!
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php endif; ?>
            
            <?php if($error): ?>
            <div class="alert alert-danger alert-dismissible fade show">
                <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php endif; ?>
            
            <!-- Batch Info -->
            <div class="batch-info">
                <div class="row">
                    <div class="col-md-4">
                        <strong>Product:</strong> <?php echo $batch['sku'] . ' - ' . $batch['product_name']; ?>
                    </div>
                    <div class="col-md-4">
                        <strong>Current Quantity:</strong> <?php echo $batch['current_quantity']; ?>
                    </div>
                    <div class="col-md-4">
                        <strong>Status:</strong> 
                        <?php 
                        $status_class = '';
                        switch($batch['status']) {
                            case 'released': $status_class = 'bg-success'; break;
                            case 'quarantine': $status_class = 'bg-warning'; break;
                            case 'expired': $status_class = 'bg-danger'; break;
                            case 'recalled': $status_class = 'bg-secondary'; break;
                        }
                        ?>
                        <span class="badge <?php echo $status_class; ?> status-badge">
                            <?php echo ucfirst($batch['status']); ?>
                        </span>
                    </div>
                </div>
            </div>
            
            <!-- Edit Form -->
            <div class="form-container">
                <form method="POST" action="">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Batch Number</label>
                                <input type="text" name="batch_number" class="form-control" 
                                       value="<?php echo htmlspecialchars($batch['batch_number']); ?>" required>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Manufacturing Date</label>
                                <input type="date" name="manufacturing_date" class="form-control" 
                                       value="<?php echo $batch['manufacturing_date']; ?>" required>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Expiry Date</label>
                                <input type="date" name="expiry_date" class="form-control" 
                                       value="<?php echo $batch['expiry_date']; ?>" required>
                                <?php
                                $expiry_date = new DateTime($batch['expiry_date']);
                                $today = new DateTime();
                                $interval = $today->diff($expiry_date);
                                $days_left = $interval->days;
                                
                                if($days_left <= 0): ?>
                                <div class="text-danger mt-1">
                                    <i class="fas fa-exclamation-triangle"></i> Batch sudah expired!
                                </div>
                                <?php elseif($days_left <= 30): ?>
                                <div class="text-warning mt-1">
                                    <i class="fas fa-clock"></i> Sisa <?php echo $days_left; ?> hari
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">BPOM Number</label>
                                <input type="text" name="bpom_number" class="form-control" 
                                       value="<?php echo htmlspecialchars($batch['bpom_number']); ?>" required>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Supplier</label>
                                <select name="supplier_id" class="form-select">
                                    <option value="">Select Supplier</option>
                                    <?php 
                                    mysqli_data_seek($suppliers_result, 0);
                                    while($supplier = mysqli_fetch_assoc($suppliers_result)): 
                                    ?>
                                    <option value="<?php echo $supplier['id']; ?>"
                                        <?php echo $batch['supplier_id'] == $supplier['id'] ? 'selected' : ''; ?>>
                                        <?php echo $supplier['company_name']; ?>
                                    </option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Notes</label>
                                <textarea name="notes" class="form-control" rows="3"><?php echo htmlspecialchars($batch['notes'] ?? ''); ?></textarea>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row mt-4">
                        <div class="col-12">
                            <button type="submit" class="btn btn-primary btn-lg">
                                <i class="fas fa-save"></i> Update Batch
                            </button>
                            <a href="view.php?id=<?php echo $batch_id; ?>" class="btn btn-info">
                                <i class="fas fa-eye"></i> View Details
                            </a>
                            <a href="index.php" class="btn btn-outline-danger">Cancel</a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>