<?php
// modules/batch/qc_check.php
define('ROOT_PATH', dirname(dirname(dirname(__FILE__))) . '/');
require_once ROOT_PATH . 'includes/config.php';
require_once ROOT_PATH . 'includes/auth.php';
checkLogin();

$page_title = "QC Check";
$success = false;
$error = '';

// Get batch ID
$batch_id = isset($_GET['batch_id']) ? intval($_GET['batch_id']) : 0;
if(!$batch_id) {
    header("Location: index.php");
    exit();
}

// Get batch info
$batch_sql = "SELECT pb.*, p.name as product_name, p.sku 
              FROM product_batches pb
              JOIN products p ON pb.product_id = p.id
              WHERE pb.id = $batch_id";
$batch_result = mysqli_query($conn, $batch_sql);
$batch = mysqli_fetch_assoc($batch_result);

// Handle form submission
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $check_type = mysqli_real_escape_string($conn, $_POST['check_type']);
    $temperature = isset($_POST['temperature']) ? floatval($_POST['temperature']) : null;
    $humidity = isset($_POST['humidity']) ? floatval($_POST['humidity']) : null;
    $packaging = mysqli_real_escape_string($conn, $_POST['packaging']);
    $condition = mysqli_real_escape_string($conn, $_POST['condition']);
    $passed = isset($_POST['passed']) ? 1 : 0;
    $notes = mysqli_real_escape_string($conn, $_POST['notes']);
    
    // Insert QC check
    $sql = "INSERT INTO qc_checks (
            batch_id, check_type, temperature_check, humidity_check,
            packaging_condition, product_condition, passed, notes, checked_by, check_date
        ) VALUES (
            $batch_id, '$check_type', $temperature, $humidity,
            '$packaging', '$condition', $passed, '$notes', " . $_SESSION['user_id'] . ", CURDATE()
        )";
    
    if(mysqli_query($conn, $sql)) {
        $success = true;
        
        // If QC passed and batch is in quarantine, auto-release
        if($passed && $batch['status'] == 'quarantine') {
            $update_sql = "UPDATE product_batches SET status = 'released' WHERE id = $batch_id";
            mysqli_query($conn, $update_sql);
        }
    } else {
        $error = "Error: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cosmetics WMS - QC Check</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <style>
        body { background: #f8f9fa; }
        .sidebar {
            background: #2c3e50;
            color: white;
            min-height: 100vh;
            width: 200px;
            position: fixed;
        }
        .main { margin-left: 200px; padding: 20px; }
        .nav-link { color: #bdc3c7; }
        .nav-link:hover { color: white; background: rgba(255,255,255,0.1); }
        .nav-link.active { color: #3498db; background: rgba(52, 152, 219, 0.1); }
        .form-container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .qc-indicator {
            width: 20px;
            height: 20px;
            border-radius: 50%;
            display: inline-block;
            margin-right: 5px;
        }
        .indicator-pass { background: #28a745; }
        .indicator-fail { background: #dc3545; }
    </style>
</head>
<body>
    <div class="d-flex">
        <!-- Sidebar -->
        <div class="sidebar p-3">
            <h4><i class="fas fa-palette"></i> Cosmetics WMS</h4>
            <hr>
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo ROOT_PATH; ?>index.php">
                        <i class="fas fa-tachometer-alt"></i> Dashboard
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="index.php">
                        <i class="fas fa-boxes"></i> Batch List
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="#">
                        <i class="fas fa-clipboard-check"></i> QC Check
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo ROOT_PATH; ?>logout.php">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </a>
                </li>
            </ul>
        </div>
        
        <!-- Main Content -->
        <div class="main flex-grow-1">
            <div class="mb-4">
                <a href="view.php?id=<?php echo $batch_id; ?>" class="btn btn-secondary mb-3">
                    <i class="fas fa-arrow-left"></i> Back to Batch
                </a>
                <h2><i class="fas fa-clipboard-check"></i> Quality Control Check</h2>
                <p class="text-muted">Batch: <?php echo $batch['batch_number']; ?> - <?php echo $batch['sku']; ?></p>
            </div>
            
            <?php if($success): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <i class="fas fa-check-circle"></i> QC check recorded successfully!
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php endif; ?>
            
            <?php if($error): ?>
            <div class="alert alert-danger alert-dismissible fade show">
                <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php endif; ?>
            
            <div class="form-container">
                <form method="POST" action="">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Check Type</label>
                                <select name="check_type" class="form-select" required>
                                    <option value="incoming">Incoming Inspection</option>
                                    <option value="periodic">Periodic Check</option>
                                    <option value="outgoing">Outgoing Check</option>
                                </select>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Temperature (°C)</label>
                                <input type="number" step="0.1" name="temperature" class="form-control" 
                                       placeholder="e.g., 25.5">
                                <small class="text-muted">Ideal: 20-25°C for cosmetics</small>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Humidity (%)</label>
                                <input type="number" step="0.1" name="humidity" class="form-control" 
                                       placeholder="e.g., 55.0">
                                <small class="text-muted">Ideal: 40-60% for cosmetics</small>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Packaging Condition</label>
                                <select name="packaging" class="form-select" required>
                                    <option value="good">Good</option>
                                    <option value="damaged">Damaged</option>
                                    <option value="sealed">Properly Sealed</option>
                                    <option value="leaking">Leaking</option>
                                </select>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Product Condition</label>
                                <select name="condition" class="form-select" required>
                                    <option value="good">Good</option>
                                    <option value="expired">Expired</option>
                                    <option value="damaged">Damaged</option>
                                    <option value="contaminated">Contaminated</option>
                                    <option value="separated">Separated</option>
                                </select>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">QC Result</label><br>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="passed" id="pass" value="1" checked>
                                    <label class="form-check-label" for="pass">
                                        <span class="qc-indicator indicator-pass"></span> Pass
                                    </label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="passed" id="fail" value="0">
                                    <label class="form-check-label" for="fail">
                                        <span class="qc-indicator indicator-fail"></span> Fail
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Notes / Observations</label>
                        <textarea name="notes" class="form-control" rows="4" 
                                  placeholder="Describe any issues found..."></textarea>
                    </div>
                    
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle"></i> 
                        <strong>Note:</strong> If QC check passes and batch is in quarantine, 
                        it will be automatically released.
                    </div>
                    
                    <div class="row mt-4">
                        <div class="col-12">
                            <button type="submit" class="btn btn-primary btn-lg">
                                <i class="fas fa-save"></i> Save QC Check
                            </button>
                            <a href="view.php?id=<?php echo $batch_id; ?>" class="btn btn-outline-danger">Cancel</a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>