<?php
// modules/batch/add.php
define('ROOT_PATH', dirname(dirname(dirname(__FILE__))) . '/');
require_once ROOT_PATH . 'includes/config.php';
require_once ROOT_PATH . 'includes/auth.php';
checkLogin();

$page_title = "Add New Batch";

// Handle form submission
$success = false;
$error = '';

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $batch_number = mysqli_real_escape_string($conn, $_POST['batch_number']);
    $product_id = intval($_POST['product_id']);
    $manufacturing_date = mysqli_real_escape_string($conn, $_POST['manufacturing_date']);
    $expiry_date = mysqli_real_escape_string($conn, $_POST['expiry_date']);
    $quantity = intval($_POST['quantity']);
    $bpom_number = mysqli_real_escape_string($conn, $_POST['bpom_number']);
    $supplier_id = intval($_POST['supplier_id']);
    
    // Validasi
    if(empty($batch_number) || empty($product_id) || empty($expiry_date)) {
        $error = "Please fill all required fields!";
    } else {
        // Auto-generate batch number jika kosong
        if(empty($batch_number)) {
            $product_sql = "SELECT sku FROM products WHERE id = $product_id";
            $product_result = mysqli_query($conn, $product_sql);
            $product = mysqli_fetch_assoc($product_result);
            $batch_number = 'BATCH-' . $product['sku'] . '-' . date('Ymd-His');
        }
        
        // Insert batch
        $sql = "INSERT INTO product_batches (
            product_id, batch_number, manufacturing_date, expiry_date, 
            quantity, current_quantity, bpom_number, supplier_id, status
        ) VALUES (
            $product_id, '$batch_number', '$manufacturing_date', '$expiry_date',
            $quantity, $quantity, '$bpom_number', $supplier_id, 'quarantine'
        )";
        
        if(mysqli_query($conn, $sql)) {
            $batch_id = mysqli_insert_id($conn);
            $success = true;
            
            // Log activity
            $log_sql = "INSERT INTO audit_logs (user_id, action, table_name, record_id) 
                       VALUES (" . $_SESSION['user_id'] . ", 'CREATE', 'product_batches', $batch_id)";
            mysqli_query($conn, $log_sql);
        } else {
            $error = "Error: " . mysqli_error($conn);
        }
    }
}

// Get products for dropdown
$products_sql = "SELECT id, sku, name FROM products WHERE status = 'active' ORDER BY name";
$products_result = mysqli_query($conn, $products_sql);

// Get suppliers
$suppliers_sql = "SELECT id, company_name FROM suppliers WHERE status = 'active' ORDER BY company_name";
$suppliers_result = mysqli_query($conn, $suppliers_sql);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cosmetics WMS - Add New Batch</title>
    
    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <!-- Select2 -->
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    
    <style>
        body { background: #f8f9fa; }
        .sidebar {
            background: #2c3e50;
            color: white;
            min-height: 100vh;
            width: 200px;
            position: fixed;
        }
        .main { margin-left: 200px; padding: 20px; }
        .nav-link { color: #bdc3c7; }
        .nav-link:hover { color: white; background: rgba(255,255,255,0.1); }
        .nav-link.active { color: #3498db; background: rgba(52, 152, 219, 0.1); }
        .form-container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .required:after {
            content: " *";
            color: red;
        }
    </style>
</head>
<body>
    <div class="d-flex">
        <!-- Sidebar -->
        <div class="sidebar p-3">
            <h4><i class="fas fa-palette"></i> Cosmetics WMS</h4>
            <hr>
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo ROOT_PATH; ?>index.php">
                        <i class="fas fa-tachometer-alt"></i> Dashboard
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="index.php">
                        <i class="fas fa-boxes"></i> Batch List
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="#">
                        <i class="fas fa-plus-circle"></i> Add Batch
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo ROOT_PATH; ?>logout.php">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </a>
                </li>
            </ul>
        </div>
        
        <!-- Main Content -->
        <div class="main flex-grow-1">
            <div class="mb-4">
                <a href="index.php" class="btn btn-secondary mb-3">
                    <i class="fas fa-arrow-left"></i> Back to Batch List
                </a>
                <h2><i class="fas fa-plus-circle"></i> Add New Batch</h2>
                <p class="text-muted">Add new product batch with expiry tracking</p>
            </div>
            
            <?php if($success): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <i class="fas fa-check-circle"></i> Batch berhasil ditambahkan!
                <a href="index.php" class="alert-link">Lihat daftar batch</a>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php endif; ?>
            
            <?php if($error): ?>
            <div class="alert alert-danger alert-dismissible fade show">
                <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php endif; ?>
            
            <div class="form-container">
                <form method="POST" action="" id="batchForm">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label required">Product</label>
                                <select name="product_id" class="form-select" required id="productSelect">
                                    <option value="">Select Product</option>
                                    <?php while($product = mysqli_fetch_assoc($products_result)): ?>
                                    <option value="<?php echo $product['id']; ?>">
                                        <?php echo $product['sku'] . ' - ' . $product['name']; ?>
                                    </option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Batch Number</label>
                                <input type="text" name="batch_number" class="form-control" 
                                       placeholder="Auto-generated if empty" id="batchNumber">
                                <small class="text-muted">Format: BATCH-{SKU}-{YYYYMMDD}-{SEQ}</small>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label required">Manufacturing Date</label>
                                <input type="date" name="manufacturing_date" class="form-control" 
                                       value="<?php echo date('Y-m-d'); ?>" required>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label required">Expiry Date</label>
                                <input type="date" name="expiry_date" class="form-control" required>
                                <small class="text-muted">Kosmetik biasanya 24-36 bulan dari manufacture date</small>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label required">Quantity</label>
                                <input type="number" name="quantity" class="form-control" 
                                       min="1" value="100" required>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label required">BPOM Number</label>
                                <input type="text" name="bpom_number" class="form-control" 
                                       placeholder="BPOM-XXXXXX-XXXX" required>
                                <small class="text-muted">Wajib untuk produk kosmetik</small>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Supplier</label>
                                <select name="supplier_id" class="form-select">
                                    <option value="">Select Supplier</option>
                                    <?php while($supplier = mysqli_fetch_assoc($suppliers_result)): ?>
                                    <option value="<?php echo $supplier['id']; ?>">
                                        <?php echo $supplier['company_name']; ?>
                                    </option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Notes</label>
                                <textarea name="notes" class="form-control" rows="3"></textarea>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row mt-4">
                        <div class="col-12">
                            <div class="alert alert-info">
                                <i class="fas fa-info-circle"></i> 
                                <strong>Note:</strong> Batch baru akan otomatis berstatus <span class="badge bg-warning">Quarantine</span> 
                                dan harus melalui QC check sebelum dirilis.
                            </div>
                        </div>
                    </div>
                    
                    <div class="row mt-3">
                        <div class="col-12">
                            <button type="submit" class="btn btn-primary btn-lg">
                                <i class="fas fa-save"></i> Save Batch
                            </button>
                            <button type="reset" class="btn btn-secondary">Reset</button>
                            <a href="index.php" class="btn btn-outline-danger">Cancel</a>
                        </div>
                    </div>
                </form>
            </div>
            
            <!-- Product Info Card -->
            <div class="card mt-4 d-none" id="productInfoCard">
                <div class="card-header">
                    <h5 class="mb-0"><i class="fas fa-info-circle"></i> Product Information</h5>
                </div>
                <div class="card-body">
                    <div class="row" id="productInfo"></div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    
    <script>
    $(document).ready(function() {
        // Initialize Select2
        $('#productSelect').select2({
            placeholder: "Select a product",
            width: '100%'
        });
        
        // Auto-generate batch number when product is selected
        $('#productSelect').change(function() {
            var productId = $(this).val();
            if(productId) {
                $.ajax({
                    url: 'ajax/get_product_info.php',
                    method: 'POST',
                    data: {product_id: productId},
                    dataType: 'json',
                    success: function(response) {
                        if(response.success) {
                            // Show product info
                            $('#productInfoCard').removeClass('d-none');
                            $('#productInfo').html(`
                                <div class="col-md-3">
                                    <strong>SKU:</strong> ${response.sku}
                                </div>
                                <div class="col-md-3">
                                    <strong>Brand:</strong> ${response.brand}
                                </div>
                                <div class="col-md-3">
                                    <strong>Category:</strong> ${response.category}
                                </div>
                                <div class="col-md-3">
                                    <strong>Halal:</strong> ${response.halal ? 'Yes' : 'No'}
                                </div>
                            `);
                            
                            // Auto-generate batch number
                            var timestamp = new Date().getTime();
                            var batchNo = 'BATCH-' + response.sku + '-' + new Date().toISOString().slice(0,10).replace(/-/g, '') + '-' + (timestamp % 1000);
                            $('#batchNumber').val(batchNo);
                        }
                    }
                });
            } else {
                $('#productInfoCard').addClass('d-none');
                $('#batchNumber').val('');
            }
        });
        
        // Calculate expiry date (default 24 months)
        $('input[name="manufacturing_date"]').change(function() {
            var manufactureDate = new Date($(this).val());
            if(manufactureDate) {
                var expiryDate = new Date(manufactureDate);
                expiryDate.setMonth(expiryDate.getMonth() + 24); // 24 months for cosmetics
                var formatted = expiryDate.toISOString().split('T')[0];
                $('input[name="expiry_date"]').val(formatted);
            }
        });
        
        // Form validation
        $('#batchForm').submit(function(e) {
            var expiryDate = new Date($('input[name="expiry_date"]').val());
            var today = new Date();
            
            if(expiryDate <= today) {
                e.preventDefault();
                alert('Expiry date must be in the future!');
                return false;
            }
            
            return true;
        });
    });
    </script>
</body>
</html>