<?php
// modules/batch/view.php
define('ROOT_PATH', dirname(dirname(dirname(__FILE__))) . '/');
require_once ROOT_PATH . 'includes/config.php';
require_once ROOT_PATH . 'includes/auth.php';
checkLogin();

$page_title = "Batch Details";

// Get batch ID
$batch_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if(!$batch_id) {
    header("Location: index.php");
    exit();
}

// Get batch details
$sql = "SELECT pb.*, p.name as product_name, p.sku, p.halal_certified,
               b.name as brand_name, c.name as category_name,
               s.company_name as supplier_name, s.contact_person,
               wl.location_code, wl.zone_code, wl.rack_number, wl.shelf_number,
               u.full_name as created_by_name,
               DATEDIFF(pb.expiry_date, CURDATE()) as days_remaining
        FROM product_batches pb
        JOIN products p ON pb.product_id = p.id
        JOIN brands b ON p.brand_id = b.id
        JOIN categories c ON p.category_id = c.id
        LEFT JOIN suppliers s ON pb.supplier_id = s.id
        LEFT JOIN warehouse_locations wl ON pb.location_id = wl.id
        LEFT JOIN users u ON pb.created_by = u.id
        WHERE pb.id = $batch_id";

$result = mysqli_query($conn, $sql);

if(mysqli_num_rows($result) == 0) {
    header("Location: index.php");
    exit();
}

$batch = mysqli_fetch_assoc($result);

// Get QC checks
$qc_sql = "SELECT * FROM qc_checks WHERE batch_id = $batch_id ORDER BY check_date DESC";
$qc_result = mysqli_query($conn, $qc_sql);

// Get transactions
$tx_sql = "SELECT * FROM inventory_transactions WHERE batch_id = $batch_id ORDER BY transaction_date DESC LIMIT 10";
$tx_result = mysqli_query($conn, $tx_sql);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cosmetics WMS - Batch Details</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <style>
        body { background: #f8f9fa; }
        .sidebar {
            background: #2c3e50;
            color: white;
            min-height: 100vh;
            width: 200px;
            position: fixed;
        }
        .main { margin-left: 200px; padding: 20px; }
        .nav-link { color: #bdc3c7; }
        .nav-link:hover { color: white; background: rgba(255,255,255,0.1); }
        .nav-link.active { color: #3498db; background: rgba(52, 152, 219, 0.1); }
        .info-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        .info-row {
            padding: 10px 0;
            border-bottom: 1px solid #eee;
        }
        .info-row:last-child { border-bottom: none; }
        .status-badge-lg {
            font-size: 16px;
            padding: 10px 20px;
            border-radius: 25px;
        }
        .expiry-progress {
            height: 10px;
            background: #e9ecef;
            border-radius: 5px;
            margin-top: 10px;
            overflow: hidden;
        }
        .expiry-bar {
            height: 100%;
            border-radius: 5px;
        }
        .tab-content { background: white; padding: 20px; border-radius: 0 0 10px 10px; }
    </style>
</head>
<body>
    <div class="d-flex">
        <!-- Sidebar -->
        <div class="sidebar p-3">
            <h4><i class="fas fa-palette"></i> Cosmetics WMS</h4>
            <hr>
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo ROOT_PATH; ?>index.php">
                        <i class="fas fa-tachometer-alt"></i> Dashboard
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="index.php">
                        <i class="fas fa-boxes"></i> Batch List
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="#">
                        <i class="fas fa-eye"></i> View Batch
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo ROOT_PATH; ?>logout.php">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </a>
                </li>
            </ul>
        </div>
        
        <!-- Main Content -->
        <div class="main flex-grow-1">
            <div class="mb-4">
                <a href="index.php" class="btn btn-secondary mb-3">
                    <i class="fas fa-arrow-left"></i> Back to Batch List
                </a>
                <h2><i class="fas fa-box"></i> Batch Details</h2>
            </div>
            
            <!-- Batch Header -->
            <div class="info-card">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <h3><?php echo $batch['batch_number']; ?></h3>
                        <h5><?php echo $batch['sku'] . ' - ' . $batch['product_name']; ?></h5>
                        <p class="text-muted mb-0"><?php echo $batch['brand_name']; ?> • <?php echo $batch['category_name']; ?></p>
                    </div>
                    <div class="col-md-4 text-end">
                        <?php 
                        $status_class = '';
                        $days = $batch['days_remaining'];
                        
                        if($batch['status'] == 'expired' || $days < 0) {
                            $status_class = 'bg-danger';
                            $status_text = 'EXPIRED';
                        } elseif($batch['status'] == 'quarantine') {
                            $status_class = 'bg-warning text-dark';
                            $status_text = 'QUARANTINE';
                        } elseif($days <= 30) {
                            $status_class = 'bg-danger';
                            $status_text = 'CRITICAL';
                        } elseif($days <= 90) {
                            $status_class = 'bg-warning text-dark';
                            $status_text = 'WARNING';
                        } else {
                            $status_class = 'bg-success';
                            $status_text = 'RELEASED';
                        }
                        ?>
                        <span class="badge <?php echo $status_class; ?> status-badge-lg">
                            <?php echo $status_text; ?>
                        </span>
                    </div>
                </div>
            </div>
            
            <!-- Tabs -->
            <ul class="nav nav-tabs" id="batchTabs">
                <li class="nav-item">
                    <a class="nav-link active" data-bs-toggle="tab" href="#details">Details</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" data-bs-toggle="tab" href="#qc">QC Checks</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" data-bs-toggle="tab" href="#transactions">Transactions</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" data-bs-toggle="tab" href="#actions">Actions</a>
                </li>
            </ul>
            
            <div class="tab-content" id="batchTabsContent">
                <!-- Details Tab -->
                <div class="tab-pane fade show active" id="details">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="info-card">
                                <h5><i class="fas fa-info-circle"></i> Batch Information</h5>
                                <div class="info-row">
                                    <strong>Batch Number:</strong> <?php echo $batch['batch_number']; ?>
                                </div>
                                <div class="info-row">
                                    <strong>BPOM Number:</strong> <?php echo $batch['bpom_number']; ?>
                                </div>
                                <div class="info-row">
                                    <strong>Manufacturing Date:</strong> <?php echo date('d/m/Y', strtotime($batch['manufacturing_date'])); ?>
                                </div>
                                <div class="info-row">
                                    <strong>Expiry Date:</strong> <?php echo date('d/m/Y', strtotime($batch['expiry_date'])); ?>
                                </div>
                                <div class="info-row">
                                    <strong>Days Remaining:</strong> 
                                    <span class="badge <?php echo $status_class; ?>">
                                        <?php echo $days > 0 ? $days . ' days' : 'EXPIRED'; ?>
                                    </span>
                                </div>
                                <div class="expiry-progress">
                                    <?php 
                                    $progress_width = min(100, max(0, (1 - ($days/730)) * 100));
                                    $progress_class = $days <= 30 ? 'bg-danger' : ($days <= 90 ? 'bg-warning' : 'bg-success');
                                    ?>
                                    <div class="expiry-bar <?php echo $progress_class; ?>" 
                                         style="width: <?php echo $progress_width; ?>%"></div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="info-card">
                                <h5><i class="fas fa-cube"></i> Product Information</h5>
                                <div class="info-row">
                                    <strong>Product:</strong> <?php echo $batch['product_name']; ?>
                                </div>
                                <div class="info-row">
                                    <strong>SKU:</strong> <?php echo $batch['sku']; ?>
                                </div>
                                <div class="info-row">
                                    <strong>Brand:</strong> <?php echo $batch['brand_name']; ?>
                                </div>
                                <div class="info-row">
                                    <strong>Category:</strong> <?php echo $batch['category_name']; ?>
                                </div>
                                <div class="info-row">
                                    <strong>Halal Certified:</strong> 
                                    <?php echo $batch['halal_certified'] ? '<span class="badge bg-success">Yes</span>' : '<span class="badge bg-secondary">No</span>'; ?>
                                </div>
                            </div>
                            
                            <div class="info-card">
                                <h5><i class="fas fa-warehouse"></i> Storage Information</h5>
                                <div class="info-row">
                                    <strong>Quantity:</strong> <?php echo $batch['current_quantity']; ?> / <?php echo $batch['quantity']; ?>
                                </div>
                                <div class="info-row">
                                    <strong>Location:</strong> <?php echo $batch['location_code'] ?? 'N/A'; ?>
                                </div>
                                <div class="info-row">
                                    <strong>Zone:</strong> <?php echo $batch['zone_code'] ?? 'N/A'; ?>
                                </div>
                                <div class="info-row">
                                    <strong>Created By:</strong> <?php echo $batch['created_by_name'] ?? 'System'; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- QC Checks Tab -->
                <div class="tab-pane fade" id="qc">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h5>Quality Control Checks</h5>
                        <a href="qc_check.php?batch_id=<?php echo $batch_id; ?>" class="btn btn-primary btn-sm">
                            <i class="fas fa-plus"></i> New QC Check
                        </a>
                    </div>
                    
                    <?php if(mysqli_num_rows($qc_result) > 0): ?>
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Type</th>
                                <th>Temperature</th>
                                <th>Packaging</th>
                                <th>Condition</th>
                                <th>Result</th>
                                <th>Checked By</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($qc = mysqli_fetch_assoc($qc_result)): ?>
                            <tr>
                                <td><?php echo date('d/m/Y', strtotime($qc['check_date'])); ?></td>
                                <td><?php echo ucfirst($qc['check_type']); ?></td>
                                <td><?php echo $qc['temperature_check'] ?? 'N/A'; ?>°C</td>
                                <td><?php echo ucfirst($qc['packaging_condition']); ?></td>
                                <td><?php echo ucfirst($qc['product_condition']); ?></td>
                                <td>
                                    <?php if($qc['passed']): ?>
                                    <span class="badge bg-success">Passed</span>
                                    <?php else: ?>
                                    <span class="badge bg-danger">Failed</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo $qc['checked_by'] ?? 'N/A'; ?></td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                    <?php else: ?>
                    <div class="alert alert-info">
                        No QC checks recorded for this batch.
                    </div>
                    <?php endif; ?>
                </div>
                
                <!-- Transactions Tab -->
                <div class="tab-pane fade" id="transactions">
                    <h5>Recent Transactions</h5>
                    
                    <?php if(mysqli_num_rows($tx_result) > 0): ?>
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Type</th>
                                <th>Quantity</th>
                                <th>Reference</th>
                                <th>Notes</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($tx = mysqli_fetch_assoc($tx_result)): ?>
                            <tr>
                                <td><?php echo date('d/m/Y H:i', strtotime($tx['transaction_date'])); ?></td>
                                <td>
                                    <?php 
                                    $type_class = strpos($tx['transaction_type'], '_out') ? 'text-danger' : 'text-success';
                                    echo '<span class="' . $type_class . '">' . $tx['transaction_type'] . '</span>';
                                    ?>
                                </td>
                                <td><?php echo $tx['quantity']; ?></td>
                                <td><?php echo $tx['reference_no'] ?? 'N/A'; ?></td>
                                <td><?php echo $tx['notes'] ?? '-'; ?></td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                    <?php else: ?>
                    <div class="alert alert-info">
                        No transactions recorded for this batch.
                    </div>
                    <?php endif; ?>
                </div>
                
                <!-- Actions Tab -->
                <div class="tab-pane fade" id="actions">
                    <h5>Batch Actions</h5>
                    
                    <div class="row">
                        <div class="col-md-4">
                            <div class="card text-center">
                                <div class="card-body">
                                    <i class="fas fa-edit fa-3x text-primary mb-3"></i>
                                    <h5>Edit Batch</h5>
                                    <p>Update batch information</p>
                                    <a href="edit.php?id=<?php echo $batch_id; ?>" class="btn btn-primary">
                                        <i class="fas fa-edit"></i> Edit
                                    </a>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-4">
                            <div class="card text-center">
                                <div class="card-body">
                                    <i class="fas fa-clipboard-check fa-3x text-warning mb-3"></i>
                                    <h5>QC Check</h5>
                                    <p>Perform quality control check</p>
                                    <a href="qc_check.php?batch_id=<?php echo $batch_id; ?>" class="btn btn-warning">
                                        <i class="fas fa-clipboard-check"></i> QC Check
                                    </a>
                                </div>
                            </div>
                        </div>
                        
                        <?php if($batch['status'] == 'quarantine'): ?>
                        <div class="col-md-4">
                            <div class="card text-center">
                                <div class="card-body">
                                    <i class="fas fa-check-circle fa-3x text-success mb-3"></i>
                                    <h5>Release Batch</h5>
                                    <p>Release from quarantine</p>
                                    <a href="release.php?id=<?php echo $batch_id; ?>" class="btn btn-success">
                                        <i class="fas fa-check"></i> Release
                                    </a>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Danger Zone -->
                    <div class="card border-danger mt-4">
                        <div class="card-header bg-danger text-white">
                            <h5 class="mb-0"><i class="fas fa-exclamation-triangle"></i> Danger Zone</h5>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <h6>Mark as Expired</h6>
                                    <p>Manually mark this batch as expired</p>
                                    <button class="btn btn-outline-danger" data-bs-toggle="modal" data-bs-target="#expireModal">
                                        <i class="fas fa-skull-crossbones"></i> Mark Expired
                                    </button>
                                </div>
                                <div class="col-md-6">
                                    <h6>Recall Batch</h6>
                                    <p>Recall batch from circulation</p>
                                    <button class="btn btn-outline-dark">
                                        <i class="fas fa-undo"></i> Recall Batch
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Expire Modal -->
    <div class="modal fade" id="expireModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-danger text-white">
                    <h5 class="modal-title">Mark Batch as Expired</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p>Are you sure you want to mark batch <strong><?php echo $batch['batch_number']; ?></strong> as expired?</p>
                    <p class="text-danger"><i class="fas fa-exclamation-triangle"></i> This action cannot be undone!</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <a href="action_expire.php?id=<?php echo $batch_id; ?>" class="btn btn-danger">
                        Yes, Mark as Expired
                    </a>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>