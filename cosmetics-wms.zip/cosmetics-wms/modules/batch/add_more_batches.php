<?php
// modules/batch/add_more_batches.php
define('ROOT_PATH', dirname(dirname(dirname(__FILE__))) . '/');
require_once ROOT_PATH . 'includes/config.php';
session_start();

// Cek login
if(!isset($_SESSION['user_id'])) {
    header("Location: " . ROOT_PATH . "login.php");
    exit();
}

echo "<!DOCTYPE html>
<html>
<head>
    <title>Add Dummy Batches</title>
    <link href='https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css' rel='stylesheet'>
    <style>
        body { padding: 20px; background: #f8f9fa; }
        .container { max-width: 800px; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
    </style>
</head>
<body>
    <div class='container'>
        <h2>🔄 Add Dummy Batches</h2>
        <p>Adding sample batch data for testing...</p>
        <hr>";

// Dummy batch data - 25 batches total
$dummy_batches = [
    // Lipstick batches
    ['LIP-001', 'BATCH-LIP001-2024-01', '2024-01-15', '2025-07-15', 200, 'BPOM123456701', 'released'],
    ['LIP-001', 'BATCH-LIP001-2024-02', '2024-02-20', '2025-08-20', 180, 'BPOM123456702', 'released'],
    ['LIP-001', 'BATCH-LIP001-2024-03', '2024-03-10', '2025-09-10', 220, 'BPOM123456703', 'released'],
    ['LIP-002', 'BATCH-LIP002-2024-01', '2024-01-25', '2025-07-25', 150, 'BPOM123456704', 'released'],
    ['LIP-002', 'BATCH-LIP002-2024-02', '2024-02-28', '2025-08-28', 170, 'BPOM123456705', 'quarantine'],
    
    // Foundation batches
    ['FND-001', 'BATCH-FND001-2024-01', '2024-01-10', '2025-07-10', 100, 'BPOM123456706', 'released'],
    ['FND-001', 'BATCH-FND001-2024-02', '2024-02-15', '2025-08-15', 120, 'BPOM123456707', 'released'],
    ['FND-001', 'BATCH-FND001-2024-03', '2024-03-20', '2025-09-20', 90, 'BPOM123456708', 'expired'],
    ['FND-002', 'BATCH-FND002-2024-01', '2024-01-05', '2025-07-05', 80, 'BPOM123456709', 'released'],
    
    // Face Powder batches
    ['POW-001', 'BATCH-POW001-2024-01', '2024-01-12', '2025-07-12', 300, 'BPOM123456710', 'released'],
    ['POW-001', 'BATCH-POW001-2024-02', '2024-02-18', '2025-08-18', 280, 'BPOM123456711', 'released'],
    ['POW-001', 'BATCH-POW001-2024-03', '2024-03-22', '2025-09-22', 320, 'BPOM123456712', 'quarantine'],
    ['POW-002', 'BATCH-POW002-2024-01', '2024-01-08', '2025-07-08', 250, 'BPOM123456713', 'released'],
    
    // Mascara batches
    ['MSC-001', 'BATCH-MSC001-2024-01', '2024-01-20', '2025-07-20', 120, 'BPOM123456714', 'released'],
    ['MSC-001', 'BATCH-MSC001-2024-02', '2024-02-25', '2025-08-25', 140, 'BPOM123456715', 'expired'],
    ['MSC-002', 'BATCH-MSC002-2024-01', '2024-01-30', '2025-07-30', 160, 'BPOM123456716', 'released'],
    
    // Skincare batches
    ['SKN-001', 'BATCH-SKN001-2024-01', '2024-01-14', '2025-07-14', 150, 'BPOM123456717', 'released'],
    ['SKN-001', 'BATCH-SKN001-2024-02', '2024-02-16', '2025-08-16', 130, 'BPOM123456718', 'released'],
    ['SKN-002', 'BATCH-SKN002-2024-01', '2024-01-22', '2025-07-22', 110, 'BPOM123456719', 'quarantine'],
    ['SKN-003', 'BATCH-SKN003-2024-01', '2024-01-28', '2025-07-28', 180, 'BPOM123456720', 'released'],
    
    // Fragrance batches
    ['FRG-001', 'BATCH-FRG001-2024-01', '2024-01-18', '2025-07-18', 80, 'BPOM123456721', 'released'],
    ['FRG-001', 'BATCH-FRG001-2024-02', '2024-02-22', '2025-08-22', 90, 'BPOM123456722', 'expired'],
    ['FRG-002', 'BATCH-FRG002-2024-01', '2024-01-24', '2025-07-24', 70, 'BPOM123456723', 'released'],
    
    // Expired batches for testing
    ['LIP-001', 'BATCH-LIP001-2023-01', '2023-01-15', '2024-01-15', 100, 'BPOM123456724', 'expired'],
    ['FND-001', 'BATCH-FND001-2023-02', '2023-02-20', '2024-02-20', 80, 'BPOM123456725', 'expired']
];

$added = 0;
$skipped = 0;

foreach($dummy_batches as $batch) {
    $sku = $batch[0];
    $batch_number = $batch[1];
    
    // Cek apakah batch sudah ada
    $check_sql = "SELECT id FROM product_batches WHERE batch_number = '$batch_number'";
    $check_result = mysqli_query($conn, $check_sql);
    
    if(mysqli_num_rows($check_result) == 0) {
        // Cari product_id berdasarkan SKU
        $product_sql = "SELECT id FROM products WHERE sku = '$sku' LIMIT 1";
        $product_result = mysqli_query($conn, $product_sql);
        
        if(mysqli_num_rows($product_result) > 0) {
            $product = mysqli_fetch_assoc($product_result);
            $product_id = $product['id'];
            
            $manufacturing_date = $batch[2];
            $expiry_date = $batch[3];
            $quantity = $batch[4];
            $bpom_number = $batch[5];
            $status = $batch[6];
            
            // Insert batch baru
            $insert_sql = "INSERT INTO product_batches 
                          (product_id, batch_number, manufacturing_date, expiry_date, 
                           quantity, current_quantity, bpom_number, status, created_at, created_by)
                          VALUES 
                          ($product_id, '$batch_number', '$manufacturing_date', '$expiry_date',
                           $quantity, $quantity, '$bpom_number', '$status', NOW(), " . $_SESSION['user_id'] . ")";
            
            if(mysqli_query($conn, $insert_sql)) {
                echo "<div class='alert alert-success'>✅ Added: $batch_number</div>";
                $added++;
            } else {
                echo "<div class='alert alert-danger'>❌ Error: " . mysqli_error($conn) . "</div>";
            }
        } else {
            echo "<div class='alert alert-warning'>⚠️ Product not found: $sku</div>";
        }
    } else {
        echo "<div class='alert alert-info'>⏭️ Skip (exists): $batch_number</div>";
        $skipped++;
    }
}

// Tampilkan summary
echo "<hr>
      <div class='alert alert-primary'>
          <h4>📊 Summary</h4>
          <p>✅ Added: <strong>$added</strong> new batches</p>
          <p>⏭️ Skipped: <strong>$skipped</strong> existing batches</p>
          <p>📦 Total batches in database now: ";

// Hitung total batch setelah penambahan
$total_sql = "SELECT COUNT(*) as total FROM product_batches";
$total_result = mysqli_query($conn, $total_sql);
$total = mysqli_fetch_assoc($total_result)['total'];

echo "<strong>$total</strong> batches</p>
      </div>";

echo "<div class='mt-4'>
        <a href='index.php' class='btn btn-primary'>📋 View Batch List</a>
        <a href='" . ROOT_PATH . "index.php' class='btn btn-secondary'>🏠 Dashboard</a>
      </div>";

echo "</div></body></html>";
?>