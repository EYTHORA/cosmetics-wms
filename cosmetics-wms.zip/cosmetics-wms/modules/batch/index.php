<?php
// modules/batch/index.php
define('ROOT_PATH', dirname(dirname(dirname(__FILE__))) . '/');
require_once ROOT_PATH . 'includes/config.php';
require_once ROOT_PATH . 'includes/auth.php';
checkLogin();

$page_title = "Batch Management";

// Query untuk batch
$sql = "SELECT pb.*, p.name as product_name, p.sku,
               b.name as brand_name,
               DATEDIFF(pb.expiry_date, CURDATE()) as days_remaining
        FROM product_batches pb
        JOIN products p ON pb.product_id = p.id
        JOIN brands b ON p.brand_id = b.id
        ORDER BY pb.expiry_date ASC";

$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cosmetics WMS - Batch Management</title>
    
    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <!-- DataTables -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.4.1/css/buttons.bootstrap5.min.css">
    
    <style>
        /* Sidebar Styles */
        .sidebar {
            background: linear-gradient(180deg, #2c3e50 0%, #1a252f 100%);
            color: white;
            min-height: 100vh;
            width: 250px;
            position: fixed;
            left: 0;
            top: 0;
            overflow-y: auto;
            z-index: 1000;
        }
        
        .main-content {
            margin-left: 250px;
            padding: 20px;
            min-height: 100vh;
            background: #f8f9fa;
        }
        
        .top-navbar {
            background: white;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            padding: 15px 20px;
            margin: -20px -20px 20px -20px;
            border-radius: 0;
            position: sticky;
            top: 0;
            z-index: 100;
        }
        
        .sidebar-header {
            padding: 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .sidebar-menu {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        
        .sidebar-menu li {
            position: relative;
        }
        
        .sidebar-menu li a {
            color: #bdc3c7;
            padding: 12px 20px;
            display: block;
            text-decoration: none;
            border-left: 4px solid transparent;
            transition: all 0.3s;
        }
        
        .sidebar-menu li a:hover {
            background: rgba(255,255,255,0.05);
            color: white;
            border-left-color: #3498db;
        }
        
        .sidebar-menu li.active a {
            background: rgba(52, 152, 219, 0.1);
            color: #3498db;
            border-left-color: #3498db;
        }
        
        /* Card Styles */
        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 20px;
        }
        
        .card-header {
            background: white;
            border-bottom: 1px solid rgba(0,0,0,0.05);
            padding: 20px;
            border-radius: 10px 10px 0 0 !important;
        }
        
        /* Table Styles */
        .dataTables_wrapper {
            padding: 0;
        }
        
        .dataTables_length,
        .dataTables_filter {
            margin-bottom: 15px;
        }
        
        .dataTables_filter input {
            border: 1px solid #ddd;
            border-radius: 5px;
            padding: 5px 10px;
        }
        
        .dataTables_info {
            padding: 15px 0;
        }
        
        .dataTables_paginate {
            margin-top: 15px;
        }
        
        .paginate_button {
            margin: 0 3px;
            padding: 5px 10px !important;
            border: 1px solid #ddd !important;
            border-radius: 5px !important;
            background: white !important;
            color: #333 !important;
        }
        
        .paginate_button.current {
            background: #3498db !important;
            color: white !important;
            border-color: #3498db !important;
        }
        
        .paginate_button:hover {
            background: #f8f9fa !important;
        }
        
        /* Status Badges */
        .badge-expired { background: #dc3545; color: white; }
        .badge-critical { background: #fd7e14; color: white; }
        .badge-warning { background: #ffc107; color: black; }
        .badge-good { background: #28a745; color: white; }
        .badge-quarantine { background: #6c757d; color: white; }
        
        /* Table Header */
        .table thead th {
            background: #2c3e50;
            color: white;
            border: none;
            padding: 15px;
            font-weight: 600;
        }
        
        .table tbody td {
            padding: 12px 15px;
            vertical-align: middle;
        }
        
        .table-hover tbody tr:hover {
            background-color: rgba(52, 152, 219, 0.05);
        }
        
        /* Button Group */
        .btn-group-sm .btn {
            padding: 5px 10px;
            margin: 0 2px;
            border-radius: 5px;
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                width: 70px;
            }
            .sidebar .sidebar-header h4,
            .sidebar .nav-link span:not(.icon) {
                display: none;
            }
            .main-content {
                margin-left: 70px;
            }
            .sidebar-header {
                padding: 15px 10px;
                text-align: center;
            }
        }
    </style>
</head>
<body>
      <div class="wrapper">
        <!-- Sidebar -->
        <?php include ROOT_PATH . 'includes/sidebar.php'; ?>
        
        <!-- Main Content -->
        <div class="main-content">
            <!-- Top Navbar -->
            <div class="top-navbar">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h4 class="mb-0">Batch Management</h4>
                        <small class="text-muted">Manage product batches and expiry dates</small>
                    </div>
                    <div>
                        <span class="badge bg-primary"><?php echo $_SESSION['username']; ?></span>
                    </div>
                </div>
            </div>
            
            <!-- Stats Cards -->
            <div class="row mb-4">
                <div class="col-md-3">
                    <div class="card bg-primary text-white">
                        <div class="card-body">
                            <h6>Total Batches</h6>
                            <?php
                            $total_sql = "SELECT COUNT(*) as total FROM product_batches";
                            $total_result = mysqli_query($conn, $total_sql);
                            $total = mysqli_fetch_assoc($total_result)['total'];
                            ?>
                            <h2><?php echo $total; ?></h2>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-3">
                    <div class="card bg-danger text-white">
                        <div class="card-body">
                            <h6>Expired</h6>
                            <?php
                            $expired_sql = "SELECT COUNT(*) as total FROM product_batches 
                                           WHERE expiry_date < CURDATE() OR status = 'expired'";
                            $expired_result = mysqli_query($conn, $expired_sql);
                            $expired = mysqli_fetch_assoc($expired_result)['total'];
                            ?>
                            <h2><?php echo $expired; ?></h2>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-3">
                    <div class="card bg-warning text-white">
                        <div class="card-body">
                            <h6>Expiring Soon</h6>
                            <?php
                            $soon_sql = "SELECT COUNT(*) as total FROM product_batches 
                                        WHERE expiry_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)";
                            $soon_result = mysqli_query($conn, $soon_sql);
                            $soon = mysqli_fetch_assoc($soon_result)['total'];
                            ?>
                            <h2><?php echo $soon; ?></h2>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-3">
                    <div class="card bg-success text-white">
                        <div class="card-body">
                            <h6>Released</h6>
                            <?php
                            $released_sql = "SELECT COUNT(*) as total FROM product_batches WHERE status = 'released'";
                            $released_result = mysqli_query($conn, $released_sql);
                            $released = mysqli_fetch_assoc($released_result)['total'];
                            ?>
                            <h2><?php echo $released; ?></h2>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Batch Table -->
            <div class="card">
                <div class="card-header">
                    <div class="d-flex justify-content-between align-items-center">
                        <h5 class="mb-0"><i class="fas fa-list me-2"></i>Batch List</h5>
                        <a href="add.php" class="btn btn-primary btn-sm">
                            <i class="fas fa-plus"></i> Add Batch
                        </a>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover" id="batchTable">
                            <thead>
                                <tr>
                                    <th>Batch No</th>
                                    <th>Product</th>
                                    <th>Brand</th>
                                    <th>Manufacture</th>
                                    <th>Expiry</th>
                                    <th>Days Left</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while($row = mysqli_fetch_assoc($result)): 
                                    $days = $row['days_remaining'];
                                    
                                    // Tentukan status
                                    if($row['status'] == 'expired' || $days < 0) {
                                        $status_class = 'badge-expired';
                                        $status_text = 'Expired';
                                    } elseif($row['status'] == 'quarantine') {
                                        $status_class = 'badge-quarantine';
                                        $status_text = 'Quarantine';
                                    } elseif($days <= 30) {
                                        $status_class = 'badge-critical';
                                        $status_text = 'Critical';
                                    } elseif($days <= 90) {
                                        $status_class = 'badge-warning';
                                        $status_text = 'Warning';
                                    } else {
                                        $status_class = 'badge-good';
                                        $status_text = 'Good';
                                    }
                                ?>
                                <tr>
                                    <td><strong><?php echo $row['batch_number']; ?></strong></td>
                                    <td>
                                        <div><?php echo $row['sku']; ?></div>
                                        <small class="text-muted"><?php echo $row['product_name']; ?></small>
                                    </td>
                                    <td><?php echo $row['brand_name']; ?></td>
                                    <td><?php echo date('d/m/Y', strtotime($row['manufacturing_date'])); ?></td>
                                    <td><?php echo date('d/m/Y', strtotime($row['expiry_date'])); ?></td>
                                    <td>
                                        <span class="badge <?php echo $status_class; ?>">
                                            <?php echo $days > 0 ? $days . ' days' : 'EXPIRED'; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="badge <?php echo $status_class; ?>">
                                            <?php echo $status_text; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <div class="btn-group btn-group-sm">
                                            <!-- VIEW Button -->
                                            <a href="view.php?id=<?php echo $row['id']; ?>" 
                                               class="btn btn-info" 
                                               title="View Details"
                                               data-bs-toggle="tooltip">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                            
                                            <!-- EDIT Button -->
                                            <a href="edit.php?id=<?php echo $row['id']; ?>" 
                                               class="btn btn-warning" 
                                               title="Edit Batch"
                                               data-bs-toggle="tooltip">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            
                                            <!-- QC Button -->
                                            <a href="qc_check.php?batch_id=<?php echo $row['id']; ?>" 
                                               class="btn btn-secondary" 
                                               title="QC Check"
                                               data-bs-toggle="tooltip">
                                                <i class="fas fa-clipboard-check"></i>
                                            </a>
                                            
                                            <!-- RELEASE Button (only for quarantine) -->
                                            <?php if($row['status'] == 'quarantine'): ?>
                                            <a href="release.php?id=<?php echo $row['id']; ?>" 
                                               class="btn btn-success" 
                                               title="Release from Quarantine"
                                               data-bs-toggle="tooltip">
                                                <i class="fas fa-check"></i>
                                            </a>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- DataTables -->
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
    
    <script>
    $(document).ready(function() {
        // Initialize DataTables dengan config yang lebih baik
        $('#batchTable').DataTable({
            dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6"f>>' +
                 '<"row"<"col-sm-12"tr>>' +
                 '<"row"<"col-sm-12 col-md-5"i><"col-sm-12 col-md-7"p>>',
            pageLength: 10,
            lengthMenu: [[10, 25, 50, 100, -1], [10, 25, 50, 100, "All"]],
            language: {
                search: "Search batches:",
                searchPlaceholder: "Type to search...",
                lengthMenu: "Show _MENU_ entries",
                info: "Showing _START_ to _END_ of _TOTAL_ batches",
                infoEmpty: "Showing 0 to 0 of 0 batches",
                infoFiltered: "(filtered from _MAX_ total batches)",
                paginate: {
                    first: "First",
                    last: "Last",
                    next: "Next",
                    previous: "Previous"
                },
                emptyTable: "No batch data available"
            },
            order: [[4, 'asc']], // Sort by expiry date (column 4)
            columnDefs: [
                { orderable: false, targets: [7] } // Make actions column not sortable
            ],
            initComplete: function() {
                // Add custom CSS untuk pagination
                $('.dataTables_paginate').addClass('pagination-sm');
            }
        });
        
        // Initialize tooltips
        $('[data-bs-toggle="tooltip"]').tooltip();
        
        // Add hover effect to table rows
        $('#batchTable tbody tr').hover(
            function() {
                $(this).addClass('table-active');
            },
            function() {
                $(this).removeClass('table-active');
            }
        );
    });
    </script>
</body>
</html>