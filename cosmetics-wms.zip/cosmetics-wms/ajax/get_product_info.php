<?php
// modules/batch/ajax/get_product_info.php
define('ROOT_PATH', dirname(dirname(dirname(dirname(__FILE__)))) . '/');
require_once ROOT_PATH . 'includes/config.php';

if(isset($_POST['product_id'])) {
    $product_id = intval($_POST['product_id']);
    
    $sql = "SELECT p.sku, p.name, p.halal_certified,
                   b.name as brand_name, c.name as category_name
            FROM products p
            LEFT JOIN brands b ON p.brand_id = b.id
            LEFT JOIN categories c ON p.category_id = c.id
            WHERE p.id = $product_id";
    
    $result = mysqli_query($conn, $sql);
    
    if(mysqli_num_rows($result) > 0) {
        $product = mysqli_fetch_assoc($result);
        
        echo json_encode([
            'success' => true,
            'sku' => $product['sku'],
            'brand' => $product['brand_name'],
            'category' => $product['category_name'],
            'halal' => (bool)$product['halal_certified']
        ]);
    } else {
        echo json_encode(['success' => false]);
    }
}
?>