 <?php
                // includes/config.php
                session_start();

                // Database connection
                $conn = mysqli_connect("localhost", "root", "", "cosmetics_wms");
                if (!$conn) {
                    die("Connection failed: " . mysqli_connect_error());
                }

                // ========== TAMBAHKAN INI ==========
                // Base URL Configuration
                $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
                $host = $_SERVER['HTTP_HOST'];

                // Auto-detect project folder
                $script_dir = dirname($_SERVER['SCRIPT_NAME']);

                // Jika script di root htdocs
                if($script_dir === '/' || $script_dir === '\\') {
                    define('BASE_URL', $protocol . '://' . $host . '/cosmetics-wms/');
                } else {
                    // Naik satu level ke root project
                    $project_root = dirname($script_dir);
                    define('BASE_URL', $protocol . '://' . $host . $project_root . '/');
                }

                // Juga define ROOT_PATH untuk file system
                // define('ROOT_PATH', dirname(__DIR__) . '/');
                // ====================================

                // Timezone
                date_default_timezone_set('Asia/Jakarta');

                // Error reporting (untuk development)
                error_reporting(E_ALL);
                ini_set('display_errors', 1);
                ?>