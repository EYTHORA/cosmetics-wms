<?php
// includes/header.php

// Dapatkan base directory
$base_path = dirname(dirname(__FILE__)) . '/';
$current_path = dirname($_SERVER['PHP_SELF']);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cosmetics WMS - <?php echo $page_title ?? 'Dashboard'; ?></title>
    
    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <!-- DataTables -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">
    
    <style>
        /* Basic styles */
        .sidebar {
            background: linear-gradient(180deg, #2c3e50 0%, #1a252f 100%);
            color: white;
            min-height: 100vh;
            width: 250px;
            position: fixed;
            left: 0;
            top: 0;
            overflow-y: auto;
        }
        
        .main-content {
            margin-left: 250px;
            padding: 20px;
            min-height: 100vh;
            background: #f8f9fa;
        }
        
        .top-navbar {
            background: white;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            padding: 15px 20px;
            position: sticky;
            top: 0;
            z-index: 100;
        }
        
        .sidebar-menu {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        
        .sidebar-menu li a {
            color: #bdc3c7;
            padding: 12px 20px;
            display: block;
            text-decoration: none;
            border-left: 4px solid transparent;
        }
        
        .sidebar-menu li a:hover {
            background: rgba(255,255,255,0.05);
            color: white;
            border-left-color: #3498db;
        }
        
        .sidebar-menu li.active a {
            background: rgba(52, 152, 219, 0.1);
            color: #3498db;
            border-left-color: #3498db;
        }
        
        .card {
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 20px;
            border: none;
        }
        
        .badge-expired { background: #dc3545; color: white; }
        .badge-critical { background: #fd7e14; color: white; }
        .badge-warning { background: #ffc107; color: black; }
        .badge-good { background: #28a745; color: white; }
        .badge-quarantine { background: #6c757d; color: white; }
    </style>
</head>
<body>
    <div class="wrapper">
        <!-- Sidebar akan diinclude di sini -->
        <?php 
        // Cari sidebar.php dengan path yang benar
        $sidebar_path = __DIR__ . '/sidebar.php';
        if(file_exists($sidebar_path)) {
            include $sidebar_path;
        } else {
            echo "<!-- Sidebar file not found -->";
        }
        ?>
        
        <!-- Main Content -->
        <div class="main-content">
            <!-- Top Navbar -->
            <?php 
            $top_navbar_path = __DIR__ . '/top-navbar.php';
            if(file_exists($top_navbar_path)) {
                include $top_navbar_path;
            }
            ?>
            