<?php
// includes/dashboard_functions.php

function getDashboardSummary($conn) {
    $summary = [];
    
    // Total Products
    $sql1 = "SELECT COUNT(*) as total FROM products WHERE status = 'active'";
    $result1 = mysqli_query($conn, $sql1);
    $summary['total_products'] = mysqli_fetch_assoc($result1)['total'];
    
    // Active Batches
    $sql2 = "SELECT COUNT(*) as total FROM product_batches 
             WHERE status = 'released' AND expiry_date > CURDATE()";
    $result2 = mysqli_query($conn, $sql2);
    $summary['active_batches'] = mysqli_fetch_assoc($result2)['total'];
    
    // Critical Alerts
    $sql3 = "SELECT COUNT(*) as total FROM expiry_alerts 
             WHERE is_resolved = FALSE AND alert_type = 'critical'";
    $result3 = mysqli_query($conn, $sql3);
    $summary['critical_alerts'] = mysqli_fetch_assoc($result3)['total'];
    
    // Pending Orders
    $sql4 = "SELECT COUNT(*) as total FROM orders 
             WHERE status = 'picking' OR status = 'packing'";
    $result4 = mysqli_query($conn, $sql4);
    $summary['pending_orders'] = mysqli_fetch_assoc($result4)['total'];
    
    // Total Stock Items
    $sql5 = "SELECT SUM(current_quantity) as total FROM product_batches 
             WHERE status = 'released'";
    $result5 = mysqli_query($conn, $sql5);
    $summary['total_stock_items'] = mysqli_fetch_assoc($result5)['total'] ?: 0;
    
    return $summary;
}

function getLowStockProducts($conn) {
    $sql = "SELECT 
                p.sku,
                p.name,
                b.name as brand_name,
                COALESCE(SUM(pb.current_quantity), 0) as current_stock,
                p.min_stock
            FROM products p
            LEFT JOIN product_batches pb ON p.id = pb.product_id AND pb.status = 'released'
            LEFT JOIN brands b ON p.brand_id = b.id
            WHERE p.status = 'active'
            GROUP BY p.id
            HAVING current_stock <= p.min_stock";
    
    return mysqli_query($conn, $sql);
}

function getExpiringSoon($conn, $days = 90) {
    $sql = "SELECT 
                p.sku,
                p.name,
                pb.batch_number,
                pb.expiry_date,
                DATEDIFF(pb.expiry_date, CURDATE()) as days_remaining,
                pb.current_quantity,
                pb.location_id
            FROM product_batches pb
            JOIN products p ON pb.product_id = p.id
            WHERE pb.status = 'released' 
            AND pb.expiry_date > CURDATE()
            AND pb.expiry_date <= DATE_ADD(CURDATE(), INTERVAL $days DAY)
            ORDER BY pb.expiry_date ASC";
    
    return mysqli_query($conn, $sql);
}

function getProductStockReport($conn) {
    $sql = "SELECT 
                p.sku,
                p.name,
                b.name as brand_name,
                COALESCE(SUM(pb.current_quantity), 0) as total_stock,
                p.min_stock,
                p.max_stock,
                CASE 
                    WHEN COALESCE(SUM(pb.current_quantity), 0) <= p.min_stock THEN 'LOW STOCK'
                    WHEN COALESCE(SUM(pb.current_quantity), 0) >= p.max_stock THEN 'OVER STOCK'
                    ELSE 'NORMAL'
                END as stock_status
            FROM products p
            LEFT JOIN product_batches pb ON p.id = pb.product_id AND pb.status = 'released'
            LEFT JOIN brands b ON p.brand_id = b.id
            WHERE p.status = 'active'
            GROUP BY p.id
            ORDER BY stock_status, total_stock";
    
    return mysqli_query($conn, $sql);
}
?>