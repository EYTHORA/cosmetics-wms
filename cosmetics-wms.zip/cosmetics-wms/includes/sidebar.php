<?php
// includes/sidebar.php - VERSI SIMPLE COLLAPSIBLE
$current_url = $_SERVER['REQUEST_URI'];
?>

<div class="sidebar">
    <div class="sidebar-header">
        <div class="brand-content">
            <i class="fas fa-palette brand-icon"></i>
            <h4 class="brand-text">Cosmetics</h4>
        </div>
        <small class="sidebar-subtitle">Warehouse Management</small>
        <button class="toggle-sidebar">
            <i class="fas fa-chevron-left"></i>
        </button>
    </div>
    
    <ul class="sidebar-menu">
        <!-- Dashboard -->
        <li class="<?php 
            echo ($current_url == '/' || 
                  $current_url == '/cosmetics-wms/' || 
                  $current_url == '/index.php' || 
                  strpos($current_url, '/index.php') === 0) ? 'active' : ''; 
        ?>">
            <a href="http://localhost:8080/cosmetics-wms/">
                <i class="fas fa-tachometer-alt"></i> 
                <span class="menu-text">Dashboard</span>
            </a>
        </li>
        
        <!-- Products -->
        <li class="<?php 
            echo (strpos($current_url, '/modules/products/') !== false || 
                  strpos($current_url, 'products.php') !== false) ? 'active' : ''; 
        ?>">
            <a href="http://localhost:8080/cosmetics-wms/modules/products/">
                <i class="fas fa-cubes"></i> 
                <span class="menu-text">Products</span>
            </a>
        </li>
        
        <!-- Batch Management -->
        <li class="<?php 
            echo (strpos($current_url, '/modules/batch/') !== false || 
                  strpos($current_url, 'batch.php') !== false) ? 'active' : ''; 
        ?>">
            <a href="http://localhost:8080/cosmetics-wms/modules/batch/">
                <i class="fas fa-boxes"></i> 
                <span class="menu-text">Batch Management</span>
            </a>
        </li>
        
        <!-- Inventory -->
        <li class="<?php echo (strpos($current_url, '/modules/inventory/') !== false) ? 'active' : ''; ?>">
            <a href="http://localhost:8080/cosmetics-wms/modules/inventory/">
                <i class="fas fa-warehouse"></i> 
                <span class="menu-text">Inventory</span>
            </a>
        </li>
        
        <!-- Orders -->
        <li class="<?php echo (strpos($current_url, '/modules/orders/') !== false) ? 'active' : ''; ?>">
            <a href="http://localhost:8080/cosmetics-wms/modules/orders/">
                <i class="fas fa-shopping-cart"></i> 
                <span class="menu-text">Orders</span>
            </a>
        </li>
        
        <!-- Reports -->
        <li class="<?php echo (strpos($current_url, '/modules/reports/') !== false) ? 'active' : ''; ?>">
            <a href="http://localhost:8080/cosmetics-wms/modules/reports/">
                <i class="fas fa-chart-bar"></i> 
                <span class="menu-text">Reports</span>
            </a>
        </li>
        
        <!-- Settings -->
        <li class="<?php echo (strpos($current_url, '/modules/settings/') !== false) ? 'active' : ''; ?>">
            <a href="http://localhost:8080/cosmetics-wms/modules/settings/">
                <i class="fas fa-cog"></i> 
                <span class="menu-text">Settings</span>
            </a>
        </li>
        
        <li class="menu-divider"></li>
        
        <!-- Logout -->
        <li>
            <a href="http://localhost:8080/cosmetics-wms/logout.php" class="logout-btn">
                <i class="fas fa-sign-out-alt"></i> 
                <span class="menu-text">Logout</span>
            </a>
        </li>
    </ul>
    
    <!-- Toggle button untuk mobile -->
    <div class="mobile-toggle">
        <button class="btn-mobile-toggle">
            <i class="fas fa-bars"></i>
        </button>
    </div>
</div>

<style>
/* CSS SIDEBAR COLLAPSIBLE SIMPLE */
.sidebar {
    background: linear-gradient(180deg, #2c3e50 0%, #1a252f 100%);
    color: white;
    min-height: 100vh;
    width: 250px;
    position: fixed;
    left: 0;
    top: 0;
    overflow-y: auto;
    z-index: 1000;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    box-shadow: 3px 0 15px rgba(0,0,0,0.1);
}

/* Sidebar dalam keadaan collapsed */
.sidebar.collapsed {
    width: 70px;
}

.sidebar.collapsed .brand-text,
.sidebar.collapsed .sidebar-subtitle,
.sidebar.collapsed .menu-text {
    display: none !important;
}

.sidebar.collapsed .toggle-sidebar i {
    transform: rotate(180deg);
}

.sidebar.collapsed .sidebar-header {
    padding: 20px 10px;
    justify-content: center;
}

.sidebar.collapsed .brand-content {
    justify-content: center;
}

/* Header sidebar */
.sidebar-header {
    padding: 20px 15px;
    border-bottom: 1px solid rgba(255,255,255,0.1);
    position: relative;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
}

.brand-content {
    display: flex;
    align-items: center;
    gap: 10px;
    width: 100%;
}

.brand-icon {
    font-size: 1.5rem;
    color: #3498db;
}

.brand-text {
    margin: 0;
    font-size: 1.3rem;
    font-weight: 600;
    transition: opacity 0.3s;
}

.sidebar-subtitle {
    color: #95a5a6;
    font-size: 0.8rem;
    margin-left: 35px;
    margin-top: 2px;
    transition: opacity 0.3s;
}

.toggle-sidebar {
    position: absolute;
    right: 10px;
    top: 20px;
    background: rgba(255,255,255,0.1);
    border: none;
    color: white;
    width: 30px;
    height: 30px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: all 0.3s;
}

.toggle-sidebar:hover {
    background: rgba(255,255,255,0.2);
    transform: scale(1.1);
}

/* Menu utama */
.sidebar-menu {
    list-style: none;
    padding: 20px 0;
    margin: 0;
}

.sidebar-menu li {
    margin-bottom: 5px;
}

.sidebar-menu li a {
    color: #bdc3c7;
    padding: 12px 20px;
    display: flex;
    align-items: center;
    text-decoration: none;
    border-left: 4px solid transparent;
    transition: all 0.3s;
    white-space: nowrap;
}

.sidebar-menu li a:hover {
    background: rgba(255,255,255,0.05);
    color: white;
    border-left-color: #3498db;
    padding-left: 25px;
}

/* Active state */
.sidebar-menu li.active > a {
    background: rgba(52, 152, 219, 0.1);
    color: #3498db;
    border-left-color: #3498db;
    font-weight: 600;
}

/* Icon styling */
.sidebar-menu li a i {
    width: 20px;
    text-align: center;
    margin-right: 15px;
    font-size: 1.1rem;
    transition: margin-right 0.3s;
}

.sidebar.collapsed .sidebar-menu li a i {
    margin-right: 0;
    font-size: 1.3rem;
}

/* Menu divider */
.menu-divider {
    height: 1px;
    background: rgba(255,255,255,0.1);
    margin: 15px 20px;
}

/* Logout button styling */
.logout-btn {
    color: #e74c3c !important;
}

.logout-btn:hover {
    color: #c0392b !important;
    background: rgba(231, 76, 60, 0.1) !important;
    border-left-color: #e74c3c !important;
}

/* Mobile toggle */
.mobile-toggle {
    display: none;
    padding: 15px;
    border-top: 1px solid rgba(255,255,255,0.1);
}

.btn-mobile-toggle {
    background: rgba(255,255,255,0.1);
    border: none;
    color: white;
    padding: 10px;
    border-radius: 5px;
    width: 100%;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
}

.btn-mobile-toggle:hover {
    background: rgba(255,255,255,0.2);
}

/* Tooltip untuk collapsed state */
.sidebar.collapsed li a {
    position: relative;
}

.sidebar.collapsed li a::after {
    content: attr(data-title);
    position: absolute;
    left: 100%;
    top: 50%;
    transform: translateY(-50%);
    background: #2c3e50;
    color: white;
    padding: 8px 12px;
    border-radius: 4px;
    white-space: nowrap;
    opacity: 0;
    visibility: hidden;
    transition: all 0.3s;
    z-index: 1000;
    box-shadow: 0 5px 15px rgba(0,0,0,0.2);
    font-size: 0.9rem;
    pointer-events: none;
}

.sidebar.collapsed li a:hover::after {
    opacity: 1;
    visibility: visible;
    left: calc(100% + 10px);
}

/* Main content adjustment */
.main-content {
    margin-left: 250px;
    transition: margin-left 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    padding: 20px;
    min-height: 100vh;
    background: #f8f9fa;
}

.sidebar.collapsed ~ .main-content {
    margin-left: 70px;
}

/* Responsive */
@media (max-width: 768px) {
    .sidebar {
        width: 250px;
        transform: translateX(-100%);
    }
    
    .sidebar.show {
        transform: translateX(0);
        box-shadow: 3px 0 15px rgba(0,0,0,0.2);
    }
    
    .main-content {
        margin-left: 0 !important;
        width: 100%;
    }
    
    .toggle-sidebar {
        display: none;
    }
    
    .mobile-toggle {
        display: block;
    }
}

/* Animasi saat toggle */
@keyframes fadeIn {
    from { opacity: 0; transform: translateX(-10px); }
    to { opacity: 1; transform: translateX(0); }
}

.sidebar:not(.collapsed) .menu-text {
    animation: fadeIn 0.3s ease;
}
</style>

<script>
// JavaScript untuk toggle sidebar
document.addEventListener('DOMContentLoaded', function() {
    const sidebar = document.querySelector('.sidebar');
    const toggleBtn = document.querySelector('.toggle-sidebar');
    const mobileToggleBtn = document.querySelector('.btn-mobile-toggle');
    const menuItems = document.querySelectorAll('.sidebar-menu li a');
    
    // Tambahkan data-title untuk tooltip
    menuItems.forEach(item => {
        const text = item.querySelector('.menu-text');
        if (text) {
            item.setAttribute('data-title', text.textContent);
        }
    });
    
    // Toggle sidebar collapse/expand
    if (toggleBtn) {
        toggleBtn.addEventListener('click', function() {
            sidebar.classList.toggle('collapsed');
            
            // Simpan state di localStorage
            const isCollapsed = sidebar.classList.contains('collapsed');
            localStorage.setItem('sidebarCollapsed', isCollapsed);
        });
    }
    
    // Toggle sidebar untuk mobile
    if (mobileToggleBtn) {
        mobileToggleBtn.addEventListener('click', function() {
            sidebar.classList.toggle('show');
        });
    }
    
    // Cek state sebelumnya dari localStorage
    const savedState = localStorage.getItem('sidebarCollapsed');
    if (savedState === 'true') {
        sidebar.classList.add('collapsed');
    }
    
    // Tutup sidebar mobile ketika klik menu item
    menuItems.forEach(item => {
        item.addEventListener('click', function() {
            if (window.innerWidth <= 768) {
                sidebar.classList.remove('show');
            }
        });
    });
    
    // Tutup sidebar ketika klik di luar (untuk mobile)
    document.addEventListener('click', function(e) {
        if (window.innerWidth <= 768) {
            const isClickInsideSidebar = sidebar.contains(e.target);
            const isClickMobileToggle = e.target.closest('.btn-mobile-toggle');
            
            if (!isClickInsideSidebar && !isClickMobileToggle) {
                sidebar.classList.remove('show');
            }
        }
    });
    
    // Adjust main content padding jika ada navbar
    function adjustMainContent() {
        const mainContent = document.querySelector('.main-content');
        if (mainContent) {
            const navbar = document.querySelector('.navbar');
            if (navbar) {
                mainContent.style.paddingTop = (navbar.offsetHeight + 20) + 'px';
            }
        }
    }
    
    // Panggil saat resize dan load
    window.addEventListener('resize', adjustMainContent);
    window.addEventListener('load', adjustMainContent);
});
</script>