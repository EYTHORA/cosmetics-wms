<?php
// includes/top-navbar.php
?>
<nav class="navbar navbar-expand navbar-light top-navbar">
    <div class="container-fluid">
        <button class="btn sidebar-toggle">
            <i class="fas fa-bars"></i>
        </button>
        
        <div class="navbar-nav ms-auto">
            <div class="nav-item dropdown">
                <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                    <i class="fas fa-bell"></i>
                    <?php
                    if(isset($conn)) {
                        $alert_sql = "SELECT COUNT(*) as count FROM expiry_alerts 
                                     WHERE is_resolved = FALSE AND alert_type = 'critical'";
                        $alert_result = mysqli_query($conn, $alert_sql);
                        if($alert_result) {
                            $alert_count = mysqli_fetch_assoc($alert_result)['count'];
                            if($alert_count > 0): ?>
                            <span class="badge bg-danger"><?php echo $alert_count; ?></span>
                            <?php endif;
                        }
                    }
                    ?>
                </a>
                <div class="dropdown-menu dropdown-menu-end">
                    <h6 class="dropdown-header">Notifications</h6>
                    <?php if(isset($alert_count) && $alert_count > 0): ?>
                    <a class="dropdown-item text-danger" href="../modules/batch/expiring.php">
                        <i class="fas fa-exclamation-triangle"></i> 
                        <?php echo $alert_count; ?> Critical Alerts
                    </a>
                    <?php else: ?>
                    <a class="dropdown-item text-success" href="#">
                        <i class="fas fa-check-circle"></i> No Alerts
                    </a>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="nav-item dropdown">
                <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                    <i class="fas fa-user"></i> <?php echo $_SESSION['username'] ?? 'User'; ?>
                </a>
                <div class="dropdown-menu dropdown-menu-end">
                    <a class="dropdown-item" href="#">
                        <i class="fas fa-user"></i> Profile
                    </a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item text-danger" href="../logout.php">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </a>
                </div>
            </div>
        </div>
    </div>
</nav>